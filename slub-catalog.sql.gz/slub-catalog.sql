-- MySQL dump 10.19  Distrib 10.3.32-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.32-MariaDB-1:10.3.32+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  `ses_backuserid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('2fafb7e266d434ed98104847d713804c','172.18.0.6',1,1642085991,'a:3:{s:26:\"formProtectionSessionToken\";s:64:\"32adc2c1fab4f88f35b83a13d207fb1a4b71844a5e1e84bf9008ec0772eb9dfc\";s:27:\"core.template.flashMessages\";N;s:52:\"TYPO3\\CMS\\Recordlist\\Controller\\RecordListController\";a:1:{s:12:\"search_field\";N;}}',0);
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lang` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1624367317,1624366519,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$ZE5NTjRRVzB4L0RwbmFacA$/MpLqUmEOVmZf3BipEAYu5Jjwwjuln4TYex4AuwVDNM',1,'','','',NULL,0,'',NULL,'','a:18:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:16:{s:20:\"system_txschedulerM1\";a:1:{s:8:\"function\";s:9:\"scheduler\";}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:21:\"tt_content_showHidden\";s:1:\"1\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"72c0a70070d08880df0aebd62bc9009d\";a:4:{i:0;s:15:\"Merkliste Daten\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:23;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B23%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:23;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"86205c5935270b8ee413592ec1b62292\";}s:8:\"web_list\";a:0:{}s:9:\"file_list\";a:0:{}s:6:\"web_ts\";a:9:{s:8:\"function\";s:88:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateConstantEditorModuleFunctionController\";s:19:\"constant_editor_cat\";s:40:\"plugin.tx_slubfindbookmarks_bookmarklist\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:20:\"tsbrowser_conditions\";a:7:{s:32:\"84e9d80d6da41b7a6c1f69fe98cfd3c9\";s:0:\"\";s:32:\"c1b5091a90dfa3edffd3e43a67f1b342\";s:0:\"\";s:32:\"fa70637005b72eebdda9cbc0f887c773\";s:0:\"\";s:32:\"5ecb7d9a4a38a0a961d31a46b40f360f\";s:0:\"\";s:32:\"3581802b78b23550b06b802448ec1afb\";s:37:\"[applicationContext == \"Development\"]\";s:32:\"9e35f8eaeee866551253786fc2d2350c\";s:0:\"\";s:32:\"c1c93f67a548f1ed1d3bdd7f7391c7a3\";s:0:\"\";}s:25:\"tsbrowser_depthKeys_setup\";a:22:{s:3:\"lib\";i:1;s:11:\"lib.catalog\";i:1;s:21:\"lib.catalog.slubLinks\";i:1;s:29:\"lib.catalog.slubLinks.account\";i:1;s:27:\"lib.catalog.slubLinks.login\";i:1;s:10:\"lib.domain\";i:1;s:6:\"plugin\";i:1;s:14:\"plugin.tx_find\";i:1;s:23:\"plugin.tx_find.settings\";i:1;s:34:\"plugin.tx_find.settings.connection\";i:1;s:4:\"page\";i:1;s:7:\"page.10\";i:1;s:17:\"page.10.variables\";i:1;s:32:\"page.10.variables.link-myaccount\";i:1;s:21:\"plugin.tx_slubaccount\";i:1;s:30:\"plugin.tx_slubaccount.settings\";i:1;s:37:\"plugin.tx_slubevents_apieventlistuser\";i:1;s:46:\"plugin.tx_slubevents_apieventlistuser.settings\";i:1;s:20:\"plugin.tx_slubevents\";i:1;s:29:\"plugin.tx_slubevents.settings\";i:1;s:25:\"plugin.tx_slubevents.view\";i:1;s:43:\"plugin.tx_slubevents.view.templateRootPaths\";i:1;}s:25:\"tsbrowser_depthKeys_const\";a:10:{s:6:\"plugin\";i:1;s:37:\"plugin.tx_slubevents_apieventlistuser\";i:1;s:46:\"plugin.tx_slubevents_apieventlistuser.settings\";i:1;s:20:\"plugin.tx_slubevents\";i:1;s:25:\"plugin.tx_slubevents.view\";i:1;s:28:\"plugin.tx_slubprofileservice\";i:1;s:37:\"plugin.tx_slubprofileservice.settings\";i:1;s:41:\"plugin.tx_slubprofileservice.settings.api\";i:1;s:46:\"plugin.tx_slubprofileservice.settings.api.path\";i:1;s:56:\"plugin.tx_slubprofileservice.settings.api.path.eventList\";i:1;}}s:16:\"opendocs::recent\";a:8:{s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"79f152fef150ea5e312ccb91e4470b0d\";a:4:{i:0;s:9:\"Dashboard\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:29;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B29%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:29;s:3:\"pid\";i:15;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f3a80bc04cdfd6ed305676c6deecde13\";a:4:{i:0;s:13:\"Benutzerkonto\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:43;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B43%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:43;s:3:\"pid\";i:15;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f1892351c3b2949606a0d76de1876160\";a:4:{i:0;s:23:\"Hilfe zum Benutzerkonto\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:22;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B22%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:22;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"fc0dde5d1e90e1fd1027b6209ce79841\";a:4:{i:0;s:49:\"Führung durch die Corty Galerie - Test Kategorie\";i:1;a:6:{s:4:\"edit\";a:1:{s:32:\"tx_slubevents_domain_model_event\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:55:\"&edit%5Btx_slubevents_domain_model_event%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:32:\"tx_slubevents_domain_model_event\";s:3:\"uid\";i:7;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"baf83a68e479bbc8f26ae4dd4da4ceca\";a:4:{i:0;s:15:\"Testnutzer DDEV\";i:1;a:6:{s:4:\"edit\";a:1:{s:37:\"tx_slubevents_domain_model_subscriber\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:60:\"&edit%5Btx_slubevents_domain_model_subscriber%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_slubevents_domain_model_subscriber\";s:3:\"uid\";i:2;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"bdcd0cb0643a686dc359586441b9d5ed\";a:4:{i:0;s:15:\"Testnutzer DDEV\";i:1;a:6:{s:4:\"edit\";a:1:{s:37:\"tx_slubevents_domain_model_subscriber\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:60:\"&edit%5Btx_slubevents_domain_model_subscriber%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:37:\"tx_slubevents_domain_model_subscriber\";s:3:\"uid\";i:3;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"08a06f2b8fb494ab79c4796bee35f6db\";a:4:{i:0;s:24:\"Gebuchte Veranstaltungen\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:34;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B34%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:34;s:3:\"pid\";i:16;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:10:\"slubevents\";a:1:{s:13:\"tx_slubevents\";a:5:{s:22:\"selectedStartDateStamp\";s:10:\"29-06-2021\";s:12:\"searchString\";s:0:\"\";s:9:\"recurring\";s:0:\"\";s:8:\"category\";a:165:{i:167;s:0:\"\";i:166;s:0:\"\";i:159;s:3:\"159\";i:169;s:3:\"169\";i:165;s:3:\"165\";i:162;s:3:\"162\";i:161;s:3:\"161\";i:133;s:3:\"133\";i:144;s:3:\"144\";i:153;s:3:\"153\";i:152;s:3:\"152\";i:151;s:3:\"151\";i:150;s:3:\"150\";i:149;s:3:\"149\";i:148;s:3:\"148\";i:147;s:3:\"147\";i:146;s:3:\"146\";i:145;s:3:\"145\";i:139;s:3:\"139\";i:168;s:3:\"168\";i:164;s:3:\"164\";i:143;s:3:\"143\";i:142;s:3:\"142\";i:141;s:3:\"141\";i:140;s:3:\"140\";i:134;s:3:\"134\";i:163;s:3:\"163\";i:138;s:3:\"138\";i:137;s:3:\"137\";i:136;s:3:\"136\";i:135;s:3:\"135\";i:154;s:3:\"154\";i:117;s:3:\"117\";i:111;s:3:\"111\";i:114;s:3:\"114\";i:108;s:3:\"108\";i:106;s:3:\"106\";i:104;s:3:\"104\";i:102;s:3:\"102\";i:101;s:3:\"101\";i:98;s:2:\"98\";i:96;s:2:\"96\";i:109;s:3:\"109\";i:130;s:3:\"130\";i:110;s:3:\"110\";i:113;s:3:\"113\";i:107;s:3:\"107\";i:105;s:3:\"105\";i:103;s:3:\"103\";i:100;s:3:\"100\";i:99;s:2:\"99\";i:97;s:2:\"97\";i:95;s:2:\"95\";i:93;s:2:\"93\";i:131;s:3:\"131\";i:128;s:3:\"128\";i:91;s:2:\"91\";i:94;s:2:\"94\";i:132;s:3:\"132\";i:129;s:3:\"129\";i:92;s:2:\"92\";i:90;s:2:\"90\";i:89;s:2:\"89\";i:88;s:2:\"88\";i:86;s:2:\"86\";i:3;s:1:\"3\";i:44;s:2:\"44\";i:81;s:2:\"81\";i:85;s:2:\"85\";i:34;s:2:\"34\";i:33;s:2:\"33\";i:79;s:2:\"79\";i:84;s:2:\"84\";i:40;s:2:\"40\";i:77;s:2:\"77\";i:127;s:3:\"127\";i:118;s:3:\"118\";i:52;s:2:\"52\";i:51;s:2:\"51\";i:47;s:2:\"47\";i:12;s:2:\"12\";i:11;s:2:\"11\";i:10;s:2:\"10\";i:9;s:1:\"9\";i:8;s:1:\"8\";i:76;s:2:\"76\";i:123;s:3:\"123\";i:122;s:3:\"122\";i:72;s:2:\"72\";i:71;s:2:\"71\";i:70;s:2:\"70\";i:69;s:2:\"69\";i:62;s:2:\"62\";i:61;s:2:\"61\";i:60;s:2:\"60\";i:59;s:2:\"59\";i:57;s:2:\"57\";i:55;s:2:\"55\";i:49;s:2:\"49\";i:48;s:2:\"48\";i:75;s:2:\"75\";i:121;s:3:\"121\";i:120;s:3:\"120\";i:119;s:3:\"119\";i:73;s:2:\"73\";i:68;s:2:\"68\";i:67;s:2:\"67\";i:66;s:2:\"66\";i:65;s:2:\"65\";i:64;s:2:\"64\";i:63;s:2:\"63\";i:58;s:2:\"58\";i:56;s:2:\"56\";i:54;s:2:\"54\";i:53;s:2:\"53\";i:50;s:2:\"50\";i:46;s:2:\"46\";i:74;s:2:\"74\";i:41;s:2:\"41\";i:32;s:2:\"32\";i:42;s:2:\"42\";i:126;s:3:\"126\";i:125;s:3:\"125\";i:124;s:3:\"124\";i:112;s:3:\"112\";i:28;s:2:\"28\";i:78;s:2:\"78\";i:39;s:2:\"39\";i:38;s:2:\"38\";i:37;s:2:\"37\";i:36;s:2:\"36\";i:35;s:2:\"35\";i:45;s:2:\"45\";i:82;s:2:\"82\";i:2;s:1:\"2\";i:83;s:2:\"83\";i:4;s:1:\"4\";i:31;s:2:\"31\";i:24;s:2:\"24\";i:22;s:2:\"22\";i:21;s:2:\"21\";i:20;s:2:\"20\";i:19;s:2:\"19\";i:23;s:2:\"23\";i:6;s:1:\"6\";i:18;s:2:\"18\";i:17;s:2:\"17\";i:16;s:2:\"16\";i:15;s:2:\"15\";i:14;s:2:\"14\";i:13;s:2:\"13\";i:29;s:2:\"29\";i:27;s:2:\"27\";i:26;s:2:\"26\";i:25;s:2:\"25\";i:7;s:1:\"7\";i:5;s:1:\"5\";i:1;s:1:\"1\";i:158;s:3:\"158\";i:157;s:3:\"157\";i:156;s:3:\"156\";i:155;s:3:\"155\";i:116;s:3:\"116\";i:115;s:3:\"115\";i:87;s:2:\"87\";}s:8:\"contacts\";s:0:\"\";}}s:13:\"system_config\";a:4:{s:4:\"tree\";s:20:\"httpMiddlewareStacks\";s:11:\"regexSearch\";b:0;s:25:\"node_httpMiddlewareStacks\";a:1:{s:8:\"frontend\";i:1;}s:22:\"node_siteConfiguration\";a:5:{s:10:\"site_route\";i:1;s:18:\"site_route.columns\";i:1;s:24:\"site_route.columns.route\";i:1;s:16:\"site_route.types\";i:1;s:27:\"site_route.types.staticText\";i:1;}}s:16:\"browse_links.php\";a:1:{s:10:\"expandPage\";s:1:\"0\";}s:18:\"list/displayFields\";a:1:{s:32:\"tx_slubevents_domain_model_event\";a:2:{i:0;s:0:\"\";i:1;s:11:\"subscribers\";}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:0:{}s:5:\"tab_1\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:5:\"tab_1\";}s:8:\"web_info\";a:1:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:353:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":12:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:12:\"\0*\0timeFrame\";i:0;s:9:\"\0*\0action\";i:-1;s:14:\"\0*\0groupByPage\";b:0;s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:4:\"list\";a:4:{s:35:\"tx_slubevents_domain_model_category\";s:1:\"1\";s:34:\"tx_slubevents_domain_model_contact\";s:1:\"1\";s:37:\"tx_slubevents_domain_model_discipline\";s:1:\"1\";s:35:\"tx_slubevents_domain_model_location\";s:1:\"1\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1624367809;s:15:\"moduleSessionID\";a:13:{s:20:\"system_txschedulerM1\";s:40:\"133a2cd4e6aab401bc1ca3fd7ac6b409847a27c4\";s:10:\"web_layout\";s:40:\"3e2294dd0a13298c7ed85838b2c361ce1bd1328f\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"e49ed4003a309bd85d6c45dedc05fd504fd90641\";s:10:\"FormEngine\";s:40:\"e49ed4003a309bd85d6c45dedc05fd504fd90641\";s:8:\"web_list\";s:40:\"9d6de26df426b8447a37f0ce489ded07bba292e6\";s:9:\"file_list\";s:40:\"9d6de26df426b8447a37f0ce489ded07bba292e6\";s:6:\"web_ts\";s:40:\"e49ed4003a309bd85d6c45dedc05fd504fd90641\";s:16:\"opendocs::recent\";s:40:\"e49ed4003a309bd85d6c45dedc05fd504fd90641\";s:16:\"browse_links.php\";s:40:\"c348a45fe3bfc46fa42174a6200ef30b63861471\";s:18:\"list/displayFields\";s:40:\"2fcd7fdf919e98e013d389be5729a871352cd58e\";s:9:\"clipboard\";s:40:\"5c8b2619bb55c9fb7d61e1cf74d72fddbc6e1e05\";s:8:\"web_info\";s:40:\"60d07324a0d3989d371ea352564513d2d7892bd1\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"7aac53af4eb43a9b790eb97301f2a289ff7bc98f\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:7:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";s:3:\"0_5\";s:1:\"1\";s:3:\"0_7\";s:1:\"1\";s:4:\"0_10\";s:1:\"1\";s:4:\"0_13\";s:1:\"1\";s:4:\"0_15\";s:1:\"1\";}}}}s:10:\"inlineView\";s:954:\"a:3:{s:32:\"tx_slubevents_domain_model_event\";a:2:{i:7;a:1:{s:37:\"tx_slubevents_domain_model_subscriber\";a:1:{i:0;s:1:\"2\";}}i:16;a:1:{s:37:\"tx_slubevents_domain_model_subscriber\";a:1:{i:0;s:1:\"6\";}}}s:10:\"tt_content\";a:10:{s:25:\"NEW614c954618145125162816\";a:1:{s:10:\"tt_content\";a:1:{i:0;i:16;}}i:15;a:1:{s:10:\"tt_content\";a:3:{i:0;i:17;i:2;i:18;i:3;s:0:\"\";}}i:19;a:1:{s:10:\"tt_content\";a:4:{i:0;s:2:\"21\";i:1;i:23;i:2;s:2:\"22\";i:3;i:24;}}s:25:\"NEW614d8b0271ce8923714397\";a:1:{s:10:\"tt_content\";a:1:{i:0;i:26;}}i:25;a:1:{s:10:\"tt_content\";a:1:{i:0;s:2:\"26\";}}s:25:\"NEW614d8cdd33079136798279\";a:1:{s:10:\"tt_content\";a:1:{i:0;i:28;}}i:27;a:1:{s:10:\"tt_content\";a:1:{i:0;s:2:\"28\";}}s:25:\"NEW614d8d8f19d39493981058\";a:1:{s:10:\"tt_content\";a:1:{i:0;i:30;}}i:29;a:1:{s:10:\"tt_content\";a:4:{i:0;s:2:\"31\";i:1;i:33;i:2;i:36;i:3;s:0:\"\";}}i:40;a:1:{s:10:\"tt_content\";a:1:{i:2;s:2:\"39\";}}}s:4:\"site\";a:1:{i:1;a:1:{s:13:\"site_language\";a:2:{i:1;s:1:\"1\";i:2;s:1:\"0\";}}}}\";s:11:\"browseTrees\";a:1:{s:11:\"browsePages\";s:32:\"a:1:{i:0;a:2:{i:0;i:1;i:1;i:1;}}\";}s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1635327927}}\";}',NULL,NULL,1,'',0,NULL,1642085866,0,NULL,0,NULL),(2,0,1624366547,1624366547,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$S1FsZndMR2hGd1p6ZXZGdg$KsRi/viQL9ah3kcRzhjLilJx6R1Krz0EZOjfMNH7WDU',1,'','','',NULL,0,'',NULL,'','a:13:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1624366547;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL),(3,0,1624367286,1624367286,0,0,0,0,0,NULL,'admin2',0,'$argon2i$v=19$m=65536,t=16,p=1$NTlBQmE5eFJhaDRqeTNPMg$IONGEgQcl2qxNecQQtmiMo0RSn6CN3ezuCBmEa8L77k',1,'','','',NULL,0,'',NULL,'','a:14:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:4:{s:8:\"web_list\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"89494ca03c0d71614c20797c37296c5a\";a:4:{i:0;s:5:\"admin\";i:1;a:6:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"89494ca03c0d71614c20797c37296c5a\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1624367303;s:15:\"moduleSessionID\";a:4:{s:8:\"web_list\";s:40:\"13e4904a05c6d06cb32fb07089454107c4455592\";s:10:\"FormEngine\";s:40:\"13e4904a05c6d06cb32fb07089454107c4455592\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"13e4904a05c6d06cb32fb07089454107c4455592\";s:10:\"web_layout\";s:40:\"13e4904a05c6d06cb32fb07089454107c4455592\";}}',NULL,NULL,1,'',0,NULL,1624367303,0,NULL,0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cf_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_adminpanel_requestcache`
--

LOCK TABLES `cf_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cf_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_adminpanel_requestcache_tags`
--

LOCK TABLES `cf_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_hash`
--

DROP TABLE IF EXISTS `cf_cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_hash`
--

LOCK TABLES `cf_cache_hash` WRITE;
/*!40000 ALTER TABLE `cf_cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_hash_tags`
--

DROP TABLE IF EXISTS `cf_cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_hash_tags`
--

LOCK TABLES `cf_cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_imagesizes`
--

DROP TABLE IF EXISTS `cf_cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_imagesizes`
--

LOCK TABLES `cf_cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cf_cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cf_cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_imagesizes_tags`
--

LOCK TABLES `cf_cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pages`
--

DROP TABLE IF EXISTS `cf_cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pages`
--

LOCK TABLES `cf_cache_pages` WRITE;
/*!40000 ALTER TABLE `cf_cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pages_tags`
--

DROP TABLE IF EXISTS `cf_cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pages_tags`
--

LOCK TABLES `cf_cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pagesection`
--

DROP TABLE IF EXISTS `cf_cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pagesection`
--

LOCK TABLES `cf_cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cf_cache_pagesection` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cf_cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pagesection_tags`
--

LOCK TABLES `cf_cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_pagesection_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_rootline`
--

DROP TABLE IF EXISTS `cf_cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_rootline`
--

LOCK TABLES `cf_cache_rootline` WRITE;
/*!40000 ALTER TABLE `cf_cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_rootline_tags`
--

DROP TABLE IF EXISTS `cf_cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_rootline_tags`
--

LOCK TABLES `cf_cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_extbase_datamapfactory_datamap`
--

DROP TABLE IF EXISTS `cf_extbase_datamapfactory_datamap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_extbase_datamapfactory_datamap` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_extbase_datamapfactory_datamap`
--

LOCK TABLES `cf_extbase_datamapfactory_datamap` WRITE;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_extbase_datamapfactory_datamap_tags`
--

DROP TABLE IF EXISTS `cf_extbase_datamapfactory_datamap_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_extbase_datamapfactory_datamap_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_extbase_datamapfactory_datamap_tags`
--

LOCK TABLES `cf_extbase_datamapfactory_datamap_tags` WRITE;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_resolv_link_electronic`
--

DROP TABLE IF EXISTS `cf_resolv_link_electronic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_resolv_link_electronic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_resolv_link_electronic`
--

LOCK TABLES `cf_resolv_link_electronic` WRITE;
/*!40000 ALTER TABLE `cf_resolv_link_electronic` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_resolv_link_electronic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_resolv_link_electronic_tags`
--

DROP TABLE IF EXISTS `cf_resolv_link_electronic_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_resolv_link_electronic_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_resolv_link_electronic_tags`
--

LOCK TABLES `cf_resolv_link_electronic_tags` WRITE;
/*!40000 ALTER TABLE `cf_resolv_link_electronic_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_resolv_link_electronic_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_slubevents_category`
--

DROP TABLE IF EXISTS `cf_slubevents_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_slubevents_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_slubevents_category`
--

LOCK TABLES `cf_slubevents_category` WRITE;
/*!40000 ALTER TABLE `cf_slubevents_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_slubevents_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_slubevents_category_tags`
--

DROP TABLE IF EXISTS `cf_slubevents_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_slubevents_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_slubevents_category_tags`
--

LOCK TABLES `cf_slubevents_category_tags` WRITE;
/*!40000 ALTER TABLE `cf_slubevents_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_slubevents_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_tx_solr`
--

DROP TABLE IF EXISTS `cf_tx_solr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_tx_solr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_tx_solr`
--

LOCK TABLES `cf_tx_solr` WRITE;
/*!40000 ALTER TABLE `cf_tx_solr` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_tx_solr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_tx_solr_configuration`
--

DROP TABLE IF EXISTS `cf_tx_solr_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_tx_solr_configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_tx_solr_configuration`
--

LOCK TABLES `cf_tx_solr_configuration` WRITE;
/*!40000 ALTER TABLE `cf_tx_solr_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_tx_solr_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_tx_solr_configuration_tags`
--

DROP TABLE IF EXISTS `cf_tx_solr_configuration_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_tx_solr_configuration_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_tx_solr_configuration_tags`
--

LOCK TABLES `cf_tx_solr_configuration_tags` WRITE;
/*!40000 ALTER TABLE `cf_tx_solr_configuration_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_tx_solr_configuration_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_tx_solr_tags`
--

DROP TABLE IF EXISTS `cf_tx_solr_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_tx_solr_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_tx_solr_tags`
--

LOCK TABLES `cf_tx_solr_tags` WRITE;
/*!40000 ALTER TABLE `cf_tx_solr_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_tx_solr_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,14,1625148210,1625148210,1,0,0,'','0','Shibboleth','','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ses_anonymous` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
INSERT INTO `fe_sessions` VALUES ('85d01a8cc6b5beda3790a115e376a509','172.18',1,1642085941,'',0,0);
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (1,14,1625148323,1625148223,1,0,0,0,0,'','0','4998866','$argon2i$v=19$m=65536,t=16,p=1$RVRVUzF0cmNYOG1QRUdxUw$vWce5noqW9ocXQwY9jaV6ujxkBjRUALomWcGcdGd3ZE','1','Testnutzer DDEV','','','','','','','testnutzer@example.com','',NULL,'','','','','','','0','',1642085836,1642085941,'','');
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `alias` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `no_search_sub_entries` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `alias` (`alias`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `content_from_pid_deleted` (`content_from_pid`,`deleted`),
  KEY `doktype_no_search_deleted` (`doktype`,`no_search`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1624965283,1624960321,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'SLUB Webseite','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624965283,'','',0,'','','',0,0,0,0,'',0,0,'pagets__default','pagets__default','EXT:slub_template/Configuration/TsConfig/Page/All.tsconfig',0,0,'',0,0,'','',0,'','',0,'',0,0),(2,1,1624965487,1624960359,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Katalog','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624965487,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(3,2,1624961583,1624960919,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Mein Konto','/mein-konto',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624962256,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(4,0,1624965283,1624961658,1,0,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:13:\"SLUB Webseite\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:15:\"pagets__default\";s:25:\"backend_layout_next_level\";s:15:\"pagets__default\";s:17:\"tsconfig_includes\";s:58:\"EXT:slub_template/Configuration/TsConfig/Page/All.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'SLUB Webseite','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1624965283,NULL,'',0,'','','',0,0,0,0,'',0,0,'pagets__default','pagets__default','EXT:slub_template/Configuration/TsConfig/Page/All.tsconfig',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(5,2,1624961871,1624961867,1,0,0,0,0,'',128,'',0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Merkliste','/merkliste',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624962456,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(6,5,1626552943,1624961884,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:36:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'API','/merkliste/api',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1626552943,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(7,1,1624970145,1624967471,1,0,0,0,0,'',128,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Veranstaltungen','/veranstaltungen',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624970171,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(8,7,1624970151,1624967481,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Details','/veranstaltungen/details',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624970208,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(9,1,1624967513,1624967503,1,0,0,0,0,'',192,'',0,0,0,0,NULL,0,'a:13:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Event Folder','/event-folder',254,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,0,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(10,1,1624970067,1624970067,1,0,0,0,0,'',160,'',0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Meine Veranstaltungen','/meine-veranstaltungen',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624970302,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(11,10,1624970126,1624970091,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Anmelden','/meine-veranstaltungen/anmelden',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624970245,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(12,10,1624970132,1624970111,1,0,0,0,0,'',512,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Abmelden','/meine-veranstaltungen/abmelden',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1624970277,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(13,1,1625148937,1625147762,1,0,0,0,0,'',64,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Anmeldung','/anmeldung',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1632397379,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(14,13,1625147842,1625147815,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:46:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'SLUB User','/slub-user',254,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,0,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0),(15,13,1635515342,1632394470,1,0,0,0,0,'1',128,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:21:\"no_search_sub_entries\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Mein Bereich','/anmeldung/mein-bereich',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1638896552,NULL,'',0,'','','',0,0,0,0,'',0,0,'pagets__WebProfile','pagets__WebProfile',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(16,15,1633098066,1632406601,1,0,0,0,0,'1',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:21:\"no_search_sub_entries\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Meine Veranstaltungen','/anmeldung/mein-bereich/meine-veranstaltungen',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1636545593,NULL,'',0,'','','',0,0,0,0,'',0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(17,1,1633505846,1633505832,1,0,0,0,0,'',128,NULL,0,1,7,7,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"no_search_sub_entries\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:15:\"Veranstaltungen\";s:4:\"slug\";s:16:\"/veranstaltungen\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Events','/events',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1633505958,NULL,'',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(18,7,1633505981,1633505976,1,0,0,0,0,'',256,NULL,0,1,8,8,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"no_search_sub_entries\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Details\";s:4:\"slug\";s:24:\"/veranstaltungen/details\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Details','/events/details',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(19,1,1633512908,1633506204,1,0,0,0,0,'',192,NULL,0,1,9,9,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"no_search_sub_entries\":\"custom\"}',0,'a:28:{s:7:\"doktype\";i:254;s:5:\"title\";s:12:\"Event Folder\";s:4:\"slug\";s:13:\"/event-folder\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:21:\"no_search_sub_entries\";i:0;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Event Folder','/event-folder',254,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(20,13,1635515342,1633602422,1,0,0,0,0,'1',128,NULL,0,1,15,15,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"no_search_sub_entries\":\"parent\"}',0,'a:54:{s:7:\"doktype\";i:1;s:5:\"title\";s:12:\"Mein Bereich\";s:4:\"slug\";s:23:\"/anmeldung/mein-bereich\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:1:\"1\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:18:\"pagets__WebProfile\";s:25:\"backend_layout_next_level\";s:18:\"pagets__WebProfile\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;s:21:\"no_search_sub_entries\";i:0;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'My area','/anmeldung/my-area',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1635515342,NULL,'',0,'','','',0,0,0,0,'',0,0,'pagets__WebProfile','pagets__WebProfile','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(21,15,1633602577,1633602566,1,0,0,0,0,'1',256,NULL,0,1,16,16,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"no_search_sub_entries\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:21:\"Meine Veranstaltungen\";s:4:\"slug\";s:45:\"/anmeldung/mein-bereich/meine-veranstaltungen\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:1:\"1\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Booked events','/anmeldung/my-area/booked-events',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1633602611,NULL,'',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(22,1,1638894843,1638894787,1,0,0,0,0,'',96,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Hilfe zum Benutzerkonto','/hilfe-zum-benutzerkonto',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,'',0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0),(23,5,1642085888,1642085884,1,0,0,0,0,'',128,'',0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,1,32,31,31,0,'Merkliste Daten','/merkliste-daten',254,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,0,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `table_name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_domain`
--

DROP TABLE IF EXISTS `sys_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_domain` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `domainName` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `getSysDomain` (`hidden`),
  KEY `getDomainStartPage` (`pid`,`hidden`,`domainName`(100)),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_domain`
--

LOCK TABLES `sys_domain` WRITE;
/*!40000 ALTER TABLE `sys_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1624969565,1624969565,0,1,'1',0,'/user_upload/_temp_/importexport/slub-events-kategorien.xml','79d891ca6b1eddbcee93db441f05030ae4e11f54','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','slub-events-kategorien.xml','610fbef04fbaf17ae6c3215f6ac6a0577a1b8a4c',476002,1624969565,1624969565),(2,0,1624969928,1624969928,0,1,'1',0,'/user_upload/_temp_/importexport/slub-events-disciplines.xml','00490ef9376e3048ef7352c4e8c8da41cd0f7fb2','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','slub-events-disciplines.xml','8067d6c4896a2a331ecb8d22e45b6df352c6fc9f',93828,1624969928,1624969928),(3,0,1624970817,1624970817,0,1,'1',0,'/user_upload/_temp_/importexport/slub-events-orte.xml','cfa15c3dcf0a434e6138544d3cebb81d91646330','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','slub-events-orte.xml','48643beda216ac43ca5d27db8c50616c0ac40c8e',205292,1624970817,1624970817);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1624969565,1624969565,1,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0),(2,0,1624969928,1624969928,1,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,2,NULL,0,0,NULL,NULL,0),(3,0,1624970817,1624970817,1,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,3,NULL,0,0,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  `tx_slubtemplate_servicechapter` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1624367311,1624367311,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,0,1636450283,2,'BE',1,0,20,'tx_slubevents_domain_model_event','{\"oldRecord\":{\"title\":\"F\\u00fchrung durch die Corty Galerie\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"title\":\"Test Root\",\"l10n_diffsource\":\"a:25:{s:10:\\\"genius_bar\\\";N;s:5:\\\"title\\\";N;s:15:\\\"start_date_time\\\";N;s:7:\\\"all_day\\\";N;s:9:\\\"cancelled\\\";N;s:13:\\\"end_date_time\\\";N;s:8:\\\"location\\\";N;s:6:\\\"teaser\\\";N;s:11:\\\"description\\\";N;s:16:\\\"content_elements\\\";N;s:5:\\\"image\\\";N;s:7:\\\"contact\\\";N;s:21:\\\"external_registration\\\";N;s:14:\\\"min_subscriber\\\";N;s:14:\\\"max_subscriber\\\";N;s:10:\\\"max_number\\\";N;s:17:\\\"sub_end_date_time\\\";N;s:22:\\\"sub_end_date_info_sent\\\";N;s:8:\\\"audience\\\";N;s:10:\\\"categories\\\";N;s:10:\\\"discipline\\\";N;s:11:\\\"subscribers\\\";N;s:6:\\\"hidden\\\";N;s:12:\\\"onlinesurvey\\\";N;s:9:\\\"no_search\\\";N;}\"}}',0),(2,0,1636455279,1,'BE',1,0,42,'tt_content','{\"uid\":42,\"rowDescription\":\"\",\"pid\":16,\"tstamp\":1636455279,\"crdate\":1636455279,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":128,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"slubwebprofile_eventfilter\",\"header\":\"Filter f\\u00fcr Veranstaltungen\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"spaceBefore\":0,\"spaceAfter\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"100\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"tx_slubtemplate_testimonials\":0,\"tx_slubtemplate_factstables\":0,\"tx_slubtemplate_staticnewsbar\":0,\"tx_slubtemplate_teaseralignment\":0,\"tx_slubtemplate_teaserblur\":1,\"tx_slubtemplate_teaserbackgroundimage\":0,\"tx_slubtemplate_teaserlink\":0,\"irre_parent_uid\":0,\"irre_parent_table\":\"\",\"tt_content\":0,\"tx_slubevents_related_content\":0}',0),(3,0,1636455455,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(4,0,1636455526,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:19:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:6:\\\"layout\\\";N;s:11:\\\"frame_class\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(5,0,1636455578,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:19:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:6:\\\"layout\\\";N;s:11:\\\"frame_class\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(6,0,1636455585,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:12:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(7,0,1636545575,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"hidden\":0,\"l18n_diffsource\":\"a:12:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"hidden\":\"1\",\"l18n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(8,0,1636545593,2,'BE',1,0,42,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0),(9,0,1636645576,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\nplugin.tx_slubevents.settings.api.user.0.username = slub\\nplugin.tx_slubevents.settings.api.user.0.password = y8bYSJbL5kuB2vUhpd44\"}}',0),(10,0,1636645608,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\nplugin.tx_slubevents.settings.api.user.0.username = slub\\nplugin.tx_slubevents.settings.api.user.0.password = y8bYSJbL5kuB2vUhpd44\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.user.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.user.0.password = y8bYSJbL5kuB2vUhpd44\"}}',0),(11,0,1636647136,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.user.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.user.0.password = y8bYSJbL5kuB2vUhpd44\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"}}',0),(12,0,1636650932,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileServicexx\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"}}',0),(13,0,1636650946,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileServicexx\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"}}',0),(14,0,1636650976,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = y8bYSJbL5kuB2vUhpd44\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = 12345\"}}',0),(15,0,1636705895,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = profileService\\r\\nplugin.tx_slubevents.settings.api.users.0.password = 12345\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = username\\nplugin.tx_slubevents.settings.api.users.0.password = password\"}}',0),(16,0,1636706069,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = username\\nplugin.tx_slubevents.settings.api.users.0.password = password\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = \\nplugin.tx_slubevents.settings.api.users.0.password = \"}}',0),(17,0,1636706768,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = \\nplugin.tx_slubevents.settings.api.users.0.password = \"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = username\\nplugin.tx_slubevents.settings.api.users.0.password = password\"}}',0),(18,0,1636706794,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = username\\nplugin.tx_slubevents.settings.api.users.0.password = password\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = usernam\\nplugin.tx_slubevents.settings.api.users.0.password = password\"}}',0),(19,0,1636706809,2,'BE',1,0,3,'sys_template','{\"oldRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = usernam\\nplugin.tx_slubevents.settings.api.users.0.password = password\"},\"newRecord\":{\"constants\":\"config.rootPid = 1\\r\\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\\r\\nconfig.piwik_hostname = matomo.slub-dresden.de\\r\\nconfig.piwik_idsite = \\r\\nconfig.piwik_domains = \\r\\nplugin.tx_slubevents.persistence.storagePid = 9\\r\\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\\r\\nplugin.tx_slubevents.settings.api.users.0.username = username\\nplugin.tx_slubevents.settings.api.users.0.password = password\"}}',0),(20,0,1637852392,2,'BE',1,0,3,'tx_slubevents_domain_model_subscriber','{\"oldRecord\":{\"name\":\"Testnutzer DDEV\"},\"newRecord\":{\"name\":\"Testnutzer DDEV A\"}}',0),(21,0,1638889166,1,'BE',1,0,43,'tt_content','{\"uid\":43,\"rowDescription\":\"\",\"pid\":15,\"tstamp\":1638889166,\"crdate\":1638889166,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":0,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"slubwebprofile_userdetail\",\"header\":\"Benutzerkonto\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"spaceBefore\":0,\"spaceAfter\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"3\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"xmlTitle\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"tx_slubtemplate_testimonials\":0,\"tx_slubtemplate_factstables\":0,\"tx_slubtemplate_staticnewsbar\":0,\"tx_slubtemplate_teaseralignment\":0,\"tx_slubtemplate_teaserblur\":1,\"tx_slubtemplate_teaserbackgroundimage\":0,\"tx_slubtemplate_teaserlink\":0,\"irre_parent_uid\":0,\"irre_parent_table\":\"\",\"tt_content\":0,\"tx_slubevents_related_content\":0}',0),(22,0,1638891726,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"pages\":null,\"l18n_diffsource\":\"\"},\"newRecord\":{\"pages\":\"12\",\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:5:\\\"pages\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(23,0,1638892821,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"pages\":\"12\"},\"newRecord\":{\"pages\":\"10,12\"}}',0),(24,0,1638894759,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"pages\":\"10,12\"},\"newRecord\":{\"pages\":\"12\"}}',0),(25,0,1638894787,1,'BE',1,0,22,'pages','{\"uid\":22,\"pid\":1,\"tstamp\":1638894787,\"crdate\":1638894787,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":96,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":32,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Hilfe zum Benutzerkonto\",\"slug\":\"\\/hilfe-zum-benutzerkonto\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0,\"no_search_sub_entries\":0}',0),(26,0,1638894798,2,'BE',1,0,22,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:47:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:9:\\\"seo_title\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:11:\\\"description\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:21:\\\"no_search_sub_entries\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(27,0,1638894816,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"pages\":\"12\"},\"newRecord\":{\"pages\":\"12,22\"}}',0),(28,0,1638894821,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"pages\":\"12,22\"},\"newRecord\":{\"pages\":\"22,12\"}}',0),(29,0,1638894831,2,'BE',1,0,22,'pages','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"a:47:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:9:\\\"seo_title\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:11:\\\"description\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:21:\\\"no_search_sub_entries\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(30,0,1638894843,2,'BE',1,0,22,'pages','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0),(31,0,1638896381,2,'BE',1,0,30,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:14:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:15:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(32,0,1638896381,1,'BE',1,0,44,'tt_content','{\"uid\":44,\"rowDescription\":\"\",\"pid\":15,\"tstamp\":1638896381,\"crdate\":1638896381,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"slubwebprofile_borrowinglist\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"spaceBefore\":0,\"spaceAfter\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":999,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"3\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"tx_slubtemplate_testimonials\":0,\"tx_slubtemplate_factstables\":0,\"tx_slubtemplate_staticnewsbar\":0,\"tx_slubtemplate_teaseralignment\":0,\"tx_slubtemplate_teaserblur\":1,\"tx_slubtemplate_teaserbackgroundimage\":0,\"tx_slubtemplate_teaserlink\":0,\"irre_parent_uid\":0,\"irre_parent_table\":\"\",\"tt_content\":0,\"tx_slubevents_related_content\":0}',0),(33,0,1638896480,2,'BE',1,0,44,'tt_content','{\"oldRecord\":{\"header\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"fe_group\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Infos zu Ausleihe\",\"subheader\":\"Bevorstehende R\\u00fcckgaben:\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"fe_group\":\"1\",\"l18n_diffsource\":\"a:15:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(34,0,1638896494,2,'BE',1,0,43,'tt_content','{\"oldRecord\":{\"fe_group\":\"\"},\"newRecord\":{\"fe_group\":\"1\"}}',0),(35,0,1638896552,2,'BE',1,0,30,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:15:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(36,0,1638896552,2,'BE',1,0,44,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"a:15:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"l18n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(37,0,1638896552,1,'BE',1,0,45,'tt_content','{\"uid\":45,\"rowDescription\":\"\",\"pid\":15,\"tstamp\":1638896552,\"crdate\":1638896552,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":0,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"slubwebprofile_bookmarklist\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"spaceBefore\":0,\"spaceAfter\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":999,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"3\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"tx_slubtemplate_testimonials\":0,\"tx_slubtemplate_factstables\":0,\"tx_slubtemplate_staticnewsbar\":0,\"tx_slubtemplate_teaseralignment\":0,\"tx_slubtemplate_teaserblur\":1,\"tx_slubtemplate_teaserbackgroundimage\":0,\"tx_slubtemplate_teaserlink\":0,\"irre_parent_uid\":0,\"irre_parent_table\":\"\",\"tt_content\":0,\"tx_slubevents_related_content\":0}',0),(38,0,1638896600,2,'BE',1,0,45,'tt_content','{\"oldRecord\":{\"header\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"fe_group\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Letzte Suchanfragen\",\"subheader\":\"Aktueller Verlauf:\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.layout\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateFormat\\\">\\n                    <value index=\\\"vDEF\\\">Y-m-d<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeFormat\\\">\\n                    <value index=\\\"vDEF\\\">H:i<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.detailPageUid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"fe_group\":\"1\",\"l18n_diffsource\":\"a:15:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:11:\\\"pi_flexform\\\";N;s:12:\\\"sectionIndex\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(39,0,1642085884,1,'BE',1,0,23,'pages','{\"uid\":23,\"pid\":1,\"tstamp\":1642085884,\"crdate\":1642085884,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":32,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Merkliste Daten\",\"slug\":\"\\/merkliste-daten\",\"doktype\":254,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0,\"no_search_sub_entries\":0}',0),(40,0,1642085888,3,'BE',1,0,23,'pages','{\"oldPageId\":1,\"newPageId\":5,\"oldData\":{\"header\":\"Merkliste Daten\",\"pid\":1,\"event_pid\":23,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1642085888,\"pid\":5,\"sorting\":128}}',0),(41,0,1642085919,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:find\\/Configuration\\/TypoScript,EXT:slub_katalog_config\\/Configuration\\/TypoScript\\/Page,EXT:slub_katalog_config\\/Configuration\\/TypoScript\\/Plugin,EXT:slub_katalog_beta\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:find\\/Configuration\\/TypoScript,EXT:slub_katalog_config\\/Configuration\\/TypoScript\\/Page,EXT:slub_katalog_config\\/Configuration\\/TypoScript\\/Plugin,EXT:slub_find_bookmarks\\/Configuration\\/TypoScript,EXT:slub_katalog_beta\\/Configuration\\/TypoScript\"}}',0),(42,0,1642085938,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":null},\"newRecord\":{\"constants\":\"\\nplugin.tx_slubfindbookmarks_bookmarklist.persistence.storagePid = 23\\nplugin.tx_slubfindbookmarks_bookmarklist.settings.detailPagePid = 5\"}}',0);
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `static_lang_isocode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
INSERT INTO `sys_language` VALUES (1,0,1624960483,0,256,'English','en-us-gb','en',0);
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=617 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (2,3,1624367317,'be_users',1,0,'admin2',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1636381157,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(2,0,1636381244,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_test\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(3,0,1636381268,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(4,0,1636381710,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(5,0,1636381818,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(6,0,1636382242,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(7,0,1636382861,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(8,0,1636382866,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'',0,NULL,NULL),(9,0,1636382873,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'',0,NULL,NULL),(10,0,1636382876,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(11,0,1636382882,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(12,0,1636383094,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"probe\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(13,0,1636383118,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"cf_probe\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(14,0,1636383243,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(15,0,1636383245,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(16,0,1636383266,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(17,0,1636383516,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(18,0,1636383855,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(19,0,1636383947,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: An exception occurred while executing \'TRUNCATE `cf_hash`\':\n\nTable \'db.cf_hash\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php in line 61. Requested URL: https://ddev-slub-katalog.ddev.site/typo3/install.php?install[controller]=maintenance&install[context]=backend&install[action]=cacheClearAll&_=1636383061691',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(20,0,1636383988,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(21,0,1636384155,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(22,0,1636384372,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(23,0,1636384497,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(24,0,1636384510,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(25,0,1636384519,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(26,0,1636384572,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(27,0,1636384640,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(28,0,1636384748,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(29,0,1636384804,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1203699034: A cache with identifier \"slubevents_category\" does not exist. | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 139. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(30,0,1636386770,1,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: count(): Parameter must be an array or an object that implements Countable in /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php line 93',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(31,0,1636386770,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Return value of Slub\\SlubEvents\\Service\\EventService::findAllBySettings() must be of the type array, object returned | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 94. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(32,0,1636449546,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.9','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(33,0,1636450283,1,2,20,'tx_slubevents_domain_model_event',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:9:\"Test Root\";i:1;s:35:\"tx_slubevents_domain_model_event:20\";s:7:\"history\";s:1:\"1\";}',9,0,'','',0,'',0,NULL,NULL),(34,0,1636450718,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(35,0,1636455228,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(36,0,1636455279,1,1,42,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.9','a:4:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";i:2;s:21:\"Meine Veranstaltungen\";i:3;i:16;}',16,0,'NEW618a5353dbc21337052251','',0,'',0,NULL,NULL),(37,0,1636455452,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(38,0,1636455455,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"3\";}',16,0,'','',0,'',0,NULL,NULL),(39,0,1636455526,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"4\";}',16,0,'','',0,'',0,NULL,NULL),(40,0,1636455578,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"5\";}',16,0,'','',0,'',0,NULL,NULL),(41,0,1636455585,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"6\";}',16,0,'','',0,'',0,NULL,NULL),(42,0,1636456320,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1257246929: Tried resolving a template file for controller action \"Standard->EventFilter\" in format \".html\", but none of the paths contained the expected template file (Standard/EventFilter.html). The following paths were checked: /var/www/html/public/typo3/sysext/fluid_styled_content/Resources/Private/Templates/, /var/www/html/public/typo3conf/ext/slub_web_profile/Resources/Private/Templates/FluidStyledContent/, /var/www/html/public/typo3conf/ext/slub_template/Resources/Private/Plugins/FluidStyledContent/Templates/ | TYPO3Fluid\\Fluid\\View\\Exception\\InvalidTemplateResourceException thrown in file /var/www/html/vendor/typo3fluid/fluid/src/View/TemplatePaths.php in line 598. Requested URL: https://ddev-slub-katalog.ddev.site/anmeldung/mein-bereich/meine-veranstaltungen',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(43,0,1636456545,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(44,0,1636456810,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(45,0,1636456830,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'',0,NULL,NULL),(46,0,1636456836,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(47,0,1636456928,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(48,0,1636475969,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(49,0,1636542254,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.9','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(50,0,1636545575,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"7\";}',16,0,'','',0,'',0,NULL,NULL),(51,0,1636545593,1,2,42,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:27:\"Filter für Veranstaltungen\";i:1;s:13:\"tt_content:42\";s:7:\"history\";s:1:\"8\";}',16,0,'','',0,'',0,NULL,NULL),(52,0,1636633601,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(53,0,1636633617,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(54,0,1636636818,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(55,0,1636636940,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(56,0,1636636981,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(57,0,1636637079,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined function Slub\\SlubEvents\\Controller\\Api\\http_digest_parse() | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 71. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(58,0,1636637589,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.9','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(59,0,1636637593,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(60,0,1636637736,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/myext/Resources/JavaScript/my.js',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(61,0,1636645576,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:1:\"9\";}',1,0,'','',0,'',0,NULL,NULL),(62,0,1636645576,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(63,0,1636645608,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"10\";}',1,0,'','',0,'',0,NULL,NULL),(64,0,1636646391,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected \'$EXTENSION_NAME\' (T_VARIABLE) | ParseError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Authentication/ApiAuthentication.php in line 27. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(65,0,1636646405,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected \'$EXTENSION_NAME\' (T_VARIABLE) | ParseError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Authentication/ApiAuthentication.php in line 27. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(66,0,1636646420,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected \'$EXTENSION_NAME\' (T_VARIABLE) | ParseError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Authentication/ApiAuthentication.php in line 27. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(67,0,1636646425,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected \'$EXTENSION_NAME\' (T_VARIABLE) | ParseError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Authentication/ApiAuthentication.php in line 27. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(68,0,1636646698,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Class \'Slub\\SlubEvents\\Authentication\\ObjectManager\' not found | Error thrown in file /var/www/html/public/typo3/sysext/core/Classes/Utility/GeneralUtility.php in line 3692. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(69,0,1636647136,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"11\";}',1,0,'','',0,'',0,NULL,NULL),(70,0,1636648419,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function setVariablesToRender() on null | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 77. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(71,0,1636648424,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function setVariablesToRender() on null | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 77. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642&L=0',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(72,0,1636648465,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function setVariablesToRender() on null | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 77. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(73,0,1636648541,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function setVariablesToRender() on null | Error thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php in line 79. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(74,0,1636648730,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Return value of Slub\\SlubEvents\\Mvc\\View\\JsonView::transformValue() must be of the type array or null, string returned | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Mvc/View/JsonView.php in line 140. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982642',5,0,'172.18.0.9','',-1,0,'','',0,'',0,NULL,NULL),(75,0,1636650385,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(76,0,1636650509,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(77,0,1636650571,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(78,0,1636650932,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"12\";}',1,0,'','',0,'',0,NULL,NULL),(79,0,1636650946,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"13\";}',1,0,'','',0,'',0,NULL,NULL),(80,0,1636650976,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"14\";}',1,0,'','',0,'',0,NULL,NULL),(81,0,1636651000,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(82,0,1636705277,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.9','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(83,0,1636705363,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(84,0,1636705895,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"15\";}',1,0,'','',0,'',0,NULL,NULL),(85,0,1636705895,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(86,0,1636706069,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"16\";}',1,0,'','',0,'',0,NULL,NULL),(87,0,1636706069,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(88,0,1636706092,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(89,0,1636706768,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"17\";}',1,0,'','',0,'',0,NULL,NULL),(90,0,1636706768,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(91,0,1636706794,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"18\";}',1,0,'','',0,'',0,NULL,NULL),(92,0,1636706794,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(93,0,1636706809,1,2,3,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.9','a:3:{i:0;s:12:\"Slub Katalog\";i:1;s:14:\"sys_template:3\";s:7:\"history\";s:2:\"19\";}',1,0,'','',0,'',0,NULL,NULL),(94,0,1636706809,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(95,0,1636723668,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.9','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(96,0,1637312725,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(97,0,1637848511,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(98,0,1637851867,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/499886611/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(99,0,1637852000,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(100,0,1637852005,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(101,0,1637852182,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(102,0,1637852196,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(103,0,1637852199,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(104,0,1637852211,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(105,0,1637852256,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/499886611/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(106,0,1637852269,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(107,0,1637852318,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(108,0,1637852392,1,2,3,'tx_slubevents_domain_model_subscriber',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:17:\"Testnutzer DDEV A\";i:1;s:39:\"tx_slubevents_domain_model_subscriber:3\";s:7:\"history\";s:2:\"20\";}',9,0,'','',0,'',0,NULL,NULL),(109,0,1637852495,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(110,0,1637852585,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(111,0,1637852611,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(112,0,1637852725,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(113,0,1637852764,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(114,0,1637852768,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(115,0,1637852771,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(116,0,1637853345,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/0/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(117,0,1637853485,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(118,0,1637853567,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(119,0,1637853600,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/0/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(120,0,1637853734,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/0/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(121,0,1637853790,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(122,0,1637854429,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to Slub\\SlubEvents\\Service\\EventService::prepareForUser() must be of the type int, null given, called in /var/www/html/public/typo3conf/ext/slub_events/Classes/Controller/Api/EventController.php on line 114 | TypeError thrown in file /var/www/html/public/typo3conf/ext/slub_events/Classes/Service/EventService.php in line 74. Requested URL: https://ddev-slub-katalog.ddev.site/?type=1452982643&L=0&tx_slubevents_apieventlistuser%%5Buser%%5D=0',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(123,0,1637854765,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/49988661/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(124,0,1638799162,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(125,0,1638884467,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(126,0,1638885298,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(127,0,1638889166,1,1,43,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.7','a:4:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";i:2;s:12:\"Mein Bereich\";i:3;i:15;}',15,0,'NEW61af76ac6483e939535078','',0,'',0,NULL,NULL),(128,0,1638889209,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(129,0,1638890242,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-slub-katalog.ddev.site/libero/core/1234998866/index.json',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(130,0,1638891516,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(131,0,1638891656,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(132,0,1638891726,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"22\";}',15,0,'','',0,'',0,NULL,NULL),(133,0,1638892170,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected \')\', expecting \']\' | ParseError thrown in file /var/www/html/public/typo3conf/ext/slub_web_profile/Classes/Controller/UserController.php in line 42. Requested URL: https://ddev-slub-katalog.ddev.site/anmeldung/mein-bereich',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(134,0,1638892717,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: special.value.field | InvalidArgumentException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/DataProcessing/MenuProcessor.php in line 285. Requested URL: https://ddev-slub-katalog.ddev.site/anmeldung/mein-bereich',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(135,0,1638892821,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"23\";}',15,0,'','',0,'',0,NULL,NULL),(136,0,1638893261,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Argument 1 passed to TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor::process() must be an instance of TYPO3\\CMS\\Frontend\\ContentObject\\ContentObjectRenderer, array given, called in /var/www/html/public/typo3conf/ext/slub_web_profile/Classes/Controller/UserController.php on line 64 | TypeError thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/DataProcessing/MenuProcessor.php in line 416. Requested URL: https://ddev-slub-katalog.ddev.site/anmeldung/mein-bereich',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(137,0,1638893612,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor::process(), 3 passed in /var/www/html/public/typo3conf/ext/slub_web_profile/Classes/Controller/UserController.php on line 57 and exactly 4 expected | ArgumentCountError thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/DataProcessing/MenuProcessor.php in line 416. Requested URL: https://ddev-slub-katalog.ddev.site/anmeldung/mein-bereich',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(138,0,1638894527,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(139,0,1638894759,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"24\";}',15,0,'','',0,'',0,NULL,NULL),(140,0,1638894787,1,1,22,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.7','a:4:{i:0;s:23:\"Hilfe zum Benutzerkonto\";i:1;s:8:\"pages:22\";i:2;s:13:\"SLUB Webseite\";i:3;i:1;}',1,0,'NEW_1','',0,'',0,NULL,NULL),(141,0,1638894798,1,2,22,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:23:\"Hilfe zum Benutzerkonto\";i:1;s:8:\"pages:22\";s:7:\"history\";s:2:\"26\";}',22,0,'','',0,'',0,NULL,NULL),(142,0,1638894816,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"27\";}',15,0,'','',0,'',0,NULL,NULL),(143,0,1638894821,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"28\";}',15,0,'','',0,'',0,NULL,NULL),(144,0,1638894831,1,2,22,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:23:\"Hilfe zum Benutzerkonto\";i:1;s:8:\"pages:22\";s:7:\"history\";s:2:\"29\";}',22,0,'','',0,'',0,NULL,NULL),(145,0,1638894843,1,2,22,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:23:\"Hilfe zum Benutzerkonto\";i:1;s:8:\"pages:22\";s:7:\"history\";s:2:\"30\";}',22,0,'','',0,'',0,NULL,NULL),(146,0,1638894846,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(147,0,1638896381,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(148,0,1638896381,1,2,30,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:21:\"Meine Veranstaltungen\";i:1;s:13:\"tt_content:30\";s:7:\"history\";s:2:\"31\";}',15,0,'','',0,'',0,NULL,NULL),(149,0,1638896381,1,1,44,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.7','a:4:{i:0;s:10:\"[No title]\";i:1;s:13:\"tt_content:44\";i:2;s:12:\"Mein Bereich\";i:3;i:15;}',15,0,'NEW61af92eecffac006599902','',0,'',0,NULL,NULL),(150,0,1638896381,1,2,40,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:40\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(151,0,1638896381,1,2,39,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"My events\";i:1;s:13:\"tt_content:39\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(152,0,1638896381,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(153,0,1638896480,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(154,0,1638896480,1,2,30,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:21:\"Meine Veranstaltungen\";i:1;s:13:\"tt_content:30\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(155,0,1638896480,1,2,44,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:17:\"Infos zu Ausleihe\";i:1;s:13:\"tt_content:44\";s:7:\"history\";s:2:\"33\";}',15,0,'','',0,'',0,NULL,NULL),(156,0,1638896480,1,2,40,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:40\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(157,0,1638896480,1,2,39,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"My events\";i:1;s:13:\"tt_content:39\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(158,0,1638896494,1,2,43,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:13:\"Benutzerkonto\";i:1;s:13:\"tt_content:43\";s:7:\"history\";s:2:\"34\";}',15,0,'','',0,'',0,NULL,NULL),(159,0,1638896552,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(160,0,1638896552,1,2,30,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:21:\"Meine Veranstaltungen\";i:1;s:13:\"tt_content:30\";s:7:\"history\";s:2:\"35\";}',15,0,'','',0,'',0,NULL,NULL),(161,0,1638896552,1,2,44,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:17:\"Infos zu Ausleihe\";i:1;s:13:\"tt_content:44\";s:7:\"history\";s:2:\"36\";}',15,0,'','',0,'',0,NULL,NULL),(162,0,1638896552,1,1,45,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.7','a:4:{i:0;s:10:\"[No title]\";i:1;s:13:\"tt_content:45\";i:2;s:12:\"Mein Bereich\";i:3;i:15;}',15,0,'NEW61af93a117479499495358','',0,'',0,NULL,NULL),(163,0,1638896552,1,2,40,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:40\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(164,0,1638896552,1,2,39,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"My events\";i:1;s:13:\"tt_content:39\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(165,0,1638896552,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(166,0,1638896600,1,2,29,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:29\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(167,0,1638896600,1,2,30,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:21:\"Meine Veranstaltungen\";i:1;s:13:\"tt_content:30\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(168,0,1638896600,1,2,44,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:17:\"Infos zu Ausleihe\";i:1;s:13:\"tt_content:44\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(169,0,1638896600,1,2,45,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:19:\"Letzte Suchanfragen\";i:1;s:13:\"tt_content:45\";s:7:\"history\";s:2:\"38\";}',15,0,'','',0,'',0,NULL,NULL),(170,0,1638896600,1,2,40,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Dashboard\";i:1;s:13:\"tt_content:40\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(171,0,1638896600,1,2,39,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"My events\";i:1;s:13:\"tt_content:39\";s:7:\"history\";i:0;}',15,0,'','',0,'',0,NULL,NULL),(172,0,1638953728,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(173,0,1642085866,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(174,0,1642085884,1,1,23,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.6','a:4:{i:0;s:15:\"Merkliste Daten\";i:1;s:8:\"pages:23\";i:2;s:13:\"SLUB Webseite\";i:3;i:1;}',1,0,'NEW61e03df47e02f738029915','',0,'',0,NULL,NULL),(175,0,1642085888,1,4,23,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,2,'172.18.0.6','a:4:{i:0;s:15:\"Merkliste Daten\";i:1;s:8:\"pages:23\";i:2;s:9:\"Merkliste\";i:3;i:5;}',1,0,'','',0,'',0,NULL,NULL),(176,0,1642085888,1,4,23,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,3,'172.18.0.6','a:4:{i:0;s:15:\"Merkliste Daten\";i:1;s:8:\"pages:23\";i:2;s:13:\"SLUB Webseite\";i:3;i:1;}',5,0,'','',0,'',0,NULL,NULL),(177,0,1642085919,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"41\";}',2,0,'','',0,'',0,NULL,NULL),(178,0,1642085938,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"42\";}',2,0,'','',0,'',0,NULL,NULL),(179,0,1642085938,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(180,0,1642085975,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1470230766: Data too long for column \'author\' at row 1 | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Storage\\Exception\\SqlErrorException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Generic/Storage/Typo3DbBackend.php in line 151. Requested URL: https://katalog.ddev.site/merkliste/api/?tx_slubfindbookmarks_bookmarklist[controller]=BookmarkList&type=1469315139&tx_slubfindbookmarks_bookmarklist[action]=addBookmark&tx_slubfindbookmarks_bookmarklist[recordid]=dswarm-126-ZnRzdWJnZ2VvOm9haTplLWRvY3MuZ2VvLWxlby5kZToxMTg1OC84Mzc5&tx_slubfindbookmarks_bookmarklist[title]=Variscan%%20ultra%%E2%%80%%90high%%E2%%80%%90pressure%%20eclogite%%20in%%20the%%20Upper%%20Allochthon%%20of%%20the%%20Rhodope%%20Metamorphic%%20Complex%%20(Bulgaria)&tx_slubfindbookmarks_bookmarklist[author]=Trapp,%%20Svenja;%%20Jan%%C3%%A1k,%%20Marian;%%20Fassmer,%%20Kathrin;%%20Froitzheim,%%20Nikolaus;%%20M%%C3%%BCnker,%%20Carsten;%%20Georgiev,%%20Neven%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20;%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20%%20Jan%%C3%%A1k,%%20Marian;%%202Earth%%20Science%%20Institute%%20Slovak%%20Academy%%20of%%20Sciences%%20Bratislava%%20Slovak%%20Republic;%%20Fassmer,%%20Kathrin;%%201Institute%%20of%%20Geosciences%%20University%%20of%%20Bonn%%20Bonn%%20Germany;%%20Froitzheim,%%20Nikolaus;%%201Institute%%20of%%20Geosciences%%20University%%20of%%20Bonn%%20Bonn%%20Germany;%%20M%%C3%%BCnker,%%20Carsten;%%203Institute%%20of%%20Geology%%20and%%20Mineralogy%%20University%%20of%%20Cologne%%20Cologne%%20Germany;%%20Georgiev,%%20Neven;%%204Department%%20of%%20Geology%%20and%%20Paleontology%%20Sofia%%20University%%20%%22St.%%20Kliment%%20Ohridski%%22%%20Sofia%%20Bulgaria&tx_slubfindbookmarks_bookmarklist[imprint]=GEO-LEOe-docs%%20(FID%%20GEO),%%202021&tx_slubfindbookmarks_bookmarklist[series]=&tx_slubfindbookmarks_bookmarklist[format]=Article,%%20E-Article',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(181,0,1642085993,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdby` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_path` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('0092202637b57cbcef02874be021240e','tx_slubevents_domain_model_category',91,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',93,''),('00e72e4ad17d90a131b20111cda557d8','tt_content',12,'pi_flexform','additional/lDEF/settings.listPageUid/vDEF/','','',0,1,0,'pages',16,''),('011c891ca76c3df61b1099a8379f28d5','tx_slubevents_domain_model_event',12,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('03bbb72f541f4fcade57d2474cfeb206','tx_slubevents_domain_model_location',13,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('048283440bd111fee907c1033d5f0ab3','tx_slubevents_domain_model_event',16,'location','','','',0,0,0,'tx_slubevents_domain_model_location',73,''),('04d8cfada0f64d61cf2fe441862145e6','tx_slubevents_domain_model_category',165,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',159,''),('054327fe83a8f63a985936705bed5e85','tt_content',44,'fe_group','','','',0,0,0,'fe_groups',1,''),('0579dc2e2727216cb9ab32e797096b83','tx_slubevents_domain_model_category',29,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('0605b158f8ccef3ba5ac3c13a4ae0595','sys_template',1,'config','','url','2',-1,0,0,'_STRING',0,'https://katalog.ddev.site/mein-konto'),('06b2d3c78bb27b80e3270089e50d8690','pages',20,'l10n_parent','','','',0,0,0,'pages',15,''),('06c92024bb40ca832aeef13033fd9e01','tx_slubevents_domain_model_category',38,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',78,''),('076b14c419c36553658ee90f1e8ae5bb','tx_slubevents_domain_model_category',51,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('078d2b39dd186464df5c051067b4a1ff','tt_content',5,'pi_flexform','sDEF/lDEF/settings.pidSubscribeForm/vDEF/','','',0,0,0,'pages',11,''),('0c61171991c858f23866c5a5eb274851','tx_slubevents_domain_model_location',55,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('0cec361dc7236fc8b4027f0d2d62016d','tx_slubevents_domain_model_category',116,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('0cedfc8a4de1ddb06fc8290f1441de1e','tx_slubevents_domain_model_category',107,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('0d46f7acfb4e3d18dfa08efb7d745505','tx_slubevents_domain_model_discipline',30,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('0d8639172bfe94c59f0c44443a912a13','tx_slubevents_domain_model_event',7,'subscribers','','','',0,0,0,'tx_slubevents_domain_model_subscriber',2,''),('0e6c282ecc4f430cc18386fa15ff5807','tx_slubevents_domain_model_category',74,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('0fe9f0d7433b135feb37d88e65e2770a','tx_slubevents_domain_model_category',115,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('1003da860b3e813677bbb1591fc68459','tx_slubevents_domain_model_discipline',26,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',34,''),('10c77e37f7c3969545037d8a4ef7c957','tx_slubevents_domain_model_discipline',19,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('10d2e96630e70031a2fcec6d8e62dde5','tt_content',22,'pi_flexform','additional/lDEF/settings.listPageUid/vDEF/','','',0,1,0,'pages',16,''),('10ef35bb10af0a32d7cae18091ae1ca5','tx_slubevents_domain_model_category',57,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('1222d12a6f5b4124a36723f9a018fd54','tx_slubevents_domain_model_category',132,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',94,''),('12a9bfec1df6bdd412ee067e7ccf578b','tt_content',38,'pi_flexform','sDEF/lDEF/settings.pidListing/vDEF/','','',0,0,0,'pages',7,''),('138b3fae93ea57a7b876b08042514e28','tx_slubevents_domain_model_category',151,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('13c645b2f636c02a1b56a56c3326cbac','tx_slubevents_domain_model_discipline',6,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('15beb0d9132dd621d93a4444b4d50fa2','tx_slubevents_domain_model_location',57,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('1618f840502ed2055cf7fd47ed30df01','tt_content',40,'l18n_parent','','','',0,0,0,'tt_content',29,''),('16bd8bd3e5a5f6255b7247d3022e3497','tx_slubevents_domain_model_category',47,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('17357e4d7b8749ead1e470660b1541d7','tx_slubevents_domain_model_category',18,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',31,''),('17362d27845bbf3685fed44cc1844bcc','tx_slubevents_domain_model_location',23,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('18510074258b0d46672b884b54dc1120','tx_slubevents_domain_model_category',21,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',24,''),('187222cfe478d5aa48f3c5c4db01b67b','pages',21,'l10n_parent','','','',0,0,0,'pages',16,''),('191572d9370a6c172134d4785904bd0f','tx_slubevents_domain_model_category',5,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('1a5864d68c57276db96f380c1e19f596','tx_slubevents_domain_model_location',39,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('1bd887ab03c5d40f8c4805865c942c99','tx_slubevents_domain_model_discipline',24,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('1c329a418d54c0fbb66c84e3966ac5ed','tt_content',4,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',1,0,0,'tx_slubevents_domain_model_category',94,''),('1c66e0a0090ff1c75c9be46f97f8ef87','tx_slubevents_domain_model_location',53,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('1f90a61fa27778c70246087856e49163','tx_slubevents_domain_model_category',76,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('20378d27451a38c079b8af2f39e7b6b6','tx_slubevents_domain_model_event',7,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('216a24887eae22c7000a3bc647cd7217','tx_slubevents_domain_model_discipline',11,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',33,''),('2203363356d55ddbe697be4a2965697a','tx_slubevents_domain_model_category',137,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',134,''),('2364547b586a1e600a19140be9a85abb','tx_slubevents_domain_model_category',96,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('24ddc30ae34f66427ce9b3466690b4f2','tt_content',4,'pi_flexform','sDEF/lDEF/settings.pidSubscribeForm/vDEF/','','',0,0,0,'pages',11,''),('2571f25c2ac4c8b085261345e71ff13e','tx_slubevents_domain_model_location',25,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('25a3f371d8a4204728a16168f95343f1','tx_slubevents_domain_model_category',153,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('25ba9adb5b8dd6229a29ea121a296b7e','tx_slubevents_domain_model_category',28,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',112,''),('25f7f6ec7d4f69341e7960b5f0937e3c','tx_slubevents_domain_model_category',62,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('26a9a6ed9b1daa804914b43e19f150a3','tx_slubevents_domain_model_category',95,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('27d0d7b6d28b4698babdf243afb3c807','tt_content',8,'pi_flexform','sDEF/lDEF/settings.pidUnsubscribeForm/vDEF/','','',0,0,0,'pages',12,''),('283dd6ef25fc9cfe1b55dbb2a7556b86','tx_slubevents_domain_model_event',10,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('29786913e7317096b03675fbd69162fa','tx_slubevents_domain_model_category',19,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',24,''),('298d557bcc1c19727e5f1668588f3149','tx_slubevents_domain_model_location',19,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('29f55828e34d0976e1ff41693b89936e','tx_slubevents_domain_model_event',1,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('2ae1761357d3700137632d0d8c6a4a4a','tx_slubevents_domain_model_category',45,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('2ae606910fff13c2fe253ab884824462','tx_slubevents_domain_model_location',9,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('2bbd8d867dc81ad480f327ca1edbfc2b','tx_slubevents_domain_model_location',44,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',45,''),('2c15ae5ad7f67bd19b6f9393bb6ad142','tt_content',38,'l18n_parent','','','',0,0,0,'tt_content',5,''),('2d2bc370df7c9b7bdcc7b5a317e83b0e','tt_content',43,'fe_group','','','',0,0,0,'fe_groups',1,''),('2e084bd04c8118b77668fb6c9f1eec18','tx_slubevents_domain_model_discipline',18,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('2e5cabf44422919928a636df97bff461','tx_slubevents_domain_model_location',14,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('2f129011a721e0d61d2d84a4a0a66922','tx_slubevents_domain_model_category',84,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',79,''),('2f5758b18a09a26cd186899c2d6c08e1','sys_template',2,'config','','url','2',-1,0,0,'_STRING',0,'https://katalog.ddev.site/'),('2f60514a1b45030f2be6ae2cbbb6538f','tx_slubevents_domain_model_category',48,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('3077f08e694029adc1f23493bfda6726','sys_template',2,'config','','url','7',-1,0,0,'_STRING',0,'https://ddev-slub-katalog.ddev.site/anmeldung'),('30e9e315b46111bcc00d42beeca44541','tx_slubevents_domain_model_discipline',27,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('31d70d0d1f4a66a86f65414c5dd03125','tx_slubevents_domain_model_category',17,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',18,''),('31dd563cd17a825a7f72eeffe441a385','tx_slubevents_domain_model_category',93,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',109,''),('32b266aae596aa4b288c1b80eb543934','tx_slubevents_domain_model_event',10,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('333eeb0a78d2eb89fc5d6a2ec182a161','tx_slubevents_domain_model_location',49,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('341fbcc681cc4d65b9b9af9a38e5f8b3','tt_content',41,'pi_flexform','additional/lDEF/settings.detailPageUid/vDEF/','','',0,0,0,'pages',8,''),('34eb8137fe0163468a19745ba2267dc5','tx_slubevents_domain_model_category',13,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',31,''),('35a3200d632486e75930ee7920965a52','tx_slubevents_domain_model_category',160,'l10n_parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('35abd107d217e307758a5eb7fbb2b724','tx_slubevents_domain_model_category',122,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('363e7e8ae6ad1915d48d8bc8fb9d484d','tx_slubevents_domain_model_category',4,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',2,''),('37881882722c4249f572c334d56184a6','tx_slubevents_domain_model_discipline',21,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('389014d3622ca586d071b266cc1b3a27','tx_slubevents_domain_model_category',43,'l10n_parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('38b3f4ced12834671bacd666fade59d0','tx_slubevents_domain_model_location',66,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',59,''),('38d702f4d48a6c7e8d5710829e29a980','tt_content',9,'pi_flexform','sDEF/lDEF/pages/vDEF/','','',0,0,0,'pages',14,''),('38e202e708370d6f0c8e3f42abe1bfbf','tx_slubevents_domain_model_category',133,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',159,''),('397fc8ae2e778b10775e9efab50c378e','tx_slubevents_domain_model_category',27,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('3a099cb9fbeb47752edd5d43557fd1f6','tx_slubevents_domain_model_category',52,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('3b0e810a350915a10236577422f3d069','tx_slubevents_domain_model_category',24,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',31,''),('3b3aa40843a9008e6efac150f3b08606','tx_slubevents_domain_model_category',120,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('3c56cf3f2ef524a6f5c751b3bb340c88','tx_slubevents_domain_model_event',2,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('3db248818ff16a72158598a8c0176f5d','tx_slubevents_domain_model_category',55,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('3eed7034939bd6640c7ea509b7506c7e','tx_slubevents_domain_model_discipline',1,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',33,''),('401b19fc0796b63b304c191358407005','tx_slubevents_domain_model_category',30,'l10n_parent','','','',0,0,0,'tx_slubevents_domain_model_category',31,''),('4043baeab529b29945111d5c5a862f88','pages',20,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('4193fe4c424ea2bd6460a46c0c9536ae','tx_slubevents_domain_model_location',58,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',59,''),('41fe24ecec79563ab304566caac1d6a4','tx_slubevents_domain_model_category',147,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('42e27c10cf17bf32705bbef84fc5c7a6','tx_slubevents_domain_model_discipline',28,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',34,''),('43f48453be1fa2aa832db618a20d82fe','tx_slubevents_domain_model_event',7,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('449f604fd908c6f97a952a60c58ce2ed','tx_slubevents_domain_model_category',163,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',134,''),('44a5043621dd094b4275111f523d3e5c','tx_slubevents_domain_model_location',21,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('45becdea2fe0e2e8e5b3c2955c947e09','tx_slubevents_domain_model_location',51,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('463ccfc8b30987e55bd70144e480a519','tx_slubevents_domain_model_event',13,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('47208ad105363fd118a89e880859a658','tx_slubevents_domain_model_location',8,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('4817bfc75d25a205e0046ee0345bbff4','tx_slubevents_domain_model_discipline',2,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('4859e1934681e3e6d44815dacb6d6ef1','tx_slubevents_domain_model_category',125,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',126,''),('486c0f645d88d9562a48eca67bde9de1','tt_content',37,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',1,0,0,'tx_slubevents_domain_model_category',94,''),('49108be7a01c1a7e982317b7520a7331','tx_slubevents_domain_model_category',9,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('4a53c6e4b991d0b6204c65e2680b3825','tx_slubevents_domain_model_category',97,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('4ade79b4d056380bb62bb74236c9819e','tx_slubevents_domain_model_category',36,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',78,''),('4c2a78d8309a9496ef5521bfdd2cc283','tx_slubevents_domain_model_category',169,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',159,''),('4ceb403bc674a18926ff0c922f8d77dc','tx_slubevents_domain_model_discipline',12,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',34,''),('4d2bbbb975491fbe5d49c1e40c25543f','tx_slubevents_domain_model_category',128,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',93,''),('4d553917eaea315fb9fd650236cbc0ab','tx_slubevents_domain_model_location',22,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('4e17e5ed0d9c8e9e914e939209d7404c','tx_slubevents_domain_model_event',20,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('4eaef045242953e24a908d894ade4087','tx_slubevents_domain_model_category',46,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('51e21b62acdf5f43789fd1b4837c6329','tx_slubevents_domain_model_category',164,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('5321ff42bd2d7739a4359f7be135b83a','pages',17,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('536effa273373db387a87466262041df','tx_slubevents_domain_model_event',26,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',9,''),('539f8f2336228530ec46069e185ac97a','tx_slubevents_domain_model_category',31,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('558dfd9552ed387f99d162230232c458','tx_slubevents_domain_model_category',58,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('56c24bdcfbf1e710d9551bcb1dacf07e','tx_slubevents_domain_model_location',54,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('573c6696fee167e4855b684f61f5e3a8','tt_content',40,'tt_content','','','',0,0,0,'tt_content',39,''),('5803bf2542625f87af2ebd753ed9ca41','tx_slubevents_domain_model_category',30,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('584dc1cc5d262d0c6e244ed852c7959e','sys_template',2,'config','','url','12',-1,0,0,'_STRING',0,'https://ddev-slub-katalog.ddev.site/libero/'),('59184949bfb1f27d3d820b845d15375a','tx_slubevents_domain_model_location',73,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',59,''),('5946aea1239817ba51f9b2c273853ba4','tt_content',21,'pi_flexform','additional/lDEF/settings.listPageUid/vDEF/','','',0,1,0,'pages',16,''),('59933f6c1ab467d8f6144de542ee9b3f','tx_slubevents_domain_model_location',75,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',36,''),('59c41b9f1d5338d9417c9b6817e2c542','sys_file',2,'storage','','','',0,0,0,'sys_file_storage',1,''),('5b7fddd2e266eb9afccc59411322e33b','tx_slubevents_domain_model_category',41,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',74,''),('5b8fa114fa223b0fab4b6b34e2c646d8','tx_slubevents_domain_model_event',7,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('5e3df262dc6bc4df031f65cdad104354','pages',17,'l10n_parent','','','',0,0,0,'pages',7,''),('602d5f21b69094230b4db35b3b8b66e5','tx_slubevents_domain_model_category',66,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('60d15a31ed94ab3d9e085b99b9dc58fe','tx_slubevents_domain_model_event',10,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('63961773ae4f769925ad178ea7670648','tx_slubevents_domain_model_category',80,'l10n_parent','','','',0,0,0,'tx_slubevents_domain_model_category',81,''),('64b13aee43b3871b4592ce2110985fdf','tx_slubevents_domain_model_category',142,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('65c9f027e4f910e64f68bae9f62c1dce','tx_slubevents_domain_model_location',33,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('662436671900f78c21af8828e4338e2a','tt_content',37,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',2,0,0,'tx_slubevents_domain_model_category',1,''),('663b50af981cada32caeee39277fbaf4','tx_slubevents_domain_model_category',130,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',109,''),('664bfa2e7dce44cec7d0c028b36f7767','tx_slubevents_domain_model_event',16,'categories','','','',1,0,0,'tx_slubevents_domain_model_category',158,''),('6681e4c8835f29a0f4c40b054c9fc0da','tx_slubevents_domain_model_event',13,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('66d816e4f5536dcdfaffbb73f952c232','tx_slubevents_domain_model_event',13,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('6706ef0f6e60f0699ff8825441bb610f','tx_slubevents_domain_model_discipline',7,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('68f2729dedffbf5f958076239e482fbb','tx_slubevents_domain_model_discipline',10,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('6a45091cc0e8d3cc84fa8254805c2651','tx_slubevents_domain_model_event',16,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('6a6e302a9c7f8449acabf1c58ebf3a8e','tt_content',41,'l18n_parent','','','',0,0,0,'tt_content',34,''),('6afbf28156cc999f0d13306e1fca84b8','tt_content',29,'tt_content','','','',2,0,0,'tt_content',45,''),('6c61d02187a06e9d62ea8da0450c8db8','tx_slubevents_domain_model_location',76,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',36,''),('6d8dd4d25acea4f3298f73c6e0249df5','tx_slubevents_domain_model_category',65,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('6e0b098cfc5b1d2c4aed1ef25e8fa0bf','tx_slubevents_domain_model_location',31,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('6f16f70222ee9f7441b1eab725bdc025','tx_slubevents_domain_model_category',82,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',45,''),('6f1f1a498b1a6e17037343f6eeaa501f','tx_slubevents_domain_model_discipline',37,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('714fb794f5050f784c7e9bdbe508dd2a','tx_slubevents_domain_model_event',10,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('72dfa3ad0217e9aa37606c7b60dfe389','tx_slubevents_domain_model_event',12,'subscribers','','','',0,0,0,'tx_slubevents_domain_model_subscriber',3,''),('7361ff471762c1141d6ae2b14092f129','tt_content',6,'pi_flexform','sDEF/lDEF/settings.pidListOwn/vDEF/','','',0,0,0,'pages',10,''),('757054e50af4c1384fa128a222d9913f','tt_content',5,'pi_flexform','sDEF/lDEF/settings.pidListing/vDEF/','','',0,0,0,'pages',7,''),('75f39bf100dfac33cd07aae0e439f3d6','tt_content',39,'l18n_parent','','','',0,0,0,'tt_content',30,''),('7617d9cfd68b6f028502c1177bf414ca','tx_slubevents_domain_model_category',37,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',78,''),('76d377941f2daeec565bdc5373d75b8f','tx_slubevents_domain_model_location',11,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('77917fda065ddb21eb9ec0009e6a68a8','tx_slubevents_domain_model_discipline',3,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('78ced43e920adb80ff4c39ca63919a65','tt_content',7,'pi_flexform','sDEF/lDEF/settings.pidListOwn/vDEF/','','',0,0,0,'pages',10,''),('79f3890c8270c5cfe53ba29ec76eae78','tt_content',11,'pages','','','',0,1,0,'pages',13,''),('7a17a9f86c1b06054f62c9e6f5f248ae','tx_slubevents_domain_model_location',18,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('7a4fde7e8f7adf4cba4cc62a2b3a1859','tx_slubevents_domain_model_location',77,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',36,''),('7ad7009a04e7e7c9e0a9b7e3397b3b68','tx_slubevents_domain_model_category',75,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('7af86294cd65d60f9b54266a053f0f67','tx_slubevents_domain_model_location',12,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('7bc387d9bfe55ae9405abc7d60aab746','tx_slubevents_domain_model_category',127,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('7c52bcfef4a0fc8d3e1d4b79e7814f64','tx_slubevents_domain_model_location',63,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('7c96f8b95ad6550b7769b016c1b7eb80','tx_slubevents_domain_model_discipline',9,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',35,''),('7d96ce68a543706ef89b39f5ac81dfa3','tt_content',29,'tt_content','','','',0,0,0,'tt_content',30,''),('7e291bcdc452a2f1973b5fd981598062','tx_slubevents_domain_model_category',101,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('7e9951b83447d99ed63b99a57645bb97','tx_slubevents_domain_model_category',103,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('7f98b9e55d6450570ea382d7874c8f9e','tx_slubevents_domain_model_category',110,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',109,''),('7fb7fbe66de3cc05e64341c2dfb6e139','tx_slubevents_domain_model_event',16,'subscribers','','','',0,0,0,'tx_slubevents_domain_model_subscriber',6,''),('808a0fa4524adddcb4582a8875b13f2e','tx_slubevents_domain_model_category',11,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('825fde339a1265266b15bb49596bc0e3','tx_slubevents_domain_model_category',26,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('82e625645752dc4a4f92d7f2638c01b5','tt_content',40,'fe_group','','','',0,0,0,'fe_groups',1,''),('84be282aa9d8277cf60779447c0481c4','tx_slubevents_domain_model_category',39,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',78,''),('859e6ea9fee31216e2b427047f471795','tx_slubevents_domain_model_event',20,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('872b7159441d8989c4b2ce15e9df98c3','tt_content',30,'pi_flexform','additional/lDEF/settings.listPageUid/vDEF/','','',0,0,0,'pages',16,''),('87c78a73e808914093d21c0b2b29b65a','tx_slubevents_domain_model_category',10,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('882b5ceb7d1f534cfb7a97c2d99cedf9','tx_slubevents_domain_model_location',24,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('88eaee74170360ae105c0f841f270b32','tx_slubevents_domain_model_location',15,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,0,'sys_file_storage',1,''),('89c4c830c6a3366d470130009659a44b','tx_slubevents_domain_model_location',71,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',59,''),('8a6e42e2e069e63d8f03ca2649369787','tx_slubevents_domain_model_category',81,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('8ba01abd3ce16dc75b77e3c3906d7713','fe_users',1,'usergroup','','','',0,0,0,'fe_groups',1,''),('8bd60d3e38e104a302a29a6e8515745f','tx_slubevents_domain_model_category',162,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',159,''),('8d8722f0a529d2f6065b8ead8cf296b3','tt_content',45,'fe_group','','','',0,0,0,'fe_groups',1,''),('8dcef3a736edb588770d09fc38f8196a','tx_slubevents_domain_model_location',60,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('9066d7c91f6947473b3c87d9e367a173','tt_content',29,'tt_content','','','',1,0,0,'tt_content',44,''),('91e37ab8438d95b52f9f00338ea1f512','tx_slubevents_domain_model_event',16,'categories','','','',2,0,0,'tx_slubevents_domain_model_category',156,''),('929b33a0cd59c65e13322b55660f25c2','pages',18,'l10n_parent','','','',0,0,0,'pages',8,''),('9344ed4aaf05cbdebbbedaed8a688b5a','tx_slubevents_domain_model_category',23,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',31,''),('93e05d0b7c6bd2ec13be15f4502ec40c','tx_slubevents_domain_model_category',161,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',159,''),('943df0783a5d773d2b925af4423a6211','tx_slubevents_domain_model_category',50,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('955bcf9004c0c6d8cc7897cfb3ce4f04','tx_slubevents_domain_model_category',108,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('956f7c1a3832a81d09a929abf7f585dc','tx_slubevents_domain_model_location',29,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',30,''),('95a2fa69f000360d39fe3b59c58e8032','tx_slubevents_domain_model_category',134,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',133,''),('96d63ce1380950dccfe6feb1886926c1','tx_slubevents_domain_model_category',68,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('97e59155056f5ddf2e36ef37dbb53449','tx_slubevents_domain_model_category',139,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',133,''),('989999a606064f6508c9cfb373736b98','tx_slubevents_domain_model_discipline',14,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',35,''),('99b8240c82d357a3bcac5b90f1bc2928','tx_slubevents_domain_model_category',61,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('9a77e25e32513a40039672d70e99ee29','tx_slubevents_domain_model_category',42,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('9abecc2b00ca20e0d3f3c0e005c36c48','tt_content',29,'fe_group','','','',0,0,0,'fe_groups',1,''),('9b0e60663b7b88e736f07ff52afd0c12','tx_slubevents_domain_model_event',20,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('9b49228a87a1a89a5ae08d0f669a09d5','tx_slubevents_domain_model_category',148,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('9b6292880bfc35f5cfe2b1c908915036','tx_slubevents_domain_model_category',112,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('9d2502b84495c1fb625df10559092693','tx_slubevents_domain_model_category',6,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',23,''),('9e2e2a7218c304dee80ee709757ba679','tx_slubevents_domain_model_category',118,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('9e8ecb5ed577076e35bdd266535d68a8','tx_slubevents_domain_model_category',141,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('9ead04f23e17e1da261b16c2f7ba6fcf','tt_content',39,'pi_flexform','additional/lDEF/settings.listPageUid/vDEF/','','',0,0,0,'pages',16,''),('9f2003672cfe394e4614bdc8d6f83a93','tt_content',4,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('a1400e8331002fc24be0246204a3966e','tt_content',9,'pi_flexform','s_redirect/lDEF/redirectPageLogout/vDEF/','','',0,0,0,'pages',1,''),('a1520cc108ef640f195978ae302a033d','tx_slubevents_domain_model_category',102,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('a1ce2f1c2ab2a45638fe98dcb94123c7','tx_slubevents_domain_model_location',41,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',45,''),('a247434efb7c1525e533b379ed942e6c','pages',21,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('a25f23872e75b67b954b34d9514722d7','tt_content',37,'pi_flexform','sDEF/lDEF/settings.pidSubscribeForm/vDEF/','','',0,0,0,'pages',11,''),('a2ea110a10f34939465a170ef1fb9afd','tx_slubevents_domain_model_category',113,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('a2f93aabf6f1caaffc9414b6bcb24d4a','tx_slubevents_domain_model_category',60,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('a47d92c8b414f405bbfd5ae3cb71f3b9','tx_slubevents_domain_model_location',40,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('a5f2d2ef5c22819f9c8c1d1f1ecde120','tx_slubevents_domain_model_event',7,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',150,''),('a6bc50e13eafca4b477a67c8ea6fb5cc','tx_slubevents_domain_model_category',144,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',133,''),('a6eeb1b3ed108da8c07affb745e5396f','tx_slubevents_domain_model_category',140,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('a6f2591ee2671272292db6280ee42451','tx_slubevents_domain_model_category',32,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',74,''),('a72102f4ec6fc8ad868ce88ce50bd355','tx_slubevents_domain_model_category',54,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('a7e12c2ac982b2df5d973b6b52a7379b','tx_slubevents_domain_model_category',14,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',18,''),('a822c5238eff6b67b9e70838746c928d','tx_slubevents_domain_model_category',124,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',126,''),('a8e1d1b0b2d114c3fbd88f34b4e01df5','pages',4,'l10n_parent','','','',0,0,0,'pages',1,''),('a96927a2a7d1040816a3f62b58c1dc38','tx_slubevents_domain_model_category',78,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('aa000fbfa9561ac283159de47a681452','tx_slubevents_domain_model_category',160,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('aaa3ebd09965b10ab1ea3491cd9dac15','tx_slubevents_domain_model_category',105,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('aaaa3236fbdc778d536a34f5f779547e','tx_slubevents_domain_model_category',72,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('aad2d73cd72b9e0f2a3e261148abbcdf','tx_slubevents_domain_model_category',43,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('abd6bd376212058d53ed5f518b48fc5a','pages',19,'l10n_parent','','','',0,0,0,'pages',9,''),('ac99431cac2c8fb9a2468b7ad9ff4680','tx_slubevents_domain_model_discipline',22,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('ae2e99c80c333181f379364ab05e1a48','tx_slubevents_domain_model_category',149,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('ae39306d198d3485ee033022d47523fc','tx_slubevents_domain_model_category',63,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('aec545e707713ecaefb9fd8bf027342e','tx_slubevents_domain_model_event',12,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('af6cb897cec8357303184bf356ba0591','tx_slubevents_domain_model_location',28,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',30,''),('b0c77855673380e7469168db9a7de987','tx_slubevents_domain_model_category',40,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',79,''),('b0e8da01dbe6a3f1c30d2d1881eb4a5d','tx_slubevents_domain_model_category',33,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',81,''),('b1315f6a325027205050c81764294b72','sys_file',1,'storage','','','',0,0,0,'sys_file_storage',1,''),('b1628737959de9384a83f8c71ee6361f','tx_slubevents_domain_model_location',16,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('b2682bc2713f32acc4ca3bb7e6e13fa8','tx_slubevents_domain_model_discipline',25,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('b2bfa7b12686e35747a1a31a8eaa2881','pages',19,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('b2da299d1b4e8af4969d8017cf1ac095','tx_slubevents_domain_model_category',53,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('b33ca234c2a55db2fcc060fb85f11691','tx_slubevents_domain_model_category',168,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('b3a1cd8f8adf77ede266c871e577a4d1','pages',4,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('b5eaed845d70532964df79978832c318','tx_slubevents_domain_model_category',80,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('b6ef252312bcf4817a87771baf199310','tx_slubevents_domain_model_category',69,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('b894bfdbfa6442ef8f3d5a6f5d35851f','tx_slubevents_domain_model_location',42,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',45,''),('b9433de2bad2161cb08015fd2db8db0b','tt_content',4,'pi_flexform','sDEF/lDEF/settings.pidDetails/vDEF/','','',0,0,0,'pages',8,''),('ba48dd393563569e5e9dee629b75a5b7','tx_slubevents_domain_model_category',71,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('ba700e88d026158477833bb55e0ec3ba','tx_slubevents_domain_model_location',34,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',35,''),('bac59003c19719c4789c20771ee0d33b','tt_content',30,'pi_flexform','additional/lDEF/settings.detailPageUid/vDEF/','','',0,0,0,'pages',8,''),('bb488b7649a28327cdda594de64aded6','tx_slubevents_domain_model_category',129,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',94,''),('bb48f39e33aa9bc4cd3805b20b2e343c','tx_slubevents_domain_model_discipline',20,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('bd0cbd0bbabed63d93375e7c78cad5d7','tx_slubevents_domain_model_discipline',5,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',33,''),('bdb690fa48af7d38df08ab622bfc62c0','tx_slubevents_domain_model_category',152,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('be08635bdca7098da3dc1bd5c2d4baff','tx_slubevents_domain_model_discipline',15,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('beb995146463af48c041edbe41106bca','tx_slubevents_domain_model_discipline',38,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',35,''),('bedfb708a76c187eac651bb72c05302e','tx_slubevents_domain_model_event',2,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('c22a42e4ea30f822c7a29f2c9e08e12d','tt_content',39,'fe_group','','','',0,0,0,'fe_groups',1,''),('c23d58ebaca0ffe6a132e0154c07f10b','tt_content',38,'pi_flexform','sDEF/lDEF/settings.pidSubscribeForm/vDEF/','','',0,0,0,'pages',11,''),('c23f7b6c6bb545fa8c1a26c23fe6a710','tx_slubevents_domain_model_category',34,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',81,''),('c3507a06c5a8a13a05db27f49a9e5dc1','pages',20,'fe_group','','','',0,0,0,'fe_groups',1,''),('c3c5066c0bb8cf8016f1936b5632d9b9','tx_slubevents_domain_model_category',123,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('c4bdbf5b9fe40b0bef9d4b18b58e7043','tx_slubevents_domain_model_category',64,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('c4cdb87da2597608ccf3474bf48d789d','tx_slubevents_domain_model_discipline',8,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',35,''),('c67dd2dbb5b0d02104f92bc9ad91648c','tx_slubevents_domain_model_event',13,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('c735ea95b7b26b5a8472e8a3057a39f4','tx_slubevents_domain_model_category',15,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',18,''),('c84672d9c66481c22f32361a6d583a7a','tt_content',43,'pages','','','',1,0,0,'pages',12,''),('c88a14a839e520bc22e7b90d82cd43a1','tt_content',37,'l18n_parent','','','',0,0,0,'tt_content',4,''),('c8dfc9cdd97736a099783b4f506d180b','tx_slubevents_domain_model_event',1,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('c97b6cc48115e599b228c375db125e5d','tx_slubevents_domain_model_category',67,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('ca48274f2368d5087ddf4872bab703c2','tx_slubevents_domain_model_location',10,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('cacaf4706fb766b9b7c8927c053eb686','tx_slubevents_domain_model_category',157,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('cb57960e111ec450393f20d80b97c5cd','tx_slubevents_domain_model_location',27,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',30,''),('cc8684dafe4f8b057fb3badc85c89dae','tx_slubevents_domain_model_category',155,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('cc998c1691874afe2683540a268e0b69','tx_slubevents_domain_model_category',119,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('cceb9c97436bae1c67f1b6d083ba840b','pages',18,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('cdb2bbcf0aebfa5efff62e3079b09a11','tx_slubevents_domain_model_category',56,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('ce23ebda2b9f1f964fea86e6cb03f012','tx_slubevents_domain_model_category',99,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('ce38598d4b51aafb4ada89cba8bfb106','tx_slubevents_domain_model_event',12,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('ce999d4f19583b1ac6d38c0e492b1147','tx_slubevents_domain_model_event',12,'subscribers','','','',2,0,0,'tx_slubevents_domain_model_subscriber',5,''),('cee5e039cde18cb4b7a5a03113691747','tx_slubevents_domain_model_category',22,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',24,''),('cfd9f28f51ee86298d5290ea04827822','tx_slubevents_domain_model_category',145,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('d08f9b2ebcf62b00ccbeaf6040bf7c93','pages',15,'fe_group','','','',0,0,0,'fe_groups',1,''),('d0c3855f554f09ed0c1454f959c25e76','tx_slubevents_domain_model_category',156,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('d13f4d3ca094e8fb4424d6d7c3a084ba','tt_content',4,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',2,0,0,'tx_slubevents_domain_model_category',1,''),('d24df9ad45a5b06f32ad7b338b1c751e','tx_slubevents_domain_model_category',16,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',18,''),('d29b8cd012438ce96557d6220ad7c827','tx_slubevents_domain_model_category',126,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('d2c8e8031a7a39e9bd41acc2993de49f','tx_slubevents_domain_model_category',73,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('d2ec8fe9251f8f96aeece44eec892850','tx_slubevents_domain_model_category',150,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('d32656950aed51061fc6d5b35c895c03','tx_slubevents_domain_model_category',85,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',81,''),('d3be6c53bb1577eb8d036613242f129c','tt_content',37,'pi_flexform','sDEF/lDEF/settings.pidDetails/vDEF/','','',0,0,0,'pages',8,''),('d41d476b32173b894856bcf0c570fccc','tx_slubevents_domain_model_location',52,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('d4f81ff44d499dde69a869283448663f','tx_slubevents_domain_model_location',7,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('d5df0b9dde8a3e282e015c374f09c7f4','tx_slubevents_domain_model_event',26,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',165,''),('d6b98d7591ed71d11e489863ffb0a82b','tx_slubevents_domain_model_location',62,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('d6d1b546e101d1aa05756fe27ccde52a','tx_slubevents_domain_model_location',64,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('d7a1141b4ba528d9fefd89c9e8b5ddd6','tx_slubevents_domain_model_category',131,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',93,''),('d7a84f820a4293292ec1c46905e45d92','tx_slubevents_domain_model_category',143,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',139,''),('d7b740abab04b7c73d3098ce6e031f50','tx_slubevents_domain_model_category',136,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',134,''),('d9d8856951973b02032c78e6ff672960','tx_slubevents_domain_model_category',106,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('d9f7f299ec391cdcfd42906c53e3671d','tx_slubevents_domain_model_location',43,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',45,''),('da2699c907292002b2d5a776d8d107b9','tx_slubevents_domain_model_category',83,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',2,''),('da2b18974aafd2e005ed6ee181a0c864','tx_slubevents_domain_model_event',26,'location','','','',0,0,0,'tx_slubevents_domain_model_location',67,''),('da8e820fc32debd23720f1d5168947d0','tx_slubevents_domain_model_location',56,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('db14c7921e3b5f969dd8e092d667e262','tx_slubevents_domain_model_event',16,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('db65fd1990ceb7e6478007776bb231a9','tx_slubevents_domain_model_event',26,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('dcc2d6e39f2196820f1576a19ecc0cc0','tx_slubevents_domain_model_event',1,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('dd76c87888132fa617d06cfb17f4118b','tt_content',39,'pi_flexform','additional/lDEF/settings.detailPageUid/vDEF/','','',0,0,0,'pages',8,''),('dda7efbf44d8705cffc62fcbd378c6a0','tx_slubevents_domain_model_discipline',4,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('dedf7261608c14efc2ceb5564f2897b9','tx_slubevents_domain_model_event',20,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('df588e8ba94f199b20e8dc20b87d1f47','pages',16,'fe_group','','','',0,0,0,'fe_groups',1,''),('e03a1c45aa77df176f000e379ef79819','tx_slubevents_domain_model_category',44,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',3,''),('e04e7303905ba6c2f270c94820e8d95c','tt_content',43,'pages','','','',0,0,0,'pages',22,''),('e18eeffabb3f230fab9a595a4cc652ae','tx_slubevents_domain_model_category',158,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('e21f84b3f6bafe6bf942118a3e7aca79','tt_content',6,'pi_flexform','sDEF/lDEF/settings.pidUnSubscribeForm/vDEF/','','',0,0,0,'pages',12,''),('e2a5c5357d5c2559259adcb70e1ea25f','tx_slubevents_domain_model_category',92,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',94,''),('e3571a8605c4ff55ff9c8569423307b8','tx_slubevents_domain_model_location',45,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('e3a97edfe33955561bb15c28174e5cca','tx_slubevents_domain_model_event',12,'contact','','','',0,0,0,'tx_slubevents_domain_model_contact',1,''),('e3c56024a8ec918c115f65bbe51fa884','tt_content',9,'pi_flexform','s_redirect/lDEF/redirectPageLogin/vDEF/','','',0,0,0,'pages',1,''),('e4056fef9bd61ebbeaf6788d8fe904ac','tx_slubevents_domain_model_category',135,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',134,''),('e428cbb8b830daa295d6f1a4430fab78','tx_slubevents_domain_model_event',12,'subscribers','','','',1,0,0,'tx_slubevents_domain_model_subscriber',4,''),('e50427e2177eec46cc3c2b14b692eab9','tx_slubevents_domain_model_category',20,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',24,''),('e555c44e4b8d3579aa278eaecde9c854','tx_slubevents_domain_model_category',98,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('e5ddb6ce3ac48eef1a2f7890b192050b','tx_slubevents_domain_model_location',6,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('e699f417fa5f9c85df9b970065fcd261','tx_slubevents_domain_model_location',61,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('e6c4f7ddd6b96e0a77bc945ae0e40b5d','tx_slubevents_domain_model_category',79,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('e7f1b8a381027baadb3171ec1a5ec88a','tx_slubevents_domain_model_category',2,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',42,''),('e84c30fd1f11b5e3384fdd44035df0f9','tx_slubevents_domain_model_discipline',13,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',34,''),('e88447a62a2c8b29362a4898ff19a35e','tx_slubevents_domain_model_category',138,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',134,''),('e884aa2aa7eb4509a6a9acb19d8d00cd','tt_content',7,'pi_flexform','sDEF/lDEF/settings.pidSubscribeForm/vDEF/','','',0,0,0,'pages',11,''),('e90402a2246edda3b06319dedba70de0','tx_slubevents_domain_model_category',121,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',75,''),('ea7f34be5433ec479ec221f295b2b1df','pages',21,'fe_group','','','',0,0,0,'fe_groups',1,''),('eac197a0e0239a71953efa0834fca08e','tx_slubevents_domain_model_category',100,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',110,''),('eb1164cba72a3f8289e69f5e0ed43ed1','tx_slubevents_domain_model_location',20,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('eb847f0b1a1f1d662e438b2a52ebc000','tx_slubevents_domain_model_category',77,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',44,''),('ec064d494edbd334ebcc786d96b4f592','tx_slubevents_domain_model_category',12,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('ec0e9e47f46fa867073225ce4042bd96','tx_slubevents_domain_model_category',104,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('ec37a2cc80878fb63e6e88a7473eb52a','tx_slubevents_domain_model_category',70,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('ed1367411128739beb4e1a39fe8ed976','tx_slubevents_domain_model_category',7,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('ee891c8c5659ec0b6a585b5db7281af4','tx_slubevents_domain_model_category',87,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',1,''),('efdcba4434e7b0e8aa5dc7e4a0aa9018','tx_slubevents_domain_model_category',146,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',144,''),('f15e1f2d1ff3d96e6be6a9f31582e219','tx_slubevents_domain_model_category',35,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',78,''),('f1b32b98a93e83c53b43710b89f45549','tx_slubevents_domain_model_discipline',29,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('f1dd9f7d91236c505d9d45b3b90af782','tx_slubevents_domain_model_location',50,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('f1fffbd6184b169c64fd9ef426deaff7','tt_content',30,'fe_group','','','',0,0,0,'fe_groups',1,''),('f227055f39a57a642dc42930f4943e39','sys_template',1,'config','','url','7',-1,0,0,'_STRING',0,'https://ddev-slub-katalog.ddev.site/anmeldung'),('f39d3090783cd539b943303624fb8a38','tx_slubevents_domain_model_event',16,'categories','','','',0,0,0,'tx_slubevents_domain_model_category',92,''),('f3f8cea0e2dac43c6a667eb795080728','tt_content',37,'pi_flexform','sDEF/lDEF/settings.categorySelection/vDEF/','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('f4c24f8cd6c5686aafef521c0828a1e2','tx_slubevents_domain_model_event',2,'location','','','',0,0,0,'tx_slubevents_domain_model_location',16,''),('f55ddf4b2bc8b5a7d054329a936b6dad','tx_slubevents_domain_model_location',5,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',26,''),('f564233557463673ad2826f24211a666','tx_slubevents_domain_model_discipline',23,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',32,''),('f59b70255933f92a3795d9fb447ae927','tx_slubevents_domain_model_location',48,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',59,''),('f59d76125b730b4078cbe0f1fd1d14cc','tx_slubevents_domain_model_category',25,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',13,''),('f8ebdc0f312b7aae634607cbb462711d','tx_slubevents_domain_model_category',49,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('f91a153437f80febe21a65be277e8c30','tx_slubevents_domain_model_category',8,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',77,''),('f99bea4f6724f0298c9a7ad6b3d0aee4','tx_slubevents_domain_model_event',2,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',35,''),('fa81dc20f05d14399eb8a28bcf978ab3','tx_slubevents_domain_model_event',1,'discipline','','','',0,0,0,'tx_slubevents_domain_model_discipline',31,''),('fa8c93bdd73397c39f501f0af451860a','tx_slubevents_domain_model_category',114,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',111,''),('fac0a39c1a62708de36c97752152cc86','tx_slubevents_domain_model_category',59,'parent','','','',0,0,0,'tx_slubevents_domain_model_category',76,''),('fb7e0d55404483fe2ad66fba9711aba1','tx_slubevents_domain_model_discipline',17,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',36,''),('fe0590fdb9adb905f443e5b417e813ee','tx_slubevents_domain_model_discipline',16,'parent','','','',0,0,0,'tx_slubevents_domain_model_discipline',34,''),('fe464a8e3cc6464b362c0920614525b7','tx_slubevents_domain_model_location',32,'parent','','','',0,0,0,'tx_slubevents_domain_model_location',47,''),('feacddddec62b126ea24229675cc04de','tx_slubevents_domain_model_event',7,'categories','','','',1,0,0,'tx_slubevents_domain_model_category',92,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` longblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserConfigurationUpdate','i:1;'),(30,'installUpdateRows','rowUpdatersDone','a:3:{i:0;s:52:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L10nModeUpdater\";i:1;s:53:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\ImageCropUpdater\";i:2;s:57:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\RteLinkSyntaxUpdater\";}'),(31,'extensionDataImport','typo3/sysext/core/ext_tables_static+adt.sql','s:0:\"\";'),(32,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(33,'extensionDataImport','typo3/sysext/extbase/ext_tables_static+adt.sql','s:0:\"\";'),(34,'extensionDataImport','typo3/sysext/fluid/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3/sysext/frontend/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3/sysext/fluid_styled_content/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3/sysext/filelist/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3/sysext/impexp/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3/sysext/form/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/install/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3/sysext/recordlist/ext_tables_static+adt.sql','s:0:\"\";'),(42,'extensionDataImport','typo3/sysext/backend/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3/sysext/reports/ext_tables_static+adt.sql','s:0:\"\";'),(44,'extensionDataImport','typo3/sysext/setup/ext_tables_static+adt.sql','s:0:\"\";'),(45,'extensionDataImport','typo3/sysext/rte_ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),(46,'extensionDataImport','typo3/sysext/about/ext_tables_static+adt.sql','s:0:\"\";'),(47,'extensionDataImport','typo3/sysext/adminpanel/ext_tables_static+adt.sql','s:0:\"\";'),(48,'extensionDataImport','typo3/sysext/belog/ext_tables_static+adt.sql','s:0:\"\";'),(49,'extensionDataImport','typo3/sysext/beuser/ext_tables_static+adt.sql','s:0:\"\";'),(50,'extensionDataImport','typo3/sysext/extensionmanager/ext_tables_static+adt.sql','s:32:\"9beb0be917f14fdde2c9cb940a47d38e\";'),(51,'extensionDataImport','typo3/sysext/felogin/ext_tables_static+adt.sql','s:0:\"\";'),(52,'extensionDataImport','typo3/sysext/info/ext_tables_static+adt.sql','s:0:\"\";'),(53,'extensionDataImport','typo3/sysext/lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),(54,'extensionDataImport','typo3/sysext/redirects/ext_tables_static+adt.sql','s:0:\"\";'),(55,'extensionDataImport','typo3/sysext/seo/ext_tables_static+adt.sql','s:0:\"\";'),(56,'extensionDataImport','typo3/sysext/sys_note/ext_tables_static+adt.sql','s:0:\"\";'),(57,'extensionDataImport','typo3/sysext/t3editor/ext_tables_static+adt.sql','s:0:\"\";'),(58,'extensionDataImport','typo3/sysext/tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),(59,'extensionDataImport','typo3/sysext/viewpage/ext_tables_static+adt.sql','s:0:\"\";'),(60,'extensionDataImport','typo3conf/ext/find/ext_tables_static+adt.sql','s:0:\"\";'),(61,'extensionDataImport','typo3conf/ext/slub_account/ext_tables_static+adt.sql','s:0:\"\";'),(62,'extensionDataImport','typo3conf/ext/slub_find_bookmarks/ext_tables_static+adt.sql','s:0:\"\";'),(63,'extensionDataImport','typo3conf/ext/slub_find_extend/ext_tables_static+adt.sql','s:0:\"\";'),(64,'extensionDataImport','typo3conf/ext/slub_katalog_beta/ext_tables_static+adt.sql','s:0:\"\";'),(65,'extensionDataImport','typo3conf/ext/slub_katalog_config/ext_tables_static+adt.sql','s:0:\"\";'),(66,'extensionDataImport','typo3conf/ext/slub_template/ext_tables_static+adt.sql','s:0:\"\";'),(67,'core','formProtectionSessionToken:3','s:64:\"8d7a4feea9e5df75666369b51df562d815ef500f32c1e855d3370bb00ff9e787\";'),(68,'languagePacks','baseUrl','s:44:\"https://extensions.typo3.org/fileadmin/l10n/\";'),(69,'core','formProtectionSessionToken:1','s:64:\"32adc2c1fab4f88f35b83a13d207fb1a4b71844a5e1e84bf9008ec0772eb9dfc\";'),(70,'languagePacks','de-slub_find_bookmarks','i:1624960456;'),(71,'languagePacks','de-slub_template','i:1624960456;'),(72,'languagePacks','de','i:1624960456;'),(73,'extensionDataImport','typo3conf/ext/slub_events/ext_tables_static+adt.sql','s:0:\"\";'),(74,'extensionDataImport','typo3conf/ext/slub_profile_service/ext_tables_static+adt.sql','s:0:\"\";'),(75,'extensionDataImport','typo3conf/ext/solr/ext_tables_static+adt.sql','s:0:\"\";'),(76,'extensionDataImport','typo3conf/ext/slub_web_profile/ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextLevel` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,2,1642085938,1624960530,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'NEW SITE','',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:find/Configuration/TypoScript,EXT:slub_katalog_config/Configuration/TypoScript/Page,EXT:slub_katalog_config/Configuration/TypoScript/Plugin,EXT:slub_find_bookmarks/Configuration/TypoScript,EXT:slub_katalog_beta/Configuration/TypoScript','\nplugin.tx_slubfindbookmarks_bookmarklist.persistence.storagePid = 23\nplugin.tx_slubfindbookmarks_bookmarklist.settings.detailPagePid = 5','page.includeJSFooterlibs.chat >\r\nplugin.tx_find.settings.nosearchRedirect >\r\nlib.catalog.slubLinks.account.value. = https://katalog.ddev.site/mein-konto\r\nlib.catalog.slubLinks.login.value = https://ddev-slub-katalog.ddev.site/anmeldung\r\nplugin.tx_find.settings.connection {\r\n    host = ddev-slub-katalog.ddev.site\r\n    port = 8983\r\n    path = /solr/katalog/\r\n    timeout = 30\r\n    scheme = http\r\n}\r\nplugin.tx_find.settings.shards >','','',0,0,0),(2,3,1626532945,1624960950,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'+ext','',0,0,'EXT:slub_account/Configuration/TypoScript',NULL,'plugin.tx_slubaccount.settings.debug = 0\r\n\r\nplugin.tx_slubaccount {\r\n  settings {\r\n    #baseURL = https://katalog.ddev.site/\r\n    loginURL = https://ddev-slub-katalog.ddev.site/anmeldung\r\n  }\r\n  \r\n}\nplugin.tx_slubaccount.settings.baseURL = https://ddev-slub-katalog.ddev.site/libero/\nplugin.tx_slubaccount.settings.debug = 1\nplugin.tx_slubaccount.settings.debug = 0','','',0,0,0),(3,1,1636706809,1624961607,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'Slub Katalog','',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:slub_events/Configuration/TypoScript,EXT:slub_web_profile/Configuration/TypoScript/,EXT:slub_template/Configuration/TypoScript','config.rootPid = 1\r\nplugin.tx_slubtemplate_oerdisplay.persistence.storagePid = 0\r\nconfig.piwik_hostname = matomo.slub-dresden.de\r\nconfig.piwik_idsite = \r\nconfig.piwik_domains = \r\nplugin.tx_slubevents.persistence.storagePid = 9\r\nplugin.tx_slubevents_apieventlistuser.settings.unsubscribePid = 12\r\nplugin.tx_slubevents.settings.api.users.0.username = username\nplugin.tx_slubevents.settings.api.users.0.password = password','page.includeJSFooterlibs.chat >\r\npage.10.variables {\r\n    link-myaccount = TEXT\r\n    link-myaccount.value = 3\r\n}','','',0,0,0),(4,5,1626552808,1624961908,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'+ext','',0,0,'EXT:slub_find_bookmarks/Configuration/TypoScript','plugin.tx_slubfindbookmarks_bookmarklist.settings.detailPagePid = 2',NULL,'','',0,0,0),(5,6,1626552823,1626552815,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'+ext','',0,0,'EXT:slub_find_bookmarks/Configuration/TypoScript/Api',NULL,NULL,'','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `spaceBefore` smallint(5) unsigned NOT NULL DEFAULT 0,
  `spaceAfter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(17) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  `tx_slubtemplate_testimonials` int(10) unsigned DEFAULT 0,
  `tx_slubtemplate_factstables` int(10) unsigned DEFAULT 0,
  `tx_slubtemplate_staticnewsbar` int(10) unsigned DEFAULT 0,
  `tx_slubtemplate_teaseralignment` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_slubtemplate_teaserblur` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_slubtemplate_teaserbackgroundimage` int(10) unsigned DEFAULT 0,
  `tx_slubtemplate_teaserlink` int(10) unsigned DEFAULT 0,
  `irre_parent_uid` int(11) NOT NULL DEFAULT 0,
  `irre_parent_table` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tt_content` int(11) NOT NULL DEFAULT 0,
  `tx_slubevents_related_content` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `index_eventscontent` (`tx_slubevents_related_content`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',2,1624962126,1624962120,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','find_find',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(2,'',3,1624962256,1624962255,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubaccount_account',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(3,'',5,1624962456,1624962289,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubfindbookmarks_bookmarklist',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(4,'',7,1624970171,1624968452,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubevents_eventlist',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.categorySelection\">\n                    <value index=\"vDEF\">111,94,1</value>\n                </field>\n                <field index=\"settings.categorySelectionRecursive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.disciplineSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.disciplineSelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPastEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showEventsFromNow\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.limitByNextWeeks\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.contactsSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidListing\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidDetails\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"settings.eventOrdering\">\n                    <value index=\"vDEF\">ASC</value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;list;Event-&gt;show;Event-&gt;showNotFound</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"FullCalendar\">\n            <language index=\"lDEF\">\n                <field index=\"settings.fullCalendarJS\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(5,'',8,1624970208,1624970189,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubevents_eventlist',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.categorySelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categorySelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disciplineSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.disciplineSelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPastEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showEventsFromNow\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.limitByNextWeeks\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.contactsSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidListing\">\n                    <value index=\"vDEF\">7</value>\n                </field>\n                <field index=\"settings.pidDetails\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;show;Event-&gt;showNotFound</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"FullCalendar\">\n            <language index=\"lDEF\">\n                <field index=\"settings.fullCalendarJS\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(6,'',11,1624970245,1624970223,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubevents_eventsubscribe',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Subscriber-&gt;new;Subscriber-&gt;create;Subscriber-&gt;eventNotFound;</value>\n                </field>\n                <field index=\"settings.dontClearCachedEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pidListOwn\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidUnSubscribeForm\">\n                    <value index=\"vDEF\">12</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(7,'',12,1624970277,1624970261,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubevents_eventsubscribe',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.dontClearCachedEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pidListOwn\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"settings.pidUnSubscribeForm\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Subscriber-&gt;delete;Subscriber-&gt;eventNotFound;Subscriber-&gt;subscriberNotFound;</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(8,'',10,1624970302,1624970293,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'',0,'','',0,'3','slubevents_eventuserpanel',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;listOwn;Event-&gt;show</value>\n                </field>\n                <field index=\"settings.pidUnsubscribeForm\">\n                    <value index=\"vDEF\">12</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(9,'',13,1625147895,1625147803,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:21:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'login','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"showForgotPassword\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pages\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n                <field index=\"recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"redirectMode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"redirectPageLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"redirectPageLogout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(10,'',13,1625148196,1625148050,1,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:21:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'text','Dummy Login','','<p>Über folgendes Formular kann man sich an der Webseite einloggen. Das dient nur der Simulation einer echten Shibboleth-Anmeldung auf der Webseite.</p>\r\n<p>Testnutzer:&nbsp;4998866</p>\r\n<p>Passwort:&nbsp;slub</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(11,'',13,1632397402,1632397379,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'menu_subpages','Unterseiten','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'13',0,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(12,'',15,1632471644,1632398687,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:14:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(13,'',15,1633602463,1632401150,1,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'text','At vero eos et accusam et justo duo','','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est.</p>\r\n<p>Lorem ipsum dolor sit amet.&nbsp;Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(14,'',15,1633602467,1632406783,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'text','Invidunt ut labore et dolore magna','','<p>Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est. Lorem ipsum dolor sit amet.&nbsp;Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(15,'',15,1632467733,1632408948,1,1,0,0,0,'',192,0,0,0,0,NULL,0,'a:20:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:10:\"tt_content\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_dashboard','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',1,0),(16,'',15,1632467733,1632408948,1,1,0,0,0,'',1,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'header','','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,15,'tt_content',0,0),(17,'',15,1632411641,1632411520,1,1,0,0,0,'',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'header','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,15,'tt_content',0,0),(18,NULL,15,1632467424,1632467397,1,1,0,0,0,'0',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'header','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,15,'tt_content',0,0),(19,'',15,1632471760,1632467755,1,1,0,0,0,'',192,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:10:\"tt_content\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_dashboard','Dashboard','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',2,0),(20,'',15,1632468886,1632467769,1,1,0,0,0,'',1,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'header','Header','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,19,'tt_content',0,0),(21,'',15,1632470175,1632468923,1,1,0,0,0,'',1,0,0,0,0,NULL,0,'a:14:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,19,'tt_content',0,0),(22,NULL,15,1632471760,1632470418,1,1,0,0,0,'',1,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,19,'tt_content',0,0),(23,NULL,15,1632470468,1632470461,1,1,0,0,0,'0',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,19,'tt_content',0,0),(24,NULL,15,1632471760,1632471691,1,1,0,0,0,'0',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,19,'tt_content',0,0),(25,'',15,1632471864,1632471829,1,1,0,0,0,'',320,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_dashboard','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',1,0),(26,NULL,15,1632471864,1632471829,1,1,0,0,0,'0',1,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,25,'tt_content',0,0),(27,'',15,1632472453,1632472319,1,1,0,0,0,'',320,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:10:\"tt_content\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_dashboard','Dashboard','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',1,0),(28,'',15,1632472453,1632472319,1,1,0,0,0,'',1,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Veranstaltungen','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,27,'tt_content',0,0),(29,'',15,1638896552,1632472495,1,0,0,0,0,'1',1024,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:10:\"tt_content\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_dashboard','Dashboard','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',3,0),(30,'',15,1638896600,1632472495,1,0,0,0,0,'1',1,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_eventlist','Meine Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'Bevorstehende Veranstaltungen:','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d M</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(31,'',15,1632476343,1632476118,1,1,0,1632915480,0,'',2,0,0,0,0,NULL,0,'a:13:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Test','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(32,'',15,1632483909,1632477957,1,1,0,0,0,'',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','Test','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(33,'',15,1633019532,1633019506,1,1,0,0,0,'',2,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'slubprofileservice_eventlist','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">Y-m-d</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(34,'',16,1635431832,1633097970,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:14:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_eventlist','Gebuchte Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d.m.Y</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(35,'',16,1633098047,1633098014,1,1,0,0,0,'',128,0,0,0,0,NULL,0,'',0,0,'',0,0,0,0,0,0,'header','Meine Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(36,'',15,1633442185,1633441965,1,1,0,0,0,'',2,0,0,0,0,NULL,0,'a:21:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'text','Text','','<p>fgh jfgjh fg fgjh&nbsp;</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">Y-m-d</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(37,'',7,1633505958,1633505881,1,0,0,0,0,'',512,0,1,4,4,NULL,4,'a:25:{s:5:\"CType\";s:4:\"list\";s:6:\"colPos\";i:0;s:6:\"header\";s:0:\"\";s:13:\"header_layout\";s:1:\"3\";s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:9:\"list_type\";s:20:\"slubevents_eventlist\";s:11:\"pi_flexform\";s:2381:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.categorySelection\">\n                    <value index=\"vDEF\">111,94,1</value>\n                </field>\n                <field index=\"settings.categorySelectionRecursive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.disciplineSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.disciplineSelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPastEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showEventsFromNow\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.limitByNextWeeks\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.contactsSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidListing\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidDetails\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"settings.eventOrdering\">\n                    <value index=\"vDEF\">ASC</value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;list;Event-&gt;show;Event-&gt;showNotFound</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"FullCalendar\">\n            <language index=\"lDEF\">\n                <field index=\"settings.fullCalendarJS\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:5:\"pages\";s:0:\"\";s:9:\"recursive\";i:0;s:6:\"layout\";i:0;s:11:\"frame_class\";s:7:\"default\";s:18:\"space_before_class\";s:0:\"\";s:17:\"space_after_class\";s:0:\"\";s:12:\"sectionIndex\";i:1;s:9:\"linkToTop\";i:0;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:11:\"l18n_parent\";i:0;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','','','',0,'','',0,'3','slubevents_eventlist',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.categorySelection\">\n                    <value index=\"vDEF\">111,94,1</value>\n                </field>\n                <field index=\"settings.categorySelectionRecursive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.disciplineSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.disciplineSelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPastEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showEventsFromNow\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.limitByNextWeeks\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.contactsSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidListing\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidDetails\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"settings.eventOrdering\">\n                    <value index=\"vDEF\">ASC</value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;list;Event-&gt;show;Event-&gt;showNotFound</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"FullCalendar\">\n            <language index=\"lDEF\">\n                <field index=\"settings.fullCalendarJS\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(38,'',8,1633505998,1633505996,1,0,0,0,0,'',512,0,1,5,5,NULL,5,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:11:\"pi_flexform\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','','','',0,'','',0,'3','slubevents_eventlist',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.categorySelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categorySelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disciplineSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.disciplineSelectionRecursive\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPastEvents\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showEventsFromNow\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.limitByNextWeeks\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.contactsSelection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidListing\">\n                    <value index=\"vDEF\">7</value>\n                </field>\n                <field index=\"settings.pidDetails\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.pidSubscribeForm\">\n                    <value index=\"vDEF\">11</value>\n                </field>\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">Event-&gt;show;Event-&gt;showNotFound</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"FullCalendar\">\n            <language index=\"lDEF\">\n                <field index=\"settings.fullCalendarJS\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(39,'',15,1635328990,1633602480,1,0,0,0,0,'1',576,0,1,30,30,NULL,30,'a:16:{s:5:\"CType\";s:24:\"slubwebprofile_eventlist\";s:6:\"colPos\";i:0;s:6:\"header\";s:21:\"Meine Veranstaltungen\";s:13:\"header_layout\";s:1:\"3\";s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:30:\"Bevorstehende Veranstaltungen:\";s:11:\"pi_flexform\";s:1088:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d M</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:1:\"1\";s:8:\"editlock\";i:0;s:14:\"rowDescription\";s:0:\"\";s:11:\"l18n_parent\";i:0;s:10:\"categories\";i:0;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_eventlist','My events','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','','','',999,'Coming events:','',0,'3','',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d M</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\">16</value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,40,'tt_content',0,0),(40,'',15,1635328987,1633602480,1,0,0,0,0,'1',768,0,1,29,29,NULL,29,'a:15:{s:5:\"CType\";s:24:\"slubwebprofile_dashboard\";s:6:\"colPos\";i:999;s:6:\"header\";s:9:\"Dashboard\";s:13:\"header_layout\";s:1:\"3\";s:10:\"tt_content\";i:1;s:12:\"sectionIndex\";i:1;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:1:\"1\";s:8:\"editlock\";i:0;s:14:\"rowDescription\";s:0:\"\";s:11:\"l18n_parent\";i:0;s:10:\"categories\";i:0;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_dashboard','Dashboard','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',1,0),(41,'',16,1635328085,1633602596,1,0,0,0,0,'',512,0,1,34,34,NULL,34,'a:16:{s:5:\"CType\";s:24:\"slubwebprofile_eventlist\";s:6:\"colPos\";i:0;s:6:\"header\";s:24:\"Gebuchte Veranstaltungen\";s:13:\"header_layout\";s:1:\"3\";s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:11:\"pi_flexform\";s:1087:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d.m.Y</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:14:\"rowDescription\";s:0:\"\";s:11:\"l18n_parent\";i:0;s:10:\"categories\";i:0;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_eventlist','Booked events','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">d.m.Y</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(42,'',16,1636545593,1636455279,1,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_eventfilter','Filter für Veranstaltungen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(43,'',15,1638896494,1638889166,1,0,0,0,0,'1',512,0,0,0,0,NULL,0,'a:14:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:5:\"pages\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_userdetail','Benutzerkonto','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,'22,12',0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"xmlTitle\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0),(44,'',15,1638896600,1638896381,1,0,0,0,0,'1',2,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_borrowinglist','Infos zu Ausleihe','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'Bevorstehende Rückgaben:','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">Y-m-d</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0),(45,'',15,1638896600,1638896552,1,0,0,0,0,'1',3,0,0,0,0,NULL,0,'a:15:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,'slubwebprofile_bookmarklist','Letzte Suchanfragen','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,0,0,'','',NULL,NULL,999,'Aktueller Verlauf:','',0,'3','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.layout\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.dateFormat\">\n                    <value index=\"vDEF\">Y-m-d</value>\n                </field>\n                <field index=\"settings.timeFormat\">\n                    <value index=\"vDEF\">H:i</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.detailPageUid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0,0,0,0,0,1,0,0,29,'tt_content',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `wsdl_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1346191200,0,0);
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user_uid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_category`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_category` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `genius_bar` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_category`
--

LOCK TABLES `tx_slubevents_domain_model_category` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_category` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_category` VALUES (1,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8448,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;}',NULL,0,'Öffentliche Veranstaltungen','',0,0),(2,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8320,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Infrastruktur und Technik','',42,1),(3,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8256,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Wissensbar','',0,1),(4,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8224,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zugang zu Ressourcen, WLAN-Nutzung','Sie möchten von zu Hause aus auf lizenzierte Ressourcen der SLUB zugreifen oder in den Gebäuden der SLUB das WLAN nutzen, aber haben Schwierigkeiten bei der Konfiguration Ihres Notebooks oder mobilen Gerätes? Kein Problem, wir helfen Ihnen gerne und lösen auch knifflige Fälle. \nSie brauchen für diese Beratung übrigens nicht in die SLUB zu kommen. Gerne helfen wir Ihnen auch per Screensharing über Skype, Google Hangouts oder ähnliche Lösungen.',2,1),(5,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8208,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'E-Journals / Open Journal Systems (OJS)','Sie planen die Herausgabe eines neuen wissenschaftlichen E-Journals oder möchten eine bestehende Print-Zeitschrift in ein elektronisches Format überführen? Wir beraten Sie gern zum Aufsetzen einer Zeitschrift auf der Basis der Software Open Journal Systems (OJS).',13,1),(6,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8200,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'DFG-Kodex, Wissenschaftliche Integrität und Richtlinien','Der neue DFG-Kodex soll es Forschenden ermöglichen, Ihr Handeln an den Leitlinien zur guten wissenschaftlichen Praxis auszurichten. Es soll eine Kultur der wissenschaftlichen Integrität in den wissenschaftlichen Einrichtungen verankert werden, die durch den Berufsethos motiviert ist und diesen stärkt. Auch die TU Dresden hat hierzu eine neue Satzung zur &quot;Sicherung guter wissenschaftlicher Praxis, zur Vermeidung wissenschaftlichen Fehlverhaltens und für den Umgang mit Verstößen&quot; erlassen.<br /><br />Haben Sie Fragen, welche Prinzipien dabei betont werden, wie Sie diese umsetzen können und wie Sie dabei unterstützt werden können? Gerne kommen wir dazu mit Ihnen ins Gespräch.',23,1),(7,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8196,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wirkungsvoll publizieren / Impact steigern: Bibliometrie','Bibliometrie beschäftigt sich mit der Analyse des Publikations- und Zitierverhaltens in einzelnen wissenschaftlichen Fachgebieten (s. <link http://de.wikipedia.org/wiki/Bibliometrie _blank extern>Bibliometrie</link> bei Wikipedia). Bibliometrie ist daher für Forschende wie auch für Publizierende interessant und kann helfen, ein Forschungsthema bzw. wissenschaftliche Trends aufzuspüren oder ein sinnvolles Publikationsorgan zu identifizieren. Mögliche Fragen in diesem Bereich sind folgende: Wie wird der Impact-Faktor einer Zeitschrift berechnet? Wie kann ich meinen persönlichen h-Index ermitteln, beispielsweise für eine Bewerbung? Welche Zeitschriften sind für meine Publikation am besten geeignet, um im Fachgebiet stärker wahrgenommen zu werden? Wir zeigen Ihnen, welche Datenquellen Sie für Zitationsanalysen in Ihrem Fachgebiet effektiv nutzen können.',13,1),(8,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8194,51,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Medien: Karten','Die Kartensammlung der SLUB verfügt über ein umfangreiches Angebot an topographischen Karten, Handzeichnungen sowie historischen Ansichten. Im Kartenforum sind bereits 20.700 Objekte hochauflösend digitalisiert anzusehen. Gern beraten wir Sie individuell und geben Ihnen Tipps für effektive Recherchestrategien im Kartenforum. Einfach Termin buchen und mehr finden durch schlaueres Suchen.',77,1),(9,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8193,11,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Medien: Tonträger und Filme','Sie suchen für Ihre Studien Tonaufnahmen oder Filme? Etwa die eine spezielle Aufnahme des Lohengrin-Vorspiels der Sächsischen Staatskapelle oder Popularmusik aus dem Maya-Gebiet, Verfilmungen von Werken Thomas Manns? Bei Recherche, Auswahl und Bereitstellung sind wir gerne behilflich.',77,1),(10,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8192,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Datenbanken: Zeitungen bzw. Presse','Sie möchten einen Überblick und eine Einführung in das Angebot an Presse-Datenbanken (Zeitungsportale) an der SLUB bekommen? Egal, ob Sie einfach nur täglich aktuelle Zeitungen aus aller Welt lesen wollen oder ob Sie Zeitungsinhalte der letzten Jahre (Jahrzehnte) für Inhaltsanalysen benötigen. Wir stellen Ihnen die Angebote vor und geben Ihnen Tipps zur richtigen Auswahl und Recherche.',77,1),(11,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7936,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Datenbanken: Normen','Normen und Normenliteratur\nWie gehen Sie am besten vor, um DIN oder ISO-Normen zu finden?&nbsp; Wussten Sie, dass wir darüber hinaus Normen des VDE-Verlages, VDI-Richtlinien, TGLs, zurückgezogene DIN-Normen, DIN-Taschenbücher und das DWA-Regelwerk&nbsp; führen? Wir sagen Ihnen, in welchen von der SLUB lizenzierten Datenbanken&nbsp; fachspezifische Normen und Standards enthalten sind. Wir begleiten Sie von der Recherche bis zum Volltext und beraten Sie bei Bedarf zur Nutzung dieser Dokumente. \nDie Termine passen nicht? <link 7402>Sprechen Sie uns an</link>.',77,1),(12,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7808,11,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Datenbanken: Biographien','Sie suchen zu bestimmten Personen Literatur oder Nachweise? Hier gibt es Tipps dazu.',77,1),(13,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7744,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Publikationsberatung','',31,1),(14,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7712,92,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zitieren','Sie sind unsicher, was und wie zitiert wird? Wir bieten Ihnen eine  Orientierung in grundsätzlichen Fragen und generellen Übereinkünften des  Zitierens und geben einen Überblick über Sinn und Anwendung des  Zitates.',18,1),(15,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7696,77,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreiben in den Ingenieurwissenschaften','Sie arbeiten an Ihrer Haus-, Bachelor-, Master-, Diplomarbeit oder Dissertation? Von der Recherche bis zur Texterstellung – wir unterstützen Sie gern und geben Ihnen Orientierung: Wir zeigen Ihnen geeignete Recherchestrategien zum Auffinden und Beschaffen der entsprechenden Fachliteratur sowie Tools zur Verwaltung Ihrer gefundenen Dokumente. Wir geben Ihnen Hinweise zum methodischen Vorgehen bei der Erstellung wissenschaftlicher Arbeiten von der Stoffsammlung über die inhaltliche Strukturierung (z.B. Titel, Zusammenfassung, Stichwörter, Einleitung, Methoden, Resultate, Diskussion, das Fazit, Referenzen, usw.) bis hin zu Konsistenz, Logik, Grammatik der Sprache sowie zur Platzierung von Illustrationen und Diagrammen im Text.',18,1),(16,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7688,7,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreiben in den Naturwissenschaften und in der Medizin','Sie arbeiten an Ihrer Haus-, Bachelor-, Master-, Diplomarbeit oder Dissertation? Von der Recherche bis zur Texterstellung – wir unterstützen Sie gern und geben Ihnen Orientierung: Wir zeigen Ihnen geeignete Recherchestrategien zum Auffinden und Beschaffen der entsprechenden Fachliteratur sowie Tools zur Verwaltung Ihrer gefundenen Dokumente. Wir geben Ihnen Hinweise zum methodischen Vorgehen bei der Erstellung wissenschaftlicher Arbeiten von der Stoffsammlung über die inhaltliche Strukturierung (z.B. Titel, Zusammenfassung, Stichwörter, Einleitung, Methoden, Resultate, Diskussion, das Fazit, Referenzen, usw.) bis hin zu Konsistenz, Logik, Grammatik der Sprache sowie zur Platzierung von Illustrationen und Diagrammen im Text.',18,1),(17,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7684,32,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreiben in den Geistes- und Sozialwissenschaften','Sie arbeiten an Ihrer Haus-, Bachelor-, Master-, Diplomarbeit oder Dissertation? Von der Recherche bis zur Texterstellung – wir unterstützen Sie gern und geben Ihnen Orientierung: Wir zeigen Ihnen geeignete Recherchestrategien zum Auffinden und Beschaffen der entsprechenden Fachliteratur sowie Tools zur Verwaltung Ihrer gefundenen Dokumente. Wir geben Ihnen Hinweise zum methodischen Vorgehen bei der Erstellung wissenschaftlicher Arbeiten von der Stoffsammlung über die inhaltliche Strukturierung (z.B. Titel, Zusammenfassung, Stichwörter, Einleitung, Methoden, Resultate, Diskussion, das Fazit, Referenzen, usw.) bis hin zu Konsistenz, Logik, Grammatik der Sprache sowie zur Platzierung von Illustrationen und Diagrammen im Text.',18,1),(18,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7682,32,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissenschaftliches Schreiben und Zitieren','',31,1),(19,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7681,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Statistiken erstellen / Analysetools nutzen','Sie schreiben eine wissenschaftliche Arbeit vor und wollen komplizierte Themen übersichtlich darstellen? Sie suchen dazu ergänzendes Zahlenmaterial? \nViele Portale bieten bereits fertige Statistiken als Komplettlösung an, die zur sofortigen Weiterverwendung geeignet sind. Weitere Möglichkeiten bieten Ihnen unsere lizenzierten Datenbanken, die über ein entsprechendes Analysetool verfügen, das wiederum zur Gewinnung statistischer Daten verwendet werden kann.\nWir informieren Sie gern und geben Ihnen Hinweise zur effektiven Nutzung dieser wertvollen Quellen.',24,1),(20,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7680,8,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Informationsvisualisierung','Umfangreiche Forschungsergebnisse und große Datenmengen lassen sich mit Hilfe der Informationsvisualisierung leicht veranschaulichen. In Zusammenarbeit mit dem Lehrstuhl Mediengestaltung sind bereits mehrere studentische Arbeiten in diesem Bereich entstanden. Wir bieten eine Basis-Beratung als Einführung an und vermitteln bei Bedarf den Kontakt zu ExpertInnen auf dem Gebiet. Bitte schildern Sie uns Ihr konkretes Anliegen und geben Sie uns einige Tage Vorbereitungszeit, damit wir uns auf Ihre spezifische Frage optimal vorbereiten können.',24,1),(21,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7424,36,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Textverarbeitungsprogramme','Textverarbeitungsprogramme wie Word oder Open Office Writer kann jeder bedienen. Wenn man aber eine wissenschaftliche Hausarbeit oder eine Dissertation schreibt, sollte man professionellen Gebrauch von diesen Instrumenten machen. Wir beraten Sie, wie Sie Datei-Templates und Formatvorlagen, Index- und Inhaltsverzeichnisfunktionen sinnvoll einsetzen und Ihre Datei so erstellen, dass Sie mit einem Klick ein publizierbares Dokument erzeugen können. Wenn Sie Beratung zu speziellen Textverarbeitungsprogrammen wie LaTeX oder AsciiDoc suchen, geben Sie uns einige Tage Zeit, um uns optimal vorbereiten zu können.',24,1),(22,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7296,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Literaturverwaltung','Sie schreiben eine Examensarbeit oder bereiten eine wissenschaftliche Publikation vor und suchen nach einer Möglichkeit, die benutzte Literatur zu sammeln, zu verwalten und sie nach den Ihnen vorgegebenen Zitierregeln in Ihre Fußnoten bzw. Bibliographie einzufügen? Lassen Sie sich von uns informieren über die für solche Aufgaben zur Verfügung stehenden Literaturverwaltungsprogramme. Wenn Sie bereits ein Literaturverwaltungsprogramm benutzen, zeigen wir Ihnen gerne, wie Sie noch mehr aus der Software herausholen können.',24,1),(23,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7232,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gute wissenschaftliche Praxis','',31,1),(24,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7200,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Werkzeuge','',31,1),(25,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7184,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Pflichtexemplarabgabe','<span>Haben Sie Fragen zur Pflichtexemplarregelung in Sachsen? Sind sie unsicher, ob Ihre Publikation abgabepflichtig an die SLUB nach dem Sächs. Pressegesetz ist? Benötigen Sie Hilfe beim Publizieren elektronischer Veröffentlichungen. Zu allen Themen Rund um die Pflichtexemplarabgabe, auch bezüglich langzeitarchivfähiger Dateiformate beraten wir Sie sehr gern.</span>',13,1),(26,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7176,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Akademisches Identitätsmanagement','Im gesamten Forschungsprozess sind Sie zunehmend gefragt, sich selbst sowie Ihre Forschungsarbeit und institutionelle Zugehörigkeit zu präsentieren. Wie sichern Sie jedoch die eindeutige Zuordnung Ihrer wissenschaftlichen Publikationen zu Ihrer Person? Personennamen sind weder unverwechselbar noch unveränderlich. Unterschiedliche Schreibweisen in verschiedenen Sprachen und Datenbanken erschweren zudem das Auffinden und darauf aufbauende Analysen bibliometrischer Kennzahlen wie beispielsweise dem H-Index. Und wie benennen Sie Ihre institutionelle Zugehörigkeit / Affiliation angemessen?\nLassen Sie sich von uns informieren über ORCID iD, ResearcherID, Scopus Author ID, Google Scholar Profile. Wir beraten Sie bei der Auswahl und Einrichtung eigener Autorenprofile. Haben Sie bereits eine oder mehrere IDs, geben wir Tipps zur Datenpflege und zur effizienten Nutzung dieser IDs.',13,1),(27,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7172,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Open Educational Resources (OER)','Open Educational Resources (OER) sind Bildungsressourcen jeder Art, die unter einer offenen Lizenz publiziert werden. Dadurch können sie meist frei heruntergeladen, verwendet, bearbeitet und wieder verbreitet werden.\nWir beraten Sie sowohl bei der Recherche nach OER als auch zur Lizenzvergabe und technischen Umsetzung, wenn Sie selbst Lehrmaterialien produzieren und mit Anderen teilen möchten.',13,1),(28,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7170,8,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Forschungsdatenmanagement - Basics und mehr','Der systematische Umgang mit Forschungsdaten ist seit einigen Jahren ein immer wichtiger werdendes Thema im wissenschaftlichen Arbeitsprozess und Teil guter wissenschaftlicher Praxis. Der Aufwand lohnt sich insbesondere mittel- und langfristig um:&nbsp;\n<ul><li>Daten zu finden und zu verstehen,&nbsp;</li><li>Sichere Aufbewahrung = Schutz vor Missbrauch,</li><li>Vorbeugen von Datenverlust in jeder Projektphase,</li><li>Nutzbarkeit für neue Vorhaben,</li><li>Erfüllung Anforderungen Dritter (z.B. Förderrichtlinien, Policies, …)</li></ul>\nForschungsförderer wie die DFG oder die Europäische Union stellen vermehrt Anforderungen an das Management von Forschungsdaten in allen Phasen eines Forschungsprojekts. Wir beraten Sie umfassend sowohl zu technischen, inhaltlichen als auch rechtlichen Aspekten des Forschungsdatenmanagements. Dazu kooperiert die SLUB mit verschiedenen Einrichtungen der TU Dresden unter dem Dach einer zentralen <link https://tu-dresden.de/forschung/services-fuer-forschende/kontaktstelle-forschungsdaten/>Kontaktstelle Forschungsdaten</link>﻿. Wir beraten Sie deshalb gemeinsam und Sie können auch mit unseren externen Partnern Beratungstermine vereinbaren. Sie erfahren zum Beispiel, wie Sie einen Datenmanagementplan entwickeln, Ihre Daten effektiv organisieren und wo und wie Sie am besten Ihre Daten aus Ihrem Forschungsprojekt veröffentlichen können. Bitte schildern Sie uns Ihr konkretes Anliegen und geben Sie uns einige Tage Vorbereitungszeit, damit wir uns auf Ihre Frage optimal vorbereiten können.&nbsp;',112,1),(29,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7169,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Elektronisches Publizieren, Open Access und Qucosa','Sie wollen Ihre Publikation frei zugänglich im Open Access-Modell veröffentlichen? Wir beraten Sie zu inhaltlichen Fragen, welche Verlage eine Open Access-Zweitveröffentlichung genehmigen, welche Open Access-Zeitschriften es in Ihrem Fachgebiet gibt und wie Sie die Publikation in dieser Zeitschrift finanzieren können.',13,1),(30,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,7168,0,1,31,'a:5:{s:11:\"l10n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:10:\"genius_bar\";N;s:6:\"parent\";N;}','{\"starttime\":\"parent\",\"endtime\":\"parent\"}',0,'Writing / Publishing','<p>Writing a scientific paper usually involves several phases: Idea, orientation, research, structuring, rough version and revision. When a research result is fixed in writing, it needs to be published. We support and advise you competently with regard to the creation and publication of documents as well as the tools and the relevant areas of knowledge in this context.</p>',3,1),(31,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6912,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreiben / Publizieren','<p>Zum Schreiben einer wissenschaftlichen Arbeit gehören zumeist mehrere Phasen: Idee, Orientierung, Recherche, Strukturierung, Rohfassung und Überarbeitung. Ist ein Forschungsergebnis schriftlich fixiert, muss es publiziert werden. Unsere Mitarbeiter unterstützen und beraten Sie kompetent hinsichtlich der Erstellung und Publikation von Dokumenten sowie hinsichtlich der Hilfsmittel und der in diesem Zusammenhang relevanten Wissensbereiche.</p>',3,1),(32,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6784,36,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Textanalyse','<p>Mit Hilfe von Textmining-Tools lassen sich große Textmengen quantitativ untersuchen, um aus der Vogelperspektive (&quot;distant reading&quot; lautet eins der Schlagwörter) neue Entdeckungen zu machen. Dabei helfen Visualisierungen und statistische Auswertungen. Wir beraten Sie gerne zu der Fülle der Angebote, angefangen bei einer einfachen Tagcloud (Wordle) über Googles Culturomics für Kulturwissenschaftliche Untersuchungen über längere Zeiträume bis hin zu avancierteren Tools für den wissenschaftlichen Einsatz. Bitte schildern Sie uns Ihr konkretes Anliegen und geben Sie uns einige Tage Vorbereitungszeit, damit wir uns auf Ihre spezifische Frage optimal vorbereiten können.</p>',74,1),(33,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6720,7,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Feeds und Alerting Services','Sie möchten immer auf dem neuesten Stand der Forschung bleiben - und das mit möglichst geringem Zeitaufwand? Alerting-Dienste und Feeds versorgen Sie automatisiert und regelmäßig&nbsp; mit aktuellen Informationen über Ihre Forschungsgebiete. Gern beraten wir Sie bei der Auswahl geeigneter Dienste und&nbsp; unterstützen Sie bei der Einrichtung maßgeschneiderter&nbsp; Abfragen.',81,1),(34,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6688,36,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Twitter in der Wissenschaft','Sie haben auf einer Konferenz oder von KommilitonInnen von Twitter gehört und möchten es nun selbst ausprobieren? Sie nutzen Twitter bereits als Informationskanal, sind aber bei der Verwendung von Hashtags, Mentions und der Netikette unsicher? Wir beraten Sie, wie Sie Twitter optimal zur Vernetzung in der Wissenschaft nutzen können.',81,1),(35,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6672,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Elektronik- und Mikrocontroller-Grundlagen','Ob einfache LED-Blinkschaltung oder Geflecht aus Sensoren und Aktoren, wir beraten Sie bei der Umsetzung Ihrer ersten Elektronikprojekte. Wir zeigen Ihnen die Möglichkeiten und Funktionen elektronischer Schaltungen sowie von Arduino, ESP8266, ESP32 und RaspberryPi. Auch beim Entwurf erster eigener Platinen mit der OpenSource-Software KiCAD können wir Sie unterstützen.',78,1),(36,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6664,201,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'3D-Gipsdruck','Hier werden die folgenden Fragen beantwortet: Was kann man mit 3D-Druck machen? Was geht mit den Geräten des Makerspaces? Wie muss man sein 3D Modell vorbereiten? Wie kommt man eigentlich zu einem 3D-druckbaren Modell?',78,1),(37,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6660,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'3D-Druck','Hier werden die folgenden Fragen beantwortet: Was kann man mit 3D-Druck machen? Was geht mit den Geräten des Makerspaces? Wie muss man sein 3D Modell vorbereiten? Wie kommt man eigentlich zu einem 3D-druckbaren Modell?',78,1),(38,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6658,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Laserschneiden und -gravieren','',78,1),(39,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6657,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Modellierung 2D/3D','Im Makerspace können Sie Ihre zwei- und dreidimensionalen Modelle realisieren. Wir unterstützen Sie bei Fragen rund um die Erstellung Ihrer Modelle mit den typischen Softwarelösungen. Um Sie optimal beraten zu können, wählen Sie Ihren Berater bitte entsprechend der zu verwendenden Software aus und &nbsp;geben Sie diese sowie eine Beschreibung Ihres Projekts bei Ihrer Anfrage an.',78,1),(40,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6656,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Recherchestrategien und Recherchemittel','Wie gehen Sie am besten vor, um geeignete Literaturquellen zur Bearbeitung Ihres Themas systematisch zu finden und auszuwerten? Dies ist eine Herausforderung, besonders dann wenn Sie sich erst einen Überblick verschaffen wollen. An den Servicetheken ist leider nicht immer die notwendige Zeit vorhanden, um Sie adäquat zu unterstützen. In einer persönlichen Beratung zeigen wir Ihnen in aller Ruhe, welche Recherchemittel in der SLUB zur Verfügung stehen und auf welchem Weg Sie die gewünschten Dokumente erhalten können. Wir vermitteln Ihnen bestmögliche Suchstrategien und geben bei Bedarf Empfehlungen aus unserem umfangreichen Serviceangebot. Kommen Sie zu uns in die Wissensbar.',79,1),(41,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6400,36,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Virtuelle Forschungsumgebungen','Sie sind auf der Suche nach einer Arbeitsplattform für Ihr Forschungsprojekt? Virtuelle Forschungsumgebungen sind definiert als <i>Arbeitsplattform, die eine kooperative Forschungstätigkeit durch mehrere Wissenschaftlerinnen und Wissenschaftler an unterschiedlichen Orten zu gleicher Zeit ohne Einschränkungen ermöglicht </i>(vgl. <a data-htmlarea-external=\"1\" class=\"extern\" target=\"_blank\" href=\"http://www.allianzinitiative.de/de/\">Schwerpunktinitiative &quot;Digitale Information&quot;</a>). In manchen Fächern haben sich bereits solche vollumfassenden Forschungsumgebungen etabliert, die den gesamten Forschungsprozess von Erhebung über Diskussion und Bearbeitung der Daten bis zur Publikation abdecken. In anderen Fächern lassen sich auf generische Tools zurückgreifen. Wir beraten Sie gerne zu den neuen Möglichkeiten. Bitte schildern Sie uns Ihr konkretes Anliegen und geben Sie uns einige Tage Vorbereitungszeit, damit wir uns auf Ihre spezifische Frage optimal vorbereiten können.',74,1),(42,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6272,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Technik / Technologien','<p>Die Benutzung der Bibliothek und die Navigation im Meer der Information setzt Wissen über Technik und Technologien voraus. Wir beraten Sie gern in diesem Bereich.</p>',3,1),(43,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6208,0,1,44,'a:5:{s:11:\"l10n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:10:\"genius_bar\";N;s:6:\"parent\";N;}','{\"starttime\":\"parent\",\"endtime\":\"parent\"}',0,'Study / Research','<p>EN:</p>\n<p>Wir unterstützen das Lernen und das Forschen durch professionelle Beratung hinsichtlich informationsorganisatorischer Methodik und technologischer Hilfsmittel.</p>\n<p>Hilfe bei fachspezifischen Fragen zur Lern- und Forschungsmethodik leisten Ihnen unsere Fachreferenten.</p>',3,1),(44,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6176,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Lernen / Forschen','Wir unterstützen das Lernen und das Forschen durch professionelle Beratung hinsichtlich informationsorganisatorischer Methodik und technologischer Hilfsmittel. \nHilfe bei fachspezifischen Fragen zur Lern- und Forschungsmethodik leisten Ihnen unsere Fachreferenten.',3,1),(45,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6160,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Langzeitarchivierung','<span>Sie fragen sich, wie digitale Dokumente über lange Zeiträume (50 Jahre+) benutzbar bleiben sollen. Sie wollen digitale Dokumente über Qucosa zur Verfügung stellen und möchten eine lange Nutzung ermöglichen. Wir erklären Ihnen unsere Langzeitarchivierung und beraten Sie bei der Auswahl der Datenformate und der Prüfung ihrer Dokumente.&nbsp;</span>',42,1),(46,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6152,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wirtschaftswissenschaften','Das AQUA-Modul ist schon lange her und nur noch verschwommen in Erinnerung? Jetzt könnten Sie aber diese Recherchetipps und Hilfen gut für Ihre Haus- oder Bachelorarbeit brauchen? Ich berate Sie gern zu speziellen Rechercheangeboten für Wirtschaftswissenschaftler - als Erstberatung, Auffrischung oder weiterführende Beratung für Fortgeschrittene. Gern gehe ich dabei auf Ihr jeweiliges Thema ein und berate Sie individuell.',75,1),(47,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6148,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Themen: Sachsen','Wie gestalte ich meine Suche, wenn ich ein Thema zu Sachsen bearbeite? Welche Literatur und Quellen stehen mir in der SLUB zur Verfügung? Welche Recherchemöglichkeiten kann ich nutzen? Wir stellen Ihnen die Angebote vor und geben Ihnen Hinweise zu Ihrem speziellen Thema.',77,1),(48,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6146,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Verkehrswesen / FID Mobilitäts- und Verkehrsforschung','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',76,1),(49,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6145,30,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Umweltwissenschaft','Biomasseanbau und Nachhaltigkeit und ich brauche mehr als nur zwei Bücher. Tipps für effektive Recherchestrategien gibts hier. Einfach Termin buchen und&nbsp; mehr finden durch schlaueres Suchen.',76,1),(50,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,6144,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Technikgeschichte','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',75,1),(51,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5888,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Themen: Nachlässe','Wie gestalte ich meine Suche, wenn ich Nachlässe bzw. einzelne Dokumente in Nachlässen bearbeite? Welche Nachweisinstrumente stehen mir in der SLUB zur Verfügung? Wie werden Nachlässe erschlossen? Wie ist ein Findbuch aufgebaut? Wie gehe ich mit dem eigenen Familienarchiv um?',77,1),(52,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5760,11,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Themen: Familienforschung','Wie beginne ich mit der Familienforschung? Wie forsche ich? Welche Literatur und Quellen stehen mir zur Verfügung? Und welche Literatur und Quellen befinden sich zur Familienforschung in der SLUB? Auf diese Fragen erhalten Sie bei uns die Antworten.',77,1),(53,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5696,60,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Romanistik','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Gern beraten wir Sie zu Recherchestrategien und Datenquellen für das Fach Romanistik.',75,1),(54,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5664,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Rechtswissenschaft','Sie suchen Quellen und Fundstellen zu einem ganz bestimmten Thema und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Ich berate Sie gern zu Recherchestrategien und Datenquellen für alle Rechtsgebiete. Gern gehe ich dabei auf Ihr jeweiliges Thema ein und berate Sie individuell.',75,1),(55,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5648,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Psychologie','Kognitive Performance und Prüfungsangst? Sie suchen Literatur und wissen nicht, wie Sie schnell an die Volltexte kommen? Der Termin für die Abgabe der Master-Arbeit rückt immer näher und das Literaturverzeichnis muss noch einmal geprüft werden. Aber in welcher Zeitschrift waren die zitierten Artikel? Für individuelle Hilfe gibt es hier Termine.',76,1),(56,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5640,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Politikwissenschaft','Sie suchen Fachliteratur zu einem ganz bestimmten Thema und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Wir beraten Sie gern zu Recherchestrategien und Datenquellen für die Politikwissenschaften. Gern gehen wir dabei auf Ihr jeweiliges Thema ein und beraten Sie individuell.',75,1),(57,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5636,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Physik / Astronomie','<span style=\"font-family: Arial, Helvetica, FreeSans, sans-serif; font-size: 13px; line-height: 17.328125px; text-align: left; \">Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?</span>',76,1),(58,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5634,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Musik','Die SLUB verfügt über ein besonders reichhaltiges und wichtiges Angebot an Musikalien. Die wertvollsten Noten der SLUB, etwa die in Autographen von Bach und Vivaldi gipfelnden Musikalien der Dresdner Hofkapelle, sind handschriftlich überliefert. Darüber hinaus finden Sie zahlreiches modernes Studien- und Aufführungsmaterial sowie genreübergreifende Sekundärliteratur. Die umfangreiche Tonträger- und Filmsammlung der Mediathek ergänzt dieses Angebot umfassend. Gerne unterstützen wir Sie bei Rechercheanfragen zu Noten, Tonträgern und musikwissenschaftlicher Literatur.',75,1),(59,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5633,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Medizin','<p>Sie suchen Fachliteratur zu einem ganz bestimmten Thema und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst &nbsp;recherchiert und wollen Ihre Suche verfeinern? Planen Sie eine &nbsp;systematische Übersichtsarbeit oder eine Meta-Analyse? Hier finden Sie &nbsp;individuelle Beratung und erfahren Tipps und Tricks zur Optimierung &nbsp;Ihrer Recherchestrategie, insbesondere in PubMed / Medline, Embase und &nbsp;Web of Science.</p><p></p><p></p>',76,1),(60,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5632,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Mathematik','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',76,1),(61,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5376,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Maschinenwesen und Werkstoffwissenschaft','<span style=\"font-family: Arial, Helvetica, FreeSans, sans-serif; font-size: 13px; line-height: 17.328125px; text-align: left; \">Sie suchen Fachliteratur zu einem ganz bestimmten Thema und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Ich berate Sie gern zu Recherchestrategien und Datenquellen für das Maschinenwesen und die Werkstoffwissenschaft. Gern gehe ich dabei auf Ihr jeweiliges Thema ein und berate Sie individuell.</span>',76,1),(62,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5248,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Landwirtschaft','Pflanzenstärkungsmittel im ökologischen Apfelanbau und der sächsische Imkerbericht vom letzten Jahr? Nicht nur für diese Fachliteratur gibt es hier Beratung zur erfolgreichen Recherche.',76,1),(63,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5184,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kunst ab 1945, Fotografie und Industriedesign','Sie haben Fragen zu einer fachlichen Recherche, z. B. in arthistoricum.net, dem virtuellen Kernangebot des Fachinformationsdienstes Kunst oder zu speziellen Bild- oder Textquellen?&nbsp;\n<div></div>',75,1),(64,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5152,25,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kommunikationswissenschaft','Die SLUB-Einführungen vom 1. Semester sind schon lange her und nur noch verschwommen in Erinnerung? Jetzt könnten Sie aber diese Recherchetipps und Hilfen gut für Ihre Haus- oder Bachelorarbeit brauchen? Wir beraten Sie gern zu speziellen Rechercheangeboten für Kommunikationswissenschaftler - als Erstberatung, Auffrischung oder weiterführende Beratung für Fortgeschrittene. Gern gehen wir dabei auf Ihr jeweiliges Thema ein und beraten Sie individuell.',75,1),(65,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5136,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Klassische Philologie','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten  einen Überblick über geeignete Datenquellen? Sie haben schon selbst  recherchiert und wollen Ihre Suche verfeinern? Gern beraten wir Sie zu  Recherchestrategien und Datenquellen für das Fach Klassische Philologie.',75,1),(66,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5128,56,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Geschichte und Landesgeschichte','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',75,1),(67,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5124,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Germanistik','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',75,1),(68,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5122,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Erziehungswissenschaften','Sie suchen Fachliteratur zu einem ganz bestimmten Thema und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Wir beraten Sie gern zu Recherchestrategien und Datenquellen für die Erziehungswissenschaften. Gern gehen wir dabei auf Ihr jeweiliges Thema ein und beraten Sie individuell.',75,1),(69,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5121,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Elektrotechnik (einschließlich Nachrichtentechnik)','<span style=\"font-family: Arial, Helvetica, FreeSans, sans-serif; font-size: 13px; line-height: 17.328125px; text-align: left; \">Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?</span>',76,1),(70,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,5120,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Chemie','Prüfungsangst und 3,4,9,10-Tetrathioperylen?<br />Sie suchen Literatur und wissen nicht, wie Sie schnell an die Volltexte kommen. Der Termin für die Abgabe der Master-Arbeit rückt immer näher und das Literaturverzeichnis muss noch einmal geprüft werden. Aber in welcher Zeitschrift waren die zitierten Artikel?',76,1),(71,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4864,25,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Biologie','Prüfungsangst und Corticotropin-releasing Hormone?<br />Sie suchen Literatur und wissen nicht, wie Sie schnell an die Volltexte kommen. Der Termin für die Abgabe der Master-Arbeit rückt immer näher und das Literaturverzeichnis muss noch einmal geprüft werden. Aber in welcher Zeitschrift waren die zitierten Artikel?',76,1),(72,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4736,69,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Bauingenieurwesen und Architektur','<span style=\"font-family: Arial, Helvetica, FreeSans, sans-serif; font-size: 13px; line-height: 17.328125px; text-align: left; \">Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?</span>',76,1),(73,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4672,25,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Anglistik / Amerikanistik','Das SLUB-Tutorium ist schon lange her und nur noch verschwommen in Erinnerung? Jetzt könnten Sie aber diese Recherchetipps und Hilfen gut für Ihre Haus- oder Bachelorarbeit brauchen? Ich berate Sie gern zu speziellen Rechercheangeboten für Anglisten und Amerikanisten - als Erstberatung, Auffrischung oder weiterführende Beratung für Fortgeschrittene. Gern gehe ich dabei auf Ihr jeweiliges Thema ein und berate Sie individuell.',75,1),(74,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4640,8,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Digital Scholarship','',44,1),(75,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4624,33,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Geistes- und Sozialwissenschaften: Recherche','',44,1),(76,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4616,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Natur- und Ingenieurwissenschaften, Medizin: Recherche','',44,1),(77,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4612,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Thematische Recherche','',44,1),(78,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4610,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Makerspace','',42,1),(79,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4609,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Recherche allgemein','',44,1),(80,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4608,0,1,81,'a:5:{s:11:\"l10n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:10:\"genius_bar\";N;s:6:\"parent\";N;}','{\"starttime\":\"parent\",\"endtime\":\"parent\"}',0,'Doing research work and networking','',44,1),(81,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4352,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissenschaftliches Arbeiten und Vernetzen','',44,1),(82,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4224,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Datenformate, Validierung, Forschungsdaten','Sie fragen sich, wie digitale Dokumente über lange Zeiträume (50 Jahre+) benutzbar bleiben sollen. Sie wollen digitale Dokumente über Qucosa zur Verfügung stellen und möchten eine lange Nutzung ermöglichen. Wir erklären Ihnen unsere Langzeitarchivierung und beraten Sie bei der Auswahl der Datenformate und der Prüfung ihrer Dokumente.',45,1),(83,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4160,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Sicherheit im Internet','Sie fangen gerade an, das Internet für Recherchen zu entdecken? Sie möchten Social Networks, Newsgroups, Foren und Communities nutzen, fühlen sich dabei aber unwohl? Wir zeigen Ihnen, wie Sie im Internet diese Dienste gefahrloser und sicher nutzen können. Geben Sie uns einige Tage Zeit, um uns optimal vorbereiten zu können.',2,1),(84,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4128,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Benutzerkonto und -service für hörgeschädigte Nutzer','Sie sind zum ersten Mal in der SLUB oder benötigen Hilfe beim Einrichten Ihres Benutzerkontos? Wie können Sie mit dem SLUB-Account Ihre Medien verlängern? Wo finden Sie Ihre Bestellungen? Und überhaupt, wie ist das mit Kennwort und Pin? Wir helfen Ihnen bei der Beantwortung Ihrer Fragen rund um den Ausleihservice.',79,1),(85,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4112,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Soziale Netzwerke und wissenschaftliche Karriere','<link http://www.researchgate.net/ - extern>ResearchGate</link>, <link http://www.academia.edu/ - extern>Academia.edu</link> und weitere soziale Netzwerke für WissenschaftlerInnen sind in den letzten Jahren entstanden, hinzu kommen Klassiker wie <link https://www.xing.com/ - extern>Xing</link> oder <link http://www.linkedin.com/ - extern>LinkedIn</link> sowie auf Literaturverwaltungsprogrammen basierende Communities wie <link http://www.mendeley.com/ - extern>Mendeley</link>. Wie kann ich die Wahrnehmung meiner Forschungsarbeiten in den wissenschaftlichen Communities steigern? Wie finde ich heraus, welche Informationen für mich wichtig sind und wie kann ich diese bewerten? Welche Stolpersteine gilt es zu verhindern? Welche Synergien können genutzt&nbsp; werden? Wir beantworten gerne Ihre Fragen und geben Tipps zum Umgang mit sozialen Netzwerken.',81,1),(86,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4104,0,0,0,'a:7:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Vorlesungsreihen','',0,0),(87,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4100,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Ausstellungseröffnungen','',1,0),(88,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4098,0,0,0,'a:7:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Ausstellungen','',0,0),(89,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4097,0,0,0,'a:7:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Tagung','',0,0),(90,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4096,0,0,0,'a:7:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Beratung','',0,0),(91,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3840,105,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen im Buchmuseum','',93,0),(92,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3712,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen im Buchmuseum','',94,0),(93,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3648,1,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen','',109,0),(94,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3616,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:5:\"title\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Führungen','',0,0),(95,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3600,124,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Online-Seminar','',110,0),(96,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3592,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Online-Seminar','',111,0),(97,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3588,164,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissenschaftliches Schreiben und Zitieren','',110,0),(98,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3586,131,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissenschaftliches Schreiben und Zitieren','',111,0),(99,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3585,135,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Textverarbeitung','',110,0),(100,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3584,133,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Literaturverwaltung','',110,0),(101,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3328,132,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Literaturverwaltung','',111,0),(102,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3200,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Textverarbeitung','',111,0),(103,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3136,140,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Open Science / Publishing','',110,0),(104,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3104,132,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Open Science / Publishing','',111,0),(105,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3088,132,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Erfolgreich Recherchieren','',110,0),(106,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3080,131,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Erfolgreich Recherchieren','',111,0),(107,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3076,131,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB-Einsteiger','',110,0),(108,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3074,2,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB-Einsteiger','',111,0),(109,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3073,2,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;}',NULL,0,'Nichtöffentliche Veranstaltungen','',0,0),(110,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3072,2,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kurse / Workshops','',109,0),(111,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2816,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;}',NULL,0,'Kurse / Workshops','',0,0),(112,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2688,144,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Forschungsdatenmanagement','',42,1),(113,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2624,122,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Makerspace','',110,0),(114,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2592,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Makerspace','',111,0),(115,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2576,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Vorträge / Präsentationen','',1,0),(116,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2568,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Musik / Konzerte','',1,0),(117,9,1624970644,1624969571,1,1,0,0,0,0,0,0,'',0,0,0,0,0,2564,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'SLUB Impftermine','',0,0),(118,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2562,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Themen: Handschriften','Wie gestalte ich meine Suche, wenn ich Handschriften bearbeite? Welche Literatur und Quellen stehen mir in der SLUB zur Verfügung? Welche Recherchemöglichkeiten kann ich nutzen? Wir stellen Ihnen die Angebote vor und geben Ihnen Hinweise für Ihr spezielles Thema.',77,1),(119,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2561,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Soziologie','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Gern&nbsp; beraten wir Sie zu Recherchestrategien und Datenquellen für das Fach Soziologie. Zusätzlich bieten wir Ihnen Beratungen bei Fragen im Kontext der quantitativen Datenerhebung, der statistischen Analyse eigener oder fremder Daten sowie der Benutzung des Programmes R an.',75,1),(120,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2560,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Philosophie','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Gern&nbsp; berate ich Sie zu Recherchestrategien und Datenquellen für das Fach Philosophie.',75,1),(121,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2304,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Theologie','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten einen Überblick über geeignete Datenquellen? Sie haben schon selbst recherchiert und wollen Ihre Suche verfeinern? Gern&nbsp;beraten wir&nbsp;Sie zu Recherchestrategien und Datenquellen für das Fach Theologie.',75,1),(122,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2176,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Forstwesen','Sie suchen Fachliteratur zu einem bestimmten Themenkomplex und möchten einen Überblick über geeignete Datenquellen und forstspezifische Datenbanken?\nBuchen Sie einen der angegebenen Termine oder teilen Sie mir Interesse kund und wir vereinbaren einen passenden Zeitpunkt.',76,1),(123,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2112,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Informatik','Sie haben Fragen, z.B. zu speziellen Quellen oder einer fachlichen Recherche?',76,1),(124,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2080,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Texterkennung','Durch die zunehmende Verfügbarkeit digitalisierter, insbesondere historischer, Quellen steigen auch die Ansprüche an deren Beforschung. Methoden der automatischen Texterkennung helfen bei der Erzeugung maschinenlesbarer Volltexte, die wiederum die Voraussetzung für den Einsatz quantitativer Verfahren in der Textanalyse oder -annotation darstellen.\nWir beraten Sie zu allen Fragen zu Werkzeugen, Formaten und Methoden im Bereich der automatischen Texterkennung, sei es für Drucke (OCR) oder Handschriften (HTR), und zeigen Perspektiven für die Aufwertung der Texte zu adäquaten digitalen Reproduktionen.',126,1),(125,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2064,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Landesdigitalisierungsprogramm','Sie sind für eine sächsische Kultur- und Wissenschaftseinrichtung tätig und möchten gern kulturell bedeutsame Bestände digitalisieren lassen? Im Landesdigitalisierungsprogramm für Wissenschaft und Kultur des Freistaates Sachsen haben Sie die Möglichkeit dazu. In einem individuellen Beratungsgespräch beantworten wir Ihnen gern alle Fragen zur Teilnahme am Landesdigitalisierungsprogramm, wie: Welche Bestände sind für das Digitalisierungsprogramm geeignet? Wie werden die zu digitalisierenden Werke ausgewählt? Welche Institutionen können ihre Bestände zur Digitalisierung vorschlagen? Welche Voraussetzungen, Nachweise und Erklärungen muss meine Institution vorweisen? Welche Eigenleistung wird von meiner Institution erwartet? Buchen Sie jetzt Ihren persönlichen Termin bei dem Team der Geschäftsstelle Landesdigitalisierungsprogramm.',126,1),(126,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2056,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Digitalisierung','',42,1),(127,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2052,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Spezielle Datenbanken: Patente, Marken und Designs','Wussten Sie, dass weltweit ca. 80 Millionen Patentdokumente existieren, derzeit jährlich ca. 3,5 Millionen Patente und Gebrauchsmuster neu angemeldet werden und ca. 80 % des aktuellen Wissens in keiner anderen Literatur als in der Patent-Literatur zu finden ist?&nbsp;Sie möchten einen Überblick und eine Einführung in das Angebot an Schutzrechts-Datenbanken (Patente, Gebrauchsmuster, Marken und Designs) im Patentinformationszentrum (PIZ) an der TU Dresden bekommen? Dann führen wir Ihnen vor Ort im PIZ, direkt gegenüber der SLUB (im Andreas-Schubert-Bau, 1. Etage), praktisch die Möglichkeiten des Recherchierens in freien und kommerziellen Schutzrechts-Datenbanken vor. Anschließend können Sie gern auch gleich Ihre eigenen Themen bearbeiten.',77,1),(128,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2050,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen im Makerspace','Die Führung bietet neben Erläuterungen zum Konzept des Makerspace einen Überblick über die vorhandene Ausstattung, die Geräte sowie die Serviceleistungen, die wir Ihnen bieten. Individuell und je nach Interessenslage der Teilnehmer werden einzelne Geräte wie die Lasergravier- und –schneideinrichtung oder die 3D-Drucker demonstriert.',93,0),(129,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2049,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen im Makerspace','Die Führung bietet neben Erläuterungen zum Konzept des Makerspace einen Überblick über die vorhandene Ausstattung, die Geräte sowie die Serviceleistungen, die wir Ihnen bieten. Individuell und je nach Interessenslage der Teilnehmer werden einzelne Geräte wie die Lasergravier- und –schneideinrichtung oder die 3D-Drucker demonstriert.',94,0),(130,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2048,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB-interne Veranstaltung','',109,0),(131,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1792,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen in der SLUB','<span>Führung durch die Zentralbibliothek der SLUB und ihre Bestände, kurze Einführung in den SLUB-Katalog, in die Selbstbedienungsfunktionen, die Aufstellungssystematik, die Benutzungs- und Ausleihmodalitäten sowie den Service.</span>',93,0),(132,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1664,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Führungen in der SLUB','<span>Führung durch die Zentralbibliothek der SLUB und ihre Bestände, kurze Einführung in den SLUB-Katalog, in die Selbstbedienungsfunktionen, die Aufstellungssystematik, die Benutzungs- und Ausleihmodalitäten sowie den Service.</span>',94,0),(133,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1600,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreiben','',159,0),(134,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1568,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe','',133,0),(135,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1552,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe Studierende','',134,0),(136,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1544,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe Promovierende','',134,0),(137,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1540,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe Postdocs','',134,0),(138,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1538,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe Lehrende','',134,0),(139,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1537,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Veranstaltungsformat','',133,0),(140,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1536,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kurzworkshop','Workshop mit einer Dauer von max. 3h',139,0),(141,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1280,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Workshop','ganztägige Veranstaltung',139,0),(142,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1152,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreibklausur','mehrtägige Veranstaltung an einem Ort außerhalb des Campus',139,0),(143,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1088,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreibmarathon','mehrtägige Veranstaltung auf dem Campus',139,0),(144,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1056,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Textsorte','',133,0),(145,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1040,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Beleg-/Hausarbeit','',144,0),(146,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1032,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Bachelorarbeit','',144,0),(147,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1028,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Diplom-/Masterarbeit','',144,0),(148,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1026,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Doktorarbeit','',144,0),(149,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1025,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Praktikumsbericht','',144,0),(150,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1024,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Protokoll','',144,0),(151,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,768,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wiss. Fachartikel','',144,0),(152,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,640,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wiss. Projektantrag','',144,0),(153,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,576,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wiss. Blogpost','',144,0),(154,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,544,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;}',NULL,0,'Sprechstunde','',0,1),(155,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,528,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Fachtagung / Konferenz','',1,0),(156,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,520,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Lesung','',1,0),(157,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,516,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gespräch / Diskussion','',1,0),(158,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,514,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Film','',1,0),(159,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,513,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'TextLab','',0,0),(160,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,1,42,'a:5:{s:11:\"l10n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:10:\"genius_bar\";N;s:6:\"parent\";N;}','{\"starttime\":\"parent\",\"endtime\":\"parent\"}',0,'Technology / Infrastructure','<p>The use of the library and navigation in the sea of information requires knowledge of technology and infrastructure. We will be happy to assist you in this area.</p>',3,1),(161,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,256,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Open Educational Resources','',159,0),(162,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,128,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Digital Humanities','',159,0),(163,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,64,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Zielgruppe Tutoren','',134,0),(164,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,32,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Open Access Week','',139,0),(165,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,16,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Yoga und Achtsamkeit','',159,0),(166,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;}',NULL,0,'Spezialprogramm','',0,0),(167,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4,0,-1,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:10:\"genius_bar\";N;s:5:\"title\";N;s:11:\"description\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Zugangs-Ticket','',0,0),(168,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Training course in english','',139,0),(169,9,1624969571,1624969571,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gemeinschaftsgarten','',159,0);
/*!40000 ALTER TABLE `tx_slubevents_domain_model_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_contact`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_contact` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_contact`
--

LOCK TABLES `tx_slubevents_domain_model_contact` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_contact` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_contact` VALUES (1,9,1624969958,1624969958,1,0,0,0,0,0,0,0,'',0,0,0,0,0,256,0,0,0,'a:9:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:5:\"email\";N;s:9:\"telephone\";N;s:11:\"description\";N;s:5:\"photo\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,'Alexander Bigga','alexander.bigga@slub-dresden.de','+493514677212','','0');
/*!40000 ALTER TABLE `tx_slubevents_domain_model_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_discipline`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_discipline` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `discipline` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_discipline`
--

LOCK TABLES `tx_slubevents_domain_model_discipline` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_discipline` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_discipline` VALUES (1,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1792,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Maschinenwesen und Werkstoffwissenschaften',33),(2,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1664,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kunst / Fotografie',32),(3,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1600,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kommunikationswissenschaft',32),(4,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1568,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Klassische Philologie',32),(5,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1552,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Informatik',33),(6,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1544,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Geschichte',32),(7,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1540,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Germanistik',32),(8,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1538,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Geowissenschaften',35),(9,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1537,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Forstwesen',35),(10,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1536,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Erziehungswissenschaften',32),(11,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1280,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Elektrotechnik / Nachrichtentechnik / Biomedizinischer Technik',33),(12,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1152,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Chemie',34),(13,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1088,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Biologie',34),(14,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1056,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Architektur  / Bauingenieurwesen',35),(15,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1040,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Anglistik / Amerikanistik',32),(16,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1032,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Mathematik',34),(17,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1028,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Medizin',36),(18,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1026,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wirtschaftswissenschaften',32),(19,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1025,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Slavistik',32),(20,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1024,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Theologie',32),(21,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,768,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Technikgeschichte',32),(22,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,640,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Soziologie',32),(23,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,576,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Sachsen',32),(24,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,544,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Romanistik',32),(25,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,528,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Recht',32),(26,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,520,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Psychologie',34),(27,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,516,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Politikwissenschaften',32),(28,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,514,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Physik',34),(29,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,513,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Philosophie',32),(30,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Musik/Musikwissenschaften',32),(31,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,256,0,0,0,'a:4:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"parent\";N;}',NULL,0,'kein spezifisches Fach',0),(32,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,128,0,0,0,'a:1:{s:6:\"hidden\";N;}',NULL,0,'Geistes- und Sozialwissenschaften',0),(33,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,64,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Ingenieurwissenschaften',0),(34,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,32,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Mathematik und Naturwissenschaften',0),(35,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,16,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Bau und Umwelt',0),(36,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8,0,0,0,'a:4:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:6:\"parent\";N;}',NULL,0,'Medizin',0),(37,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Handschriften / Alte Drucke / Landeskunde',32),(38,9,1624969931,1624969931,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Verkehrswissenschaften',35);
/*!40000 ALTER TABLE `tx_slubevents_domain_model_discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_event`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_event` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `start_date_time` int(11) NOT NULL DEFAULT 0,
  `all_day` smallint(5) unsigned NOT NULL DEFAULT 0,
  `end_date_time` int(11) NOT NULL DEFAULT 0,
  `sub_end_date_time` int(11) NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `min_subscriber` int(11) NOT NULL DEFAULT 0,
  `max_subscriber` int(11) NOT NULL DEFAULT 0,
  `max_number` int(11) NOT NULL DEFAULT 0,
  `audience` int(11) NOT NULL DEFAULT 0,
  `sub_end_date_info_sent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `genius_bar` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recurring` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recurring_options` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recurring_end_date_time` int(11) NOT NULL DEFAULT 0,
  `cancelled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `onlinesurvey` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `subscribers` int(10) unsigned NOT NULL DEFAULT 0,
  `location` int(10) unsigned NOT NULL DEFAULT 0,
  `discipline` int(10) unsigned NOT NULL DEFAULT 0,
  `contact` int(10) unsigned DEFAULT 0,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `external_registration` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` int(10) unsigned DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_event`
--

LOCK TABLES `tx_slubevents_domain_model_event` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_event` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_event` VALUES (1,9,1629728475,1624971025,1,0,0,0,0,0,0,0,'',0,0,0,0,0,768,0,0,0,'a:26:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:9:\"recurring\";N;s:17:\"recurring_options\";N;s:23:\"recurring_end_date_time\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;}',NULL,'Führung durch die Corty Galerie',0,1625320800,0,1625324400,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,1,'s:102:\"a:2:{s:7:\"weekday\";a:4:{i:0;s:1:\"2\";i:1;s:1:\"5\";i:2;s:1:\"6\";i:3;s:1:\"7\";}s:8:\"interval\";s:6:\"weekly\";}\";',1640184660,0,'',1,0,16,1,1,0,'',0,0),(2,9,1633524083,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:24:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;s:16:\"sys_language_uid\";N;}',NULL,'Führung durch die Corty Galerie - Textsorte',1,1635084000,1,1635606000,1634997600,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,1,'',1,0,16,1,1,0,'',0,0),(3,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1626530400,0,1626534000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(4,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1627135200,0,1627138800,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(5,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1627740000,0,1627743600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(6,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1628344800,0,1628348400,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(7,9,1636372554,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:25:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:16:\"content_elements\";N;s:5:\"image\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;}',NULL,'Führung durch die Corty Galerie - Test Kategorie',1,1639490400,0,1639494000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',2,1,16,1,1,0,'',0,0),(8,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1629554400,0,1629558000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(9,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1630159200,0,1630162800,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(10,9,1633524511,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:24:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;s:16:\"sys_language_uid\";N;}',NULL,'Führung durch die Corty Galerie',1,1630764000,0,1632960000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(11,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1631368800,0,1631372400,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(12,9,1633446393,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:1:{s:6:\"hidden\";N;}',NULL,'Führung durch die Corty Galerie',1,1639836000,0,1639839600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,3,16,1,1,0,'',0,0),(13,9,1633524981,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:24:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;s:16:\"sys_language_uid\";N;}',NULL,'Führung durch die Corty Galerie',1,1632578400,0,1632585600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(14,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1633183200,0,1633186800,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(15,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1633788000,0,1633791600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(16,9,1635328202,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:25:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:16:\"content_elements\";N;s:5:\"image\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;}',NULL,'Führung durch die Corty Galerie - Deinde disputat, quod cuiusque generis animantium',1,1639526400,0,1639668600,0,'<p>XXX - In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>XXX - In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',3,1,73,1,1,0,'',0,0),(17,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1634997600,0,1635001200,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(18,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1635602400,0,1635606000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(19,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1636207200,0,1636210800,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(20,9,1636450283,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'a:25:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:16:\"content_elements\";N;s:5:\"image\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;}',NULL,'Test Root',1,1636812000,0,1636815600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(21,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1637416800,0,1637420400,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(22,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1638021600,0,1638025200,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(23,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1638626400,0,1638630000,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(24,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1639231200,0,1639234800,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(25,9,1624971122,1624971070,0,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,0,0,'',NULL,'Führung durch die Corty Galerie',1,1639836000,0,1639839600,0,'<p>In dieser einstündigen Führung erhalten Sie einen Einblick in die Dauerausstellung in der Schatzkammer unseres Buchmuseums und erfahren interessante Hintergründe zu den wertvollen und einzigartigen Exponaten.</p>','<p>In dieser einstündigen Führung durch unsere Schatzkammer erfahren Sie mehr über die Exponate der jeweils aktuellen Ausstellung. Über unsere Ausstellungen informieren wir Sie auf den Seiten der Corty Galerie.</p>\r\n<p>Der berühmte Maya-Codex ist ausstellungsunabhängig Gegenstand jeder Schatzkammer-Führung.</p>\r\n<p>Für diese Führung ist eine Anmeldung nötig. Aufgrund der aktuellen Situation bitten wir Sie, den Mindestabstand (1,50 m) einzuhalten. Tragen Sie bitte einen Mund-und Nasenschutz (Pflicht).</p>\r\n<p>Der Eintritt und die Führung sind kostenfrei, wir freuen uns über Spenden zur Erhaltung unserer wertvollen Bestände. Eine Spendenbox steht in der Galerie.</p>\r\n<p>Bitte verstauen Sie vor Beginn Ihre Taschen, Mäntel oder Jacken in den Schließfächern im Foyer. Sie benötigen dafür 1 Euro Pfand.</p>',0,10,10,0,0,0,0,'a:2:{s:7:\"weekday\";a:1:{i:0;s:1:\"6\";}s:8:\"interval\";s:6:\"weekly\";}',1640184660,0,'',1,0,16,1,1,0,'',0,0),(26,9,1633524749,1633524749,1,0,0,0,0,0,0,0,'',0,0,0,0,0,256,0,0,0,'a:25:{s:10:\"genius_bar\";N;s:5:\"title\";N;s:15:\"start_date_time\";N;s:7:\"all_day\";N;s:9:\"cancelled\";N;s:13:\"end_date_time\";N;s:8:\"location\";N;s:6:\"teaser\";N;s:11:\"description\";N;s:7:\"contact\";N;s:21:\"external_registration\";N;s:14:\"min_subscriber\";N;s:14:\"max_subscriber\";N;s:10:\"max_number\";N;s:17:\"sub_end_date_time\";N;s:22:\"sub_end_date_info_sent\";N;s:8:\"audience\";N;s:10:\"categories\";N;s:10:\"discipline\";N;s:11:\"subscribers\";N;s:9:\"recurring\";N;s:6:\"hidden\";N;s:12:\"onlinesurvey\";N;s:9:\"no_search\";N;s:16:\"sys_language_uid\";N;}',NULL,'c',0,1635346320,0,1635349920,0,'','',0,0,0,0,0,0,0,'',0,0,'',1,0,67,1,1,0,'',0,0);
/*!40000 ALTER TABLE `tx_slubevents_domain_model_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_location`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_location` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_location`
--

LOCK TABLES `tx_slubevents_domain_model_location` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_location` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_location` VALUES (1,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3840,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Online-Veranstaltung','','',0),(2,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3712,45,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Virtueller Seminarraum','Wir verwenden den browserbasierten Konferenzdienst DFNconf. Die Installation&nbsp; zusätzlicher Software ist nicht notwendig. Bitte halten Sie für eine aktive Teilnahme ein Headset bereit!','',0),(3,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3648,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Online / Telefon','Ihr Wissensbartermin findet entweder per Telefon oder per Videokonferenz, etwa via Skype oder DFNConf, statt. Die Expertin / der Experte informiert Sie im Anschluss an Ihre Buchung über die genauen Rahmenbedingen bzw. Einwahldaten. Geben Sie gerne in der Nachricht zur Buchung einen bevorzugten Kommunikationskanal an.','',0),(4,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3616,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Gemeinschaftstag','','',0),(5,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3600,17,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Lesesaal Sammlungen','','http://3d.slub-dresden.de/viewer/show.html?project_id=3&amp;language=de&amp;activate_location=2084',26),(6,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3592,16,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Kartenleseraum / Deutsche Fotothek','','https://3d.slub-dresden.de/viewer?p=3&l=3021',26),(7,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3588,14,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Informationspunkt Musik und Mediathek (IP 4)','Bitte finden Sie sich zur angegebenen Zeit an diesem Treffpunkt ein:<a href=\"http://3d.slub-dresden.de/viewer/show.html?project_id=3&amp;language=de&amp;activate_location=2080\" target=\"_blank\" class=\"threed\" external=\"1\"> Informationspunkt 4 in der Zentralbibliothek<br /></a>','http://3d.slub-dresden.de/viewer/show.html?project_id=3&amp;language=de&amp;activate_location=2080',26),(8,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3586,19,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Treffpunkt Führungen','Bitte finden Sie sich zur angegebenen Zeit an diesem Treffpunkt ein: <link http://slubdd.de/meet _blank threed>Treffpunkt Führungen in der Zentralbibliothek<br /></link>','http://slubdd.de/meet',26),(9,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3585,12,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Mitarbeiter-Büro, Zentralbibliothek; Treffpunkt Infostele','Bitte finden Sie sich zur angegebenen Zeit an diesem Treffpunkt ein: <link https://3d.slub-dresden.de/viewer?activate_location=8337 _blank>Infostele in der Zentralbibliothek (Ebene 0)<br /></link>','https://3d.slub-dresden.de/viewer?activate_location=8337',26),(10,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3584,10,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schulungsraum 0.47','Den Schulungsraum 0.47&nbsp;finden Sie in der Ebene 0 im Südflügel der Zentralbibliothek.','http://3d.slub-dresden.de/viewer?activate_location=3004',26),(11,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3328,10,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gruppenraum 0.46','Den <link http://3d.slub-dresden.de/viewer/show.html?project_id=3&language=de&activate_location=3003 - threed>Gruppenraum&nbsp;0.46</link>&nbsp;finden Sie in der Ebene 0 im Südflügel der Zentralbibliothek.','http://3d.slub-dresden.de/viewer?activate_location=3003',26),(12,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3200,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Beratungsraum 0.45','Den <link https://3d.slub-dresden.de/viewer?p=3&l=3002 - threed>Beratungsraum 0.45</link> finden Sie in der Ebene 0 im Südflügel der Zentralbibliothek.','https://3d.slub-dresden.de/viewer?p=3&l=3002',26),(13,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3136,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Blinden-AP - 0.44','Den <link http://3d.slub-dresden.de/viewer?project_id=3&language=de&activate_location=3001 - threed>Arbeitsplatz für Blinde und Sehbehinderte</link> finden Sie in der Ebene 0 im Südflügel der Zentralbibliothek.','http://3d.slub-dresden.de/viewer?project_id=3&language=de&activate_location=3001',26),(14,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3104,10,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schulungsraum 0.42','Den Schulungsraum&nbsp;0.42&nbsp;finden Sie in der Ebene 0 im Südflügel der Zentralbibliothek.','http://3d.slub-dresden.de/viewer?activate_location=2999',26),(15,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3088,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Buchmuseum/Sonderausstellung','','http://3d.slub-dresden.de/viewer/show.html?project_id=3&amp;language=de&amp;activate_location=2075',26),(16,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3080,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Foyer','Bitte finden Sie sich zur angegebenen Zeit am Informationspunkt ServiceCenterStudium ein.','http://3d.slub-dresden.de/viewer?activate_location=2893',26),(17,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3076,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Digitalisierungszentrum','','',0),(18,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3074,27,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schulungsraum IT A+4.53','Nordflügel der Zentralbibliothek; für interne Veranstaltungen (nicht zugänglich für NutzerInnen)','',26),(19,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3073,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.17','Mitarbeiterbüro von Christof Rodejohann und Alexander Bigga','',26),(20,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,3072,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.15','Mitarbeiterbüro von Sebastian Meyer','',26),(21,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2816,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.14','','',26),(22,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2688,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.13','','',26),(23,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2624,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.06a','','',26),(24,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2592,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.04','','',26),(25,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2576,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'IT Raum 4.01','Zugang zum Server-Raum und zur IT-Zelle (4.19)','',26),(26,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2568,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Zentralbibliothek, Zellescher Weg 18','<link https://3d.slub-dresden.de/viewer?p=3&b=5&f=11&c=8909&l=3137&lang=de - externallink>3D-Innenansicht der SLUB-Zentralbibliothek</link>','https://osm.org/go/0MLhJN39g-?m=',0),(27,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2564,14,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Mitarbeiter-Büro; Treffpunkt Infopunkt','Bitte finden Sie sich zur angegebenen Zeit an diesem Treffpunkt ein: <link http://3d.slub-dresden.de/viewer/show.html?project_id=3&language=de&activate_location=757 _blank threed>Informationspunkt in der Bereichsbibliothek DrePunct<br /></link>','http://3d.slub-dresden.de/viewer?project_id=3&amp;language=de&amp;activate_location=757',30),(28,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2562,35,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Makerspace M2','','http://3d.slub-dresden.de/viewer?activate_location=3356',30),(29,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2561,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Makerspace M1','','http://3d.slub-dresden.de/viewer?activate_location=3359',30),(30,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2560,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Bereichsbibliothek DrePunct, Zellescher Weg 17','','http://www.openstreetmap.org/directions?engine=graphhopper_bicycle&route=%3B51.02938%2C13.73878',0),(31,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2304,20,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Institut für Germanistik, Wiener Str. 48, Raum 016','','https://navigator.tu-dresden.de/etplan/w48/00/raum/334300.0160',47),(32,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2176,5,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schumannbau, Fakultät Wirtschaftswissenschaften, B247','','https://navigator.tu-dresden.de/etplan/sch/02/raum/146102.1240',47),(33,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2112,21,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gerber-Bau, Juristische Fakultät, GER 221, Computerpool','','https://navigator.tu-dresden.de/etplan/ger/02/raum/222002.0210',47),(34,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2080,20,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'GER 202','','https://navigator.tu-dresden.de/etplan/ger/02/raum/222002.0020',35),(35,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2064,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Zweigbibliothek Rechtswissenschaft, Bergstraße 53','','https://3d.slub-dresden.de/viewer?project_id=3&amp;language=de&amp;activate_location=3689',0),(36,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2056,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Zweigbibliothek Erziehungswissenschaften','','',0),(37,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2052,0,0,0,'a:8:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',NULL,0,'Zweigbibliothek Forstwesen','','',0),(38,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2050,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Zweigbibliothek Medizin','<link http://www.slub-dresden.de/ueber-uns/standorte/medizin/>Schulungsraum (Raum 307)</link>','http://www.slub-dresden.de/ueber-uns/standorte/medizin/',0),(39,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2049,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Patentinformationszentrum, Zellescher Weg 19, Andreas-Schubert-Bau, 1. Etage','','',47),(40,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2048,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Graduiertenakademie, Seminarraum, Mommsenstr. 7','','https://navigator.tu-dresden.de/gebaeude/m07',47),(41,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1792,74,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Foyer des MTZ, Fiedlerstraße 42, Haus 91','','',45),(42,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1664,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Hörsaal 1 MTZ, Haus 91, Fiedlerstr. 42','','',45),(43,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1600,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Hörsaal Dekanatsgebäude, Haus 40, Fiedlerstr. 27','','',45),(44,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1568,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Computerpool Blasewitzer Straße 86, Haus 105, 2. Etage, Raum 2.350','','https://eplan.med.tu-dresden.de/',45),(45,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1552,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Medizinische Fakultät','','',47),(46,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1544,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Fakultät Forstwissenschaften, Rechenstation, PC-Pool, Pienner Str. 8, Tharandt','','',0),(47,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1540,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'TU Dresden','','',0),(48,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1538,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Gemeinschaftstag','','',59),(49,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1537,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Informationspunkt 2','','http://3d.slub-dresden.de/viewer?activate_location=2895',26),(50,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1536,55,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissensbar, Informationspunkt 7','','http://3d.slub-dresden.de/viewer?activate_location=2896',26),(51,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1280,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissensbar, Informationspunkt 6','','http://3d.slub-dresden.de/viewer?activate_location=2897',26),(52,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1152,81,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissensbar 2','','http://slubdd.de/wb2',26),(53,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1088,56,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Wissensbar 1','','http://slubdd.de/wb1',26),(54,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1056,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Talleyrand-Zimmer','Talleyrand-Zimmer','http://3d.slub-dresden.de/viewer?project_id=3&amp;language=de&amp;activate_location=3263',26),(55,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1040,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Beratungsraum -2.115','Den&nbsp;<link http://3d.slub-dresden.de/viewer/show.html?project_id=3&language=de&activate_location=3002 - threed>Beratungsraum -2.115</link>&nbsp;finden Sie in der Ebene -2 im Südflügel der Zentralbibliothek.','',26),(56,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1032,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Multimed. Sprachlernzentrum, Zellescher Weg 22, SEI-207','','https://navigator.tu-dresden.de/etplan/se1/02/raum/236402.0070',47),(57,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1028,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Berndt-Bau, Fakultät Maschinenwesen, BER207','','https://navigator.tu-dresden.de/etplan/ber/02',47),(58,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1026,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Hygiene-Museum, Foyer','','http://www.dhmd.de/index.php?id=37',59),(59,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1025,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Extern','','',0),(60,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1024,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schreibzentrum, Strehlener Str. 22/24','','',47),(61,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,768,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Project Scouts an der TU Dresden, Mommsenstr. 7','','',47),(62,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,640,75,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Hörsaalzentrum (HSZ), Bergstraße 64, 01069 Dresden, Raum - HSZ/0201/U','','https://navigator.tu-dresden.de/etplan/hsz/02/raum/136102.0010',47),(63,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,576,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Testothek, Chemnitzer Str. 46b, Raum 154','','',47),(64,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,544,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Klemperer-Saal','','https://3d.slub-dresden.de/viewer?project_id=3&amp;language=de&amp;activate_location=2068',26),(65,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,528,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Kulturpalast - Zentralbibliothek','','',0),(66,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,520,0,0,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Fraunhofer IWU','Nöthnitzer Straße 44, 01187 Dresden','https://www.iwu.fraunhofer.de/',59),(67,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,516,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'HTW Bibliothek Dresden','Andreas-Schubert-Straße 8','https://www.htw-dresden.de/bib.html',0),(68,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,514,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Coworking-Space Impact Hub, Bayrische Strasse 8, 01069 Dresden','','https://dresden.impacthub.net/',0),(69,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,513,0,0,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Staatsarchiv Dresden, Archivstraße 14','','http://geoportal.sachsen.de/cps/karte.html?showmap=true&lang=de&app=amt24&address=Archivstra%C3%9Fe%2014:hausnummer%2001097%20Dresden',0),(70,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,512,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Japanisches Palais','','https://www.skd.museum/besuch/japanisches-palais/',0),(71,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,256,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Schimmel Projects Art Centre Dresden, Großenhainer Str. 61–63','','',59),(72,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,128,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Universitätsbibliothek Leipzig - Bibliotheca Albertina, Beethovenstraße 6, 04107 Leipzig, Vortragssaal','Der Vortragsaal der Albertina befindet sich im Erdgeschoss des Gebäudes.','',0),(73,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,64,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'Hauptbahnhof Dresden','','',59),(74,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,32,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Sächsische Akademie der Künste, Palaisplatz 3, 01097 Dresden','','',0),(75,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,16,93,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB TextLab T3','','https://www.slub-dresden.de/ueber-uns/standorte/erziehungswissenschaften/',36),(76,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,8,93,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB TextLab T2','','https://www.slub-dresden.de/ueber-uns/standorte/erziehungswissenschaften/',36),(77,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,4,0,-1,0,'a:1:{s:6:\"parent\";N;}',NULL,0,'SLUB TextLab T1','','https://www.slub-dresden.de/ueber-uns/standorte/erziehungswissenschaften/',36),(78,9,1624970820,1624970820,1,0,0,0,0,0,0,0,'',0,0,0,0,0,2,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Frauenkirche Dresden','','',0),(79,9,1624970840,1624970820,1,1,0,0,0,0,0,0,'',0,0,0,0,0,1,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Impfraum 1','','',0),(80,9,1624970836,1624970820,1,1,0,0,0,0,0,0,'',0,0,0,0,0,0,0,-1,0,'a:6:{s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:4:\"name\";N;s:11:\"description\";N;s:4:\"link\";N;s:6:\"parent\";N;}',NULL,0,'Impfraum 2','','',0);
/*!40000 ALTER TABLE `tx_slubevents_domain_model_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_domain_model_subscriber`
--

DROP TABLE IF EXISTS `tx_slubevents_domain_model_subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_domain_model_subscriber` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `event` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `institution` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `customerid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `number` int(11) NOT NULL DEFAULT 0,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `editcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `acceptpp` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_domain_model_subscriber`
--

LOCK TABLES `tx_slubevents_domain_model_subscriber` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_domain_model_subscriber` DISABLE KEYS */;
INSERT INTO `tx_slubevents_domain_model_subscriber` VALUES (1,9,1625148336,1625148327,0,1,0,0,0,0,0,'Testnutzer DDEV','testnutzer@example.com','','','4998866',1,'','122e9cd184b7f7da54bb3b94103b0500ec3b7a9f712eafb0b63af8868dc9d5b4',0),(2,9,1636372554,1628774774,0,0,0,0,0,0,7,'Testnutzer DDEV','testnutzer@example.com','','','4998866',2,'','142a45f981cb92fdfbce2df0058759a0260cbbb47e235001bef25695000486bb',0),(3,9,1637852392,1631534373,0,0,0,0,0,0,12,'Testnutzer DDEV A','testnutzer@example.com','','','4998866',1,'','98af36e67cbaf1e51ce0b4e43f441a2eeca36c784ea2aa87cd90ae3bf3c22f6b',0),(4,9,1633020586,1631534387,0,0,0,0,0,0,12,'Testnutzer DDEV','testnutzer@example.com','','','4998866',1,'','32b2baee3033cf5c8c9a68a4547a4eada22c9a52dd7f1aaf723ba3e2d2891190',0),(5,9,1633020586,1631534395,0,0,0,0,0,0,12,'Testnutzer DDEV','testnutzer@example.com','','','4998866',1,'','49f1d93b38fae2734df03d14db5b285e8e35092e2dfaf45eb74b7fe5db8fecdd',0),(6,9,1635328202,1631534438,0,0,0,0,0,0,16,'Testnutzer DDEV','testnutzer@example.com','','','4998866',1,'','8c5398acf572c55bf4920b130e726f8cee91a40f7ce13c2ec012179402cc0f72',0);
/*!40000 ALTER TABLE `tx_slubevents_domain_model_subscriber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_event_category_mm`
--

DROP TABLE IF EXISTS `tx_slubevents_event_category_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_event_category_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_event_category_mm`
--

LOCK TABLES `tx_slubevents_event_category_mm` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_event_category_mm` DISABLE KEYS */;
INSERT INTO `tx_slubevents_event_category_mm` VALUES (1,92,1,0),(3,92,1,0),(4,92,1,0),(5,92,1,0),(6,92,1,0),(7,92,2,0),(8,92,1,0),(9,92,1,0),(10,92,1,0),(11,92,1,0),(12,92,1,0),(13,92,1,0),(14,92,1,0),(15,92,1,0),(16,92,1,0),(17,92,1,0),(18,92,1,0),(19,92,1,0),(20,92,1,0),(21,92,1,0),(22,92,1,0),(23,92,1,0),(24,92,1,0),(25,92,1,0),(2,144,1,0),(16,158,2,0),(16,156,3,0),(26,165,1,0),(7,150,1,0);
/*!40000 ALTER TABLE `tx_slubevents_event_category_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubevents_event_discipline_mm`
--

DROP TABLE IF EXISTS `tx_slubevents_event_discipline_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubevents_event_discipline_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubevents_event_discipline_mm`
--

LOCK TABLES `tx_slubevents_event_discipline_mm` WRITE;
/*!40000 ALTER TABLE `tx_slubevents_event_discipline_mm` DISABLE KEYS */;
INSERT INTO `tx_slubevents_event_discipline_mm` VALUES (1,31,1,0),(3,31,1,0),(4,31,1,0),(5,31,1,0),(6,31,1,0),(7,31,1,0),(8,31,1,0),(9,31,1,0),(10,31,1,0),(11,31,1,0),(12,31,1,0),(13,31,1,0),(14,31,1,0),(15,31,1,0),(16,31,1,0),(17,31,1,0),(18,31,1,0),(19,31,1,0),(20,31,1,0),(21,31,1,0),(22,31,1,0),(23,31,1,0),(24,31,1,0),(25,31,1,0),(2,35,1,0),(26,9,1,0);
/*!40000 ALTER TABLE `tx_slubevents_event_discipline_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubfindbookmarks_domain_model_bookmark`
--

DROP TABLE IF EXISTS `tx_slubfindbookmarks_domain_model_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubfindbookmarks_domain_model_bookmark` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `bookmarklist` int(10) unsigned NOT NULL DEFAULT 0,
  `recordid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imprint` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `series` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `format` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `bookmarklist` (`bookmarklist`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubfindbookmarks_domain_model_bookmark`
--

LOCK TABLES `tx_slubfindbookmarks_domain_model_bookmark` WRITE;
/*!40000 ALTER TABLE `tx_slubfindbookmarks_domain_model_bookmark` DISABLE KEYS */;
INSERT INTO `tx_slubfindbookmarks_domain_model_bookmark` VALUES (1,0,1642085952,1626552975,0,1,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,19,'dswarm-126-ZnR1bml2ZG9ydG11bmQ6b2FpOmVsZG9yYWRvLnR1LWRvcnRtdW5kLmRlOjIwMDMvMjQxNzU','Integrated formal modeling and automated analysis of computer network attacks','Rothmaier, Gerrit                                                    ;                 Krumm, Heiko; Biskup, Joachim','Eldorado - Repositorium der TU Dortmund, 2007','','','Thesis'),(2,0,1642085952,1626552988,0,1,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,19,'dswarm-126-ZnRzdWJnZ2VvOm9haTplLWRvY3MuZ2VvLWxlby5kZToxMTg1OC84MzAx','Implementierung und Bewertung einer auf statistischen Momenten basierenden Methode zur automatischen Bestimmung der Einsatzzeiten von P- und S-Phasen','Kühne, Niklas; Hellwig, Olaf; Buske, Stefan','GEO-LEOe-docs (FID GEO), 2021','','','Article, E-Article'),(3,0,1642085967,1642085967,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,26,'dswarm-126-ZnR1bml2ZG9ydG11bmQ6b2FpOmVsZG9yYWRvLnR1LWRvcnRtdW5kLmRlOjIwMDMvMjYzMQ','Erweiterung des EMILE-Verfahrens zum induktiven Lernen von kontextfreien Grammatiken für natürliche Sprache','Dörnenburg, Erik','Universität Dortmund, 2003','','','Article, E-Article'),(4,0,1642085972,1642085971,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,27,'dswarm-126-ZnRzdWJnZ2VvOm9haTplLWRvY3MuZ2VvLWxlby5kZToxMTg1OC84MzEz','NEXD: A Software Package for Seismic Wave Simulation in Complex Geological Media – New Developments','Boxberg, Marc S.; Lamert, Andre; Möller, Thomas; Friederich, Wolfgang','GEO-LEOe-docs (FID GEO), 2021','','','Article, E-Article'),(5,0,1642085986,1642085984,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,27,'dswarm-126-ZnRzdWJnZ2VvOm9haTplLWRvY3MuZ2VvLWxlby5kZToxMTg1OC84MzM3','Geologische Specialkarte des Grossherzogthums Hessen und der angrenzenden Landesgebiete im Maassstabe von 1: 50000 / Mittelrheinischer Geologischer Verein: Section Lauterbach ; Geological map of the Grossherzogthums Hessen and the neighboring state areas on a scale of 1: 50,000 / Middle Rhine Geological Association: Lauterbach section','Tasche, Hans; Gutberlet, Wilhelm Carl Julius; Ludwig, Rudolf','SUB Göttingen,1869','','','Article, E-Article');
/*!40000 ALTER TABLE `tx_slubfindbookmarks_domain_model_bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubfindbookmarks_domain_model_bookmarklist`
--

DROP TABLE IF EXISTS `tx_slubfindbookmarks_domain_model_bookmarklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubfindbookmarks_domain_model_bookmarklist` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `appaccesskey` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `publicaccesskey` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `session` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `bookmarks` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubfindbookmarks_domain_model_bookmarklist`
--

LOCK TABLES `tx_slubfindbookmarks_domain_model_bookmarklist` WRITE;
/*!40000 ALTER TABLE `tx_slubfindbookmarks_domain_model_bookmarklist` DISABLE KEYS */;
INSERT INTO `tx_slubfindbookmarks_domain_model_bookmarklist` VALUES (1,0,1624962306,1624962306,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','db9bcd75e8ade46258b60f0658eb53b3',0,0),(2,0,1624962361,1624962361,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','0217970d6e503069ffb61df6af8f5d05',0,0),(3,0,1624962587,1624962587,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','258626371718b9586bc0f7f576e517ec',0,0),(4,0,1624963033,1624963033,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','4e330d35fc6857ae302b247f457509ce',0,0),(5,0,1624963045,1624963045,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','2203ad52eaec893c20f76d25c2216f90',0,0),(6,0,1624963177,1624963177,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','63b230f2e1b07384a578ad4c3d297cd0',0,0),(7,0,1624963179,1624963179,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','52cd1e397c79a030a0085182acf7ff0e',0,0),(8,0,1624963185,1624963185,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','31c79dfba92f7b598b401c338f25213e',0,0),(9,0,1624963187,1624963187,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','81ca9c3f14752f6d034de232592a8686',0,0),(10,0,1624963817,1624963817,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','526ccd1de09b9918620c31ca96544099',0,0),(11,0,1624963875,1624963875,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','ff9e2d8ab887544176972bdb1d8ed068',0,0),(12,0,1624963875,1624963875,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','85739cae09ed4585c3b3cd02b188f86e',0,0),(13,0,1624963887,1624963887,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','061232d2e857873e8b9fc509b74c5226',0,0),(14,0,1624963898,1624963898,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','5bf0c2ef14976e9e0d4c136786c76c4e',0,0),(15,0,1624964949,1624964949,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','70930beffbb71ab9d7a01ddf02235a39',0,0),(16,0,1625147971,1625147971,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','f8035145a3216acb518b0da9748a9fa9',0,0),(17,0,1625148054,1625148054,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','1dc57ab862cd99031459a3dccb8b0db9',0,0),(18,0,1626440727,1626440727,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','d0dc36ba0f3b3a9b8126c88f4e218a14',0,0),(19,0,1642085952,1626534194,0,1,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','4998866','','','',0,2),(20,0,1626552827,1626552827,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','3d5980f9e64fdfd333149ea40d0582c7',0,0),(21,0,1626552988,1626552832,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','19718cb978b302c4c9e8b393a10c414c',0,2),(22,0,1626552888,1626552888,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','6b1f5af495dd9ff79d747a891d0c0aae',0,0),(23,0,1626766069,1626766069,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','75b75c49e30f282bf1cbcfa5c0671e17',0,0),(24,0,1626766075,1626766075,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','a81b56a2ddb9a81e8eda9e507491fa4e',0,0),(25,0,1628771510,1628771510,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','','','','eaf8fa702bbfa9acfaea5d7c62834c4a',0,0),(26,0,1642085984,1642085947,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'','','4998866','','','',1,2),(27,0,1642085986,1642085959,0,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,'',NULL,'Meine erste Merkliste','','4998866','','','',0,2);
/*!40000 ALTER TABLE `tx_slubfindbookmarks_domain_model_bookmarklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubtemplate_domain_model_oerdisplay`
--

DROP TABLE IF EXISTS `tx_slubtemplate_domain_model_oerdisplay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubtemplate_domain_model_oerdisplay` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `highlight` int(11) NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `institution` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mediatype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` int(11) NOT NULL DEFAULT 0,
  `platform` int(11) NOT NULL DEFAULT 0,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `licence` int(11) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubtemplate_domain_model_oerdisplay`
--

LOCK TABLES `tx_slubtemplate_domain_model_oerdisplay` WRITE;
/*!40000 ALTER TABLE `tx_slubtemplate_domain_model_oerdisplay` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_slubtemplate_domain_model_oerdisplay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubtemplate_factstables`
--

DROP TABLE IF EXISTS `tx_slubtemplate_factstables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubtemplate_factstables` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubtemplate_factstables`
--

LOCK TABLES `tx_slubtemplate_factstables` WRITE;
/*!40000 ALTER TABLE `tx_slubtemplate_factstables` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_slubtemplate_factstables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubtemplate_staticnewsbar`
--

DROP TABLE IF EXISTS `tx_slubtemplate_staticnewsbar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubtemplate_staticnewsbar` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci NOT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubtemplate_staticnewsbar`
--

LOCK TABLES `tx_slubtemplate_staticnewsbar` WRITE;
/*!40000 ALTER TABLE `tx_slubtemplate_staticnewsbar` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_slubtemplate_staticnewsbar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_slubtemplate_testimonials`
--

DROP TABLE IF EXISTS `tx_slubtemplate_testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_slubtemplate_testimonials` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `job` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hired_date` int(10) unsigned NOT NULL DEFAULT 0,
  `slogan` text COLLATE utf8_unicode_ci NOT NULL,
  `bodytext` text COLLATE utf8_unicode_ci NOT NULL,
  `whattolearn` text COLLATE utf8_unicode_ci NOT NULL,
  `portrait` int(10) unsigned DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `favpiece` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_slubtemplate_testimonials`
--

LOCK TABLES `tx_slubtemplate_testimonials` WRITE;
/*!40000 ALTER TABLE `tx_slubtemplate_testimonials` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_slubtemplate_testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_cache`
--

DROP TABLE IF EXISTS `tx_solr_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `content` mediumblob DEFAULT NULL,
  `lifetime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_cache`
--

LOCK TABLES `tx_solr_cache` WRITE;
/*!40000 ALTER TABLE `tx_solr_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_solr_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_cache_tags`
--

DROP TABLE IF EXISTS `tx_solr_cache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_cache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`),
  KEY `cache_tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_cache_tags`
--

LOCK TABLES `tx_solr_cache_tags` WRITE;
/*!40000 ALTER TABLE `tx_solr_cache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_solr_cache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_indexqueue_indexing_property`
--

DROP TABLE IF EXISTS `tx_solr_indexqueue_indexing_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_indexqueue_indexing_property` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0,
  `property_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `property_value` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_indexqueue_indexing_property`
--

LOCK TABLES `tx_solr_indexqueue_indexing_property` WRITE;
/*!40000 ALTER TABLE `tx_solr_indexqueue_indexing_property` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_solr_indexqueue_indexing_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_indexqueue_item`
--

DROP TABLE IF EXISTS `tx_solr_indexqueue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_indexqueue_item` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL DEFAULT 0,
  `item_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `indexing_configuration` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `has_indexing_properties` smallint(6) NOT NULL DEFAULT 0,
  `indexing_priority` int(11) NOT NULL DEFAULT 0,
  `changed` int(11) NOT NULL DEFAULT 0,
  `indexed` int(11) NOT NULL DEFAULT 0,
  `errors` text COLLATE utf8_unicode_ci NOT NULL,
  `pages_mountidentifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `changed` (`changed`),
  KEY `indexing_priority_changed` (`indexing_priority`,`changed`),
  KEY `item_id` (`item_type`,`item_uid`),
  KEY `pages_mountpoint` (`item_type`,`item_uid`,`has_indexing_properties`,`pages_mountidentifier`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_indexqueue_item`
--

LOCK TABLES `tx_solr_indexqueue_item` WRITE;
/*!40000 ALTER TABLE `tx_solr_indexqueue_item` DISABLE KEYS */;
INSERT INTO `tx_solr_indexqueue_item` VALUES (5,1,'tx_slubevents_domain_model_event',12,'events',0,0,1633446393,0,'',''),(6,1,'tx_slubevents_domain_model_event',16,'events',0,0,1633446392,0,'',''),(7,1,'tx_slubevents_domain_model_event',7,'events',0,0,1636372554,0,'',''),(8,1,'tx_slubevents_domain_model_event',2,'events',0,0,1633524083,0,'',''),(9,1,'tx_slubevents_domain_model_event',26,'events',0,0,1633524749,0,'',''),(10,1,'tx_slubevents_domain_model_event',20,'events',0,0,1636450283,0,'','');
/*!40000 ALTER TABLE `tx_solr_indexqueue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_last_searches`
--

DROP TABLE IF EXISTS `tx_solr_last_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_last_searches` (
  `sequence_id` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `keywords` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`sequence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_last_searches`
--

LOCK TABLES `tx_solr_last_searches` WRITE;
/*!40000 ALTER TABLE `tx_solr_last_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_solr_last_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_solr_statistics`
--

DROP TABLE IF EXISTS `tx_solr_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_solr_statistics` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `root_pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT 0,
  `num_found` int(11) NOT NULL DEFAULT 0,
  `suggestions_shown` int(11) NOT NULL DEFAULT 0,
  `time_total` int(11) NOT NULL DEFAULT 0,
  `time_preparation` int(11) NOT NULL DEFAULT 0,
  `time_processing` int(11) NOT NULL DEFAULT 0,
  `feuser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `cookie` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `keywords` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `page` int(10) unsigned NOT NULL DEFAULT 0,
  `filters` blob DEFAULT NULL,
  `sorting` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parameters` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `rootpid_keywords` (`root_pid`,`keywords`),
  KEY `rootpid_tstamp` (`root_pid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_solr_statistics`
--

LOCK TABLES `tx_solr_statistics` WRITE;
/*!40000 ALTER TABLE `tx_solr_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_solr_statistics` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-13 15:01:03
